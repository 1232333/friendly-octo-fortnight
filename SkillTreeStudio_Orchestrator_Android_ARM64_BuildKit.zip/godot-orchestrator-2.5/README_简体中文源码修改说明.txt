Orchestrator 2.5 源码简体中文 UI 修改包

基于用户提供的 godot-orchestrator-2.5.zip，已修改 src/editor/ 下 17 个 C++ 源文件。

本轮源码级 UI 翻译重点：
- 蓝图画布右键菜单、节点操作、对齐/整理菜单
- 图表、函数、宏、变量、信号组件面板及说明文字
- 搜索结果、匹配项、跳转节点对话框
- 蓝图创建、打开、另存为、最近打开、帮助搜索
- 输入事件设置、附加选项、保存并重启等界面

构建状态（重要）：本轮未能完成编译。当前环境缺少 Android NDK（ANDROID_NDK 未设置）、Android CMake toolchain；源码压缩包的 extern/godot-cpp 和 extern/godot-engine 子模块目录为空，缺少 godot-cpp/gdextension/extension_api.json；也没有 Godot 可执行文件。因此不能声称已编译或实机验证，原有 liborchestrator.android.64.editor.so 未被本次源码修改更新。

尝试命令：cmake --preset android-arm64-editor
失败原因：缺少 extern/godot-cpp/gdextension/extension_api.json，且找不到 Android NDK toolchain 文件。

后续需要在具备 Godot 4.7 对应源码/API、godot-cpp 子模块和 Android NDK 的环境中执行：
  cmake --preset android-arm64-editor
  cmake --build build/android-arm64-editor --config Release

注意：源码字符串替换只处理明确的 UI 文案，不翻译用户自定义变量名、函数名、信号名或序列化字段。
