// This file is part of the Godot Orchestrator project.
//
// Copyright (c) 2023-present Crater Crash Studios LLC and its contributors.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//		http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
#include "editor/gui/search_dialog.h"

#include "common/macros.h"
#include "common/scene_utils.h"
#include "core/godot/scene_string_names.h"
#include "editor/gui/filter_line_edit.h"
#include "editor/plugins/orchestrator_editor_plugin.h"

#include <godot_cpp/classes/button.hpp>
#include <godot_cpp/classes/editor_interface.hpp>
#include <godot_cpp/classes/editor_settings.hpp>
#include <godot_cpp/classes/h_box_container.hpp>
#include <godot_cpp/classes/h_split_container.hpp>
#include <godot_cpp/classes/input_event_key.hpp>
#include <godot_cpp/classes/label.hpp>
#include <godot_cpp/classes/option_button.hpp>
#include <godot_cpp/classes/popup_menu.hpp>
#include <godot_cpp/classes/popup_panel.hpp>
#include <godot_cpp/classes/v_box_container.hpp>
#include <godot_cpp/classes/v_split_container.hpp>

void OrchestratorEditorSearchDialog::_favorite_selected() {
    TreeItem* item = _favorites->get_selected();
    if (!item) {
        return;
    }

    const Ref<SearchItem> search_item = item->get_meta("__item");
    if (search_item.is_valid() && !search_item->text.is_empty()) {
        _search_box->set_text(search_item->text);
        _search_box->set_caret_column(search_item->text.length());
        _recent->deselect_all();
        _update_search();
    }
}

void OrchestratorEditorSearchDialog::_favorite_activated() {
    _favorite_selected();
    _confirmed();
}

void OrchestratorEditorSearchDialog::_favorite_toggled() {
    TreeItem* item = _search_options->get_selected();
    if (!item) {
        return;
    }

    const Ref<SearchItem> search_item = item->get_meta("__item");
    if (search_item.is_valid() && _favorite_list.has(search_item)) {
        _favorite_list.erase(search_item);
        _favorite->set_pressed(false);
    } else {
        _favorite_list.push_back(search_item);
        _favorite->set_pressed(true);
    }

    _save_and_update_favorites_list();
}

void OrchestratorEditorSearchDialog::_history_selected(int p_index) {
    const Ref<SearchItem> item = _recent->get_item_metadata(p_index);
    if (item.is_valid()) {
        _search_box->set_text(item->text);
        _search_box->set_caret_column(item->text.length());
        _favorites->deselect_all();
        _update_search();
    }
}

void OrchestratorEditorSearchDialog::_history_activated(int p_index) {
    _history_selected(p_index);
    _confirmed();
}

void OrchestratorEditorSearchDialog::_search_changed(const String& p_text) {
    _update_search();
}

void OrchestratorEditorSearchDialog::_confirmed() {
    TreeItem* selected = _search_options->get_selected();
    if (!selected) {
        return;
    }

    Ref<SearchItem> search_item = selected->get_meta("__item");
    if (!search_item.is_valid()) {
        return;
    }

    if (!search_item->selectable) {
        return;
    }

    constexpr int RECENT_HISTORY_SIZE = 15;

    Vector<Ref<SearchItem>> to_be_saved;
    to_be_saved.push_back(search_item);

    for (int i = 0; i < MIN(RECENT_HISTORY_SIZE - 1, _recent->get_item_count()); i++) {
        const Ref<SearchItem> item = _recent->get_item_metadata(i);
        if (item.is_valid()) {
            to_be_saved.push_back(item);
        }
    }

    _save_recent_items(to_be_saved);

    hide();

    emit_signal("selected");
    _cleanup();
}

void OrchestratorEditorSearchDialog::_canceled() {
    emit_signal("closed");
    _cleanup();
}

void OrchestratorEditorSearchDialog::_item_selected() {
    TreeItem* item = _search_options->get_selected();
    if (!item) {
        return;
    }
    _select_item(item, false);
}

void OrchestratorEditorSearchDialog::_filter_selected(int p_index) {
    _filter_type_changed(p_index);
    _update_search();
}

void OrchestratorEditorSearchDialog::_update_themes() {
    const int icon_width = SceneUtils::get_editor_class_icon_size();
    if (_search_options) {
        _search_options->add_theme_constant_override("icon_max_width", icon_width);
        _favorites->add_theme_constant_override("icon_max_width", icon_width);
        _recent->set_fixed_icon_size(Size2i(icon_width, icon_width));

        _search_box->set_right_icon(SceneUtils::get_editor_icon("Search"));
        _favorite->set_button_icon(SceneUtils::get_editor_icon("Favorites"));
    }
}

bool OrchestratorEditorSearchDialog::_is_favorite(const Ref<SearchItem>& p_item) const {
    return _favorite_list.has(p_item);
}

TreeItem* OrchestratorEditorSearchDialog::_populate_search_results() {
    const String search_text = _search_box->get_text();

    // Generate list of possible candidates
    Vector<Ref<SearchItem>> candidates;
    for (const Ref<SearchItem>& item : _search_items) {
        if (search_text.is_empty() || search_text.is_subsequence_ofn(item->name) || search_text.is_subsequence_ofn(item->text)) {
            if (!_filters || (_filters && !_is_filtered(item, search_text))) {
                candidates.push_back(item);
            }
        }
    }

    HashMap<String, TreeItem*> cache;
    for (const Ref<SearchItem>& candidate : candidates) {
        Vector<Ref<SearchItem>> item_hierarchy;
        item_hierarchy.push_back(candidate);

        Ref<SearchItem> hierarchy_parent = candidate->parent;
        while (hierarchy_parent.is_valid()) {
            item_hierarchy.push_back(hierarchy_parent);
            hierarchy_parent = hierarchy_parent->parent;
        }

        item_hierarchy.reverse();

        TreeItem* parent = nullptr;
        while (!item_hierarchy.is_empty()) {
            const String lookup = item_hierarchy.get(0)->path;
            if (cache.has(lookup)) {
                parent = cache[lookup];
                item_hierarchy.remove_at(0);
                continue;
            }
            break;
        }

        // Create entries for all remaining hierarchy items
        for (const Ref<SearchItem>& item : item_hierarchy) {
            TreeItem* child = parent ? parent->create_child() : _search_options->create_item();
            if (!item->script_filename.is_empty()) {
                child->set_text(0, vformat("%s (%s)", item->text, item->script_filename));
            } else {
                child->set_text(0, item->text);
            }
            child->set_icon(0, item->icon.is_valid() ? item->icon : nullptr);
            child->set_selectable(0, item->selectable);
            child->set_collapsed(false);
            child->set_meta("__item", item);

            // font_disabled_color
            if (item->disabled) {
                child->set_custom_color(0, Color(0.875, 0.875, 0.875, 0.5));
            }

            cache[item->path] = child;
            parent = child;

            _set_search_item_collapse_state(child);
        }
    }

    float highest_score = 0;
    int highest_index = 0;

    for (int i = 0; i < candidates.size(); i++) {
        float score = _calculate_score(candidates[i], search_text);
        if (score > highest_score) {
            highest_score = score;
            highest_index = i;
        }
    }

    if (!candidates.is_empty() && cache.has(candidates[highest_index]->path)) {
        return cache[candidates[highest_index]->path];
    }

    return nullptr;
}

void OrchestratorEditorSearchDialog::_update_search_box(bool p_clear, bool p_replace, const String& p_text, bool p_focus) {
    if (p_clear) {
        _search_box->clear();
    } else {
        _search_box->select_all();
    }

    if (p_replace) {
        _search_box->set_text(p_text);
    }

    if (p_focus) {
        _search_box->grab_focus();
    }
}

void OrchestratorEditorSearchDialog::_set_search_item_collapse_state(TreeItem* p_item) {
    if (!_search_box->get_text().is_empty()) {
        p_item->set_collapsed(false);
    } else if (p_item->get_parent()) {
        if (_search_box->get_text().is_empty() && _should_collapse_on_empty_search()) {
            p_item->set_collapsed(true);
            return;
        }

        bool should_collapse = _get_search_item_collapse_suggestion(p_item);

        if (should_collapse && bool(EDITOR_GET("docks/scene_tree/start_create_dialog_fully_expanded"))) {
            should_collapse = false;
        }

        p_item->set_collapsed(should_collapse);
    }
}

void OrchestratorEditorSearchDialog::_load_favorites_and_history() {
    Vector<Ref<SearchItem>> recent_items = _get_recent_items();
    for (const Ref<SearchItem>& item : recent_items) {
        int32_t index = _recent->add_item(item->text, item->icon);
        _recent->set_item_metadata(index, item);
    }

    _favorite_list = _get_favorite_items();
}

void OrchestratorEditorSearchDialog::_save_and_update_favorites_list() {
    _favorites->clear();

    _save_favorite_items(_favorite_list);

    _favorite_list = _get_favorite_items();
    TreeItem* root = _favorites->create_item();
    for (const Ref<SearchItem>& favorite : _favorite_list) {
        TreeItem* item = _favorites->create_item(root);
        item->set_text(0, favorite->text);
        item->set_icon(0, favorite->icon.is_valid() ? favorite->icon : nullptr);
        item->set_meta("__item", favorite);
    }

    emit_signal("favorites_updated");
}

float OrchestratorEditorSearchDialog::_calculate_score(const Ref<SearchItem>& p_item, const String& p_search) const {
    const String text = p_item->text;

    if (text == p_search) {
        // Always favor an exact match (case-sensitive), since clicking a favorite will set search text to type
        return 1.f;
    }

    float inverse_length = 1.f / float(text.length());

    // Favor types where search term is a substring close to the start of the type.
    float w = 0.5f;
    int pos = text.findn(p_search);
    float score = (pos > -1) ? 1.0f - w * MIN(1, 3 * pos * inverse_length) : MAX(0.f, .9f - w);

    // Favor shorter items: they resemble the search term more.
    w = 0.9f;
    score *= (1 - w) + w * MIN(1.0f, p_search.length() * inverse_length);

    score *= _is_preferred(text) ? 1.0f : 0.9f;

    // Add score for being a favorite type
    score *= (_is_favorite(p_item) ? 1.0f : 0.8f);

    // Look through at most 5 recent items
    bool in_recent = false;
    constexpr int RECENT_COMPLETION_SIZE = 5;
    for (int i = 0; i < MIN(RECENT_COMPLETION_SIZE - 1, _recent->get_item_count()); i++) {
        if (_recent->get_item_text(i) == p_item) {
            in_recent = true;
            break;
        }
    }
    score *= in_recent ? 1.f : 0.9f;

    // Significantly drop the item's score if its disabled
    if (p_item->disabled) {
        score *= 0.1f;
    }

    return score;
}

void OrchestratorEditorSearchDialog::_cleanup() {
    _favorite_list.clear();

    if (_favorites) {
        _favorites->clear();
    }

    if (_recent) {
        _recent->clear();
    }
}

void OrchestratorEditorSearchDialog::_select_item(TreeItem* p_item, bool p_center_on_item) {
    if (!p_item) {
        return;
    }

    p_item->select(0);
    _search_options->scroll_to_item(p_item, p_center_on_item);

    Ref<SearchItem> item = p_item->get_meta("__item");

    _favorite->set_disabled(false);
    _favorite->set_pressed(_is_favorite(item));
    get_ok_button()->set_disabled(false);

    _update_help(item);
}

void OrchestratorEditorSearchDialog::_update_search() {
    _search_options->clear();

    TreeItem* hit = _populate_search_results();

    if (_search_box->get_text().is_empty()) {
        _favorite->set_pressed_no_signal(false);
        _search_options->scroll_to_item(_search_options->get_root());
        _search_options->deselect_all();
    } else if (hit) {
        _select_item(hit, true);
    } else {
        _favorite->set_disabled(true);
        _search_options->deselect_all();
        get_ok_button()->set_disabled(true);
    }
}

Ref<OrchestratorEditorSearchDialog::SearchItem> OrchestratorEditorSearchDialog::_get_search_item_by_name(const String& p_name) const {
    for (const Ref<SearchItem>& item : _search_items) {
        if (item->name.match(p_name)) {
            return item;
        }
    }
    return {};
}

PackedStringArray OrchestratorEditorSearchDialog::_read_cache_values(const String& p_section, const String& p_key) const {
    return OrchestratorPlugin::get_singleton()->get_metadata_value(p_section, p_key, PackedStringArray());
}

void OrchestratorEditorSearchDialog::_write_cache_values(const String& p_section, const String& p_key, const PackedStringArray& p_values) {
    OrchestratorPlugin::get_singleton()->set_metadata_value(p_section, p_key, p_values);
}

void OrchestratorEditorSearchDialog::popup_create(bool p_dont_clear, bool p_replace_mode, const String& p_current_type, const String& p_current_name) {
    _search_items = _get_search_items();

    Ref<SearchItem> initial_item = _get_search_item_by_name(p_current_type);
    String search_value = initial_item.is_valid() ? initial_item->text : p_current_type;

    _load_favorites_and_history();

    _update_search_box(!p_dont_clear, p_replace_mode, search_value, true);
    _update_search();

    _save_and_update_favorites_list();

    Rect2 saved_size = PROJECT_GET("dialog_bounds", "create_new_node", Rect2());
    if (saved_size != Rect2()) {
        popup(saved_size);
    } else {
        popup_centered_clamped(Size2(900, 700), 0.8);
    }
}

void OrchestratorEditorSearchDialog::_notification(int p_what) {
    switch (p_what) {
        case NOTIFICATION_ENTER_TREE: {
            HSplitContainer* hsplit_container = memnew(HSplitContainer);
            add_child(hsplit_container);

            VSplitContainer* vsplit_container = memnew(VSplitContainer);
            hsplit_container->add_child(vsplit_container);

            VBoxContainer* fav_vbox = memnew(VBoxContainer);
            fav_vbox->set_custom_minimum_size(Size2(150, 100));
            fav_vbox->set_v_size_flags(Control::SIZE_EXPAND_FILL);
            vsplit_container->add_child(fav_vbox);

            _favorites = memnew(Tree);
            // set_auto_translate_mode
            _favorites->set_hide_root(true);
            _favorites->set_hide_folding(true);
            _favorites->set_allow_reselect(true);
            _favorites->set_focus_mode(Control::FOCUS_NONE);
            _favorites->connect("cell_selected", callable_mp_this(_favorite_selected));
            _favorites->connect(SceneStringName(item_activated), callable_mp_this(_favorite_activated));
            _favorites->add_theme_constant_override("draw_guides", 1);
            SceneUtils::set_theme_type_variation(_favorites, "Tree");
            SceneUtils::add_margin_child(fav_vbox, "Favorites:", _favorites, true);

            VBoxContainer* rec_vbox = memnew(VBoxContainer);
            vsplit_container->add_child(rec_vbox);
            rec_vbox->set_custom_minimum_size(Size2(150, 100));
            rec_vbox->set_v_size_flags(Control::SIZE_EXPAND_FILL);

            _recent = memnew(ItemList);
            // set_auto_translate_mode
            _recent->set_allow_reselect(true);
            _recent->set_focus_mode(Control::FOCUS_NONE);
            _recent->connect(SceneStringName(item_selected), callable_mp_this(_history_selected));
            _recent->connect(SceneStringName(item_activated), callable_mp_this(_history_activated));
            _recent->add_theme_constant_override("draw_guides", 1);
            SceneUtils::set_theme_type_variation(_recent, "ItemList");
            SceneUtils::add_margin_child(rec_vbox, "Recent:", _recent, true);

            VBoxContainer* vbox = memnew(VBoxContainer);
            vbox->set_custom_minimum_size(Size2(300, 0) * EDSCALE);
            vbox->set_h_size_flags(Control::SIZE_EXPAND_FILL);
            hsplit_container->add_child(vbox);

            _search_box = memnew(OrchestratorEditorFilterLineEdit);
            _search_box->connect(SceneStringName(text_changed), callable_mp_this(_search_changed));

            HBoxContainer* search_hbox = memnew(HBoxContainer);
            search_hbox->add_child(_search_box);

            _favorite = memnew(Button);
            _favorite->set_toggle_mode(true);
            _favorite->set_tooltip_text("(Un)favorite selected item.");
            _favorite->set_focus_mode(Control::FOCUS_NONE);
            _favorite->connect(SceneStringName(pressed), callable_mp_this(_favorite_toggled));
            search_hbox->add_child(_favorite);

            const Vector<FilterOption> filters = _get_filters();
            if (!filters.is_empty()) {
                _filters = memnew(OptionButton);
                for (const FilterOption& filter : filters) {
                    _filters->add_item(filter.text, filter.id);
                }

                search_hbox->add_child(_filters);
                _filters->connect(SceneStringName(item_selected), callable_mp_this(_filter_selected));
            }

            SceneUtils::add_margin_child(vbox, "搜索：", search_hbox);

            _search_options = memnew(Tree);
            // set_auto_translate_mode
            _search_options->connect(SceneStringName(item_activated), callable_mp_this(_confirmed));
            _search_options->connect("cell_selected", callable_mp_this(_item_selected));
            SceneUtils::set_theme_type_variation(_search_options, "Tree");
            SceneUtils::add_margin_child(vbox, "匹配项：", _search_options, true);

            _search_box->set_forward_control(_search_options);

            _help_bit = memnew(OrchestratorEditorHelpBit);
            SceneUtils::add_margin_child(vbox, "Description:", _help_bit);

            register_text_enter(_search_box);
            set_hide_on_ok(false);

            connect(SceneStringName(confirmed), callable_mp_this(_confirmed));
            connect(SceneStringName(canceled), callable_mp_this(_canceled));

            _search_box->set_right_icon(SceneUtils::get_editor_icon("Search"));
            _favorite->set_button_icon(SceneUtils::get_editor_icon("Favorites"));

            _update_themes();
            break;
        }
        case NOTIFICATION_EXIT_TREE: {
            disconnect(SceneStringName(confirmed), callable_mp_this(_confirmed));
            disconnect(SceneStringName(canceled), callable_mp_this(_canceled));
            break;
        }
        case NOTIFICATION_READY: {
            if (_filters) {
                _filters->select(_get_default_filter());
            }
            break;
        }
        case NOTIFICATION_VISIBILITY_CHANGED: {
            if (is_visible()) {
                callable_mp_cast(_search_box, Control, grab_focus).call_deferred(false);
                _search_box->select_all();
            }
            break;
        }
        case NOTIFICATION_THEME_CHANGED: {
            _update_themes();
            break;
        }
    }
}

void OrchestratorEditorSearchDialog::_bind_methods() {
    ADD_SIGNAL(MethodInfo("selected"));
    ADD_SIGNAL(MethodInfo("closed"));
}