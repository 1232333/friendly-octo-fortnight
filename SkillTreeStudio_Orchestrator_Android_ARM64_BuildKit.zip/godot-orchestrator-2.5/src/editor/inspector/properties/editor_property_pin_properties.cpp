// This file is part of the Godot Orchestrator project.
//
// Copyright (c) 2023-present Crater Crash Studios LLC and its contributors.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//		http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
#include "editor/inspector/properties/editor_property_pin_properties.h"

#include "common/dictionary_utils.h"
#include "common/macros.h"
#include "common/name_utils.h"
#include "common/property_utils.h"
#include "common/scene_utils.h"
#include "common/variant_utils.h"
#include "core/godot/core_string_names.h"
#include "core/godot/scene_string_names.h"
#include "editor/gui/select_type_dialog.h"
#include "editor/inspector/properties/type_selector.h"

#include <godot_cpp/classes/v_box_container.hpp>

void OrchestratorEditorPropertyPinProperties::_focus_name_field(int p_index) {
    if (p_index < _slots.size()) {
        _slots[p_index].name->grab_focus();
        _slots[p_index].name->select_all();
    }
}

void OrchestratorEditorPropertyPinProperties::_focus_pending_name_field() {
    // Return values use a read-only, fixed name field and are never focused.
    if (_focus_property.is_empty() || !_args) {
        return;
    }

    // Keyed by name rather than index because rearranging reorders the property list.
    for (int index = 0; index < _properties.size(); ++index) {
        if (_properties[index].name == _focus_property) {
            // Deferred because the slot's widgets were only just added to the container.
            callable_mp_this(_focus_name_field).call_deferred(index);
            break;
        }
    }

    _focus_property = StringName();
}

void OrchestratorEditorPropertyPinProperties::_selector_type_changed(const Dictionary& p_property, int p_index) {
    const PropertyInfo property = DictionaryUtils::to_property(p_property);
    _properties.write[p_index].type = property.type;
    _properties.write[p_index].class_name = property.class_name;
    _properties.write[p_index].hint = property.hint;
    _properties.write[p_index].hint_string = property.hint_string;
    _properties.write[p_index].usage = property.usage;
    _set_properties();
}

void OrchestratorEditorPropertyPinProperties::_add_property() {
    PackedStringArray existing_names;
    for (const PropertyInfo& pi : _properties) {
        existing_names.push_back(pi.name);
    }

    PropertyInfo property;
    property.name = NameUtils::create_unique_name(_args ? "NewParam" : "return_value", existing_names);
    property.type = Variant::NIL;
    property.usage = PROPERTY_USAGE_DEFAULT | PROPERTY_USAGE_NIL_IS_VARIANT;
    property.hint = PROPERTY_HINT_NONE;

    _properties.push_back(property);

    _focus_property = property.name;

    _set_properties();
}

void OrchestratorEditorPropertyPinProperties::_rename_property(const String& p_name, int p_index) {
    _properties.write[p_index].name = p_name;
    _set_properties();
}

void OrchestratorEditorPropertyPinProperties::_remove_property(int p_index) {
    emit_signal("remove", p_index);
}

void OrchestratorEditorPropertyPinProperties::_move_up(int p_index) {
    if (p_index > 0) {
        _update_move_buttons(true);
        emit_signal("move_up", p_index);
    }
}

void OrchestratorEditorPropertyPinProperties::_move_down(int p_index) {
    if (p_index < _properties.size()) {
        _update_move_buttons(true);
        emit_signal("move_down", p_index);
    }
}

void OrchestratorEditorPropertyPinProperties::_get_properties() {
    _properties.clear();

    const TypedArray<Dictionary> properties = get_edited_object()->get(get_edited_property());
    for (int index = 0; index < properties.size(); ++index) {
        _properties.push_back(DictionaryUtils::to_property(properties[index]));
    }
}

void OrchestratorEditorPropertyPinProperties::_set_properties() {
    TypedArray<Dictionary> properties;
    for (int index = 0; index < _properties.size(); ++index) {
        properties.push_back(DictionaryUtils::from_property(_properties[index]));
    }
    emit_changed(get_edited_property(), properties);
}

void OrchestratorEditorPropertyPinProperties::_update_pass_by_details(int p_index, const PropertyInfo& p_property) {
    Button* pass_by = cast_to<Button>(_slots[p_index].button_group->get_child(0));
    if (!pass_by) {
        return;
    }

    if (PropertyUtils::is_passed_by_reference(p_property)) {
        pass_by->set_button_icon(SceneUtils::get_icon("CircleReference"));
        pass_by->set_tooltip_text("Passed by reference");
    } else {
        pass_by->set_button_icon(SceneUtils::get_icon("CircleValue"));
        pass_by->set_tooltip_text("Passed by value");
    }
}

void OrchestratorEditorPropertyPinProperties::_update_move_buttons(bool p_force_disable) {
    for (int index = 0; index < _slots.size(); ++index) {
        Button* move_up = cast_to<Button>(_slots[index].button_group->get_child(2));
        Button* move_down = cast_to<Button>(_slots[index].button_group->get_child(3));

        if (_allow_rearrange) {
            move_up->set_disabled(index == 0 || p_force_disable);
            move_down->set_disabled(index == (_slots.size() - 1) || p_force_disable);
        } else {
            move_up->set_disabled(true);
            move_down->set_disabled(true);
        }
    }
}

void OrchestratorEditorPropertyPinProperties::_update_property() {
    _get_properties();

    for (int index = 0; index < _properties.size(); ++index) {
        const PropertyInfo& property = _properties[index];

        String type_name;
        if (property.usage & PROPERTY_USAGE_CLASS_IS_ENUM || property.usage & PROPERTY_USAGE_CLASS_IS_BITFIELD) {
            type_name = property.class_name;
        } else {
            type_name = PropertyUtils::get_property_type_name(property);
        }

        const String friendly_type_name = type_name == "Variant" ? "Any" : type_name;

        if (index >= _slots.size()) {
            Slot new_slot;
            new_slot.name = memnew(LineEdit);
            new_slot.name->set_h_size_flags(SIZE_EXPAND_FILL);
            new_slot.name->connect(SceneStringName(text_changed), callable_mp_this(_rename_property).bind(index));
            new_slot.name->set_editable(!is_read_only());
            add_focusable(new_slot.name);

            new_slot.selector = memnew(OrchestratorEditorTypeSelector);
            new_slot.selector->setup("inspector_property_container", true);
            new_slot.selector->set_property(property);
            new_slot.selector->connect(CoreStringName(changed), callable_mp_this(_selector_type_changed).bind(index));
            new_slot.selector->set_read_only(is_read_only());

            new_slot.button_group = memnew(HBoxContainer);

            Button* pass_by = memnew(Button);
            pass_by->set_flat(true);
            pass_by->set_disabled(false);
            pass_by->set_focus_mode(FOCUS_NONE);
            new_slot.button_group->add_child(pass_by);

            Button* remove = memnew(Button);
            remove->set_button_icon(SceneUtils::get_editor_icon("移除"));
            remove->set_tooltip_text(_args ? "Remove this argument" : "Remove this return value");
            remove->set_disabled(is_read_only());
            remove->connect(SceneStringName(pressed), callable_mp_this(_remove_property).bind(index));
            new_slot.button_group->add_child(remove);

            Button* move_up = memnew(Button);
            move_up->set_button_icon(SceneUtils::get_editor_icon("ArrowUp"));
            move_up->set_tooltip_text(_args ? "Move this argument up" : "Move this return value up");
            move_up->set_disabled(true);
            move_up->connect(SceneStringName(pressed), callable_mp_this(_move_up).bind(index));
            if (!_allow_rearrange) {
                move_up->hide();
            }
            new_slot.button_group->add_child(move_up);

            Button* move_down = memnew(Button);
            move_down->set_button_icon(SceneUtils::get_editor_icon("ArrowDown"));
            move_down->set_tooltip_text(_args ? "Move this argument down" : "Move this return value down");
            move_down->set_disabled(true);
            move_down->connect(SceneStringName(pressed), callable_mp_this(_move_down).bind(index));
            if (!_allow_rearrange) {
                move_down->hide();
            }
            new_slot.button_group->add_child(move_down);

            _container->add_child(new_slot.name);
            _container->add_child(new_slot.selector);
            _container->add_child(new_slot.button_group);

            _slots.push_back(new_slot);
        }

        if (_slots[index].name->has_focus()) {
            continue;
        }

        if (!_args) {
            _slots[index].name->set_text("Return Value");
            _slots[index].name->set_editable(false);
        }
        else {
            _slots[index].name->set_text(property.name);
        }

        _update_pass_by_details(index, property);
    }

    while (_slots.size() > _properties.size()) {
        // Cleanup grid container
        for (int i = 0; i < _container->get_columns(); i++) {
            Node* child = _container->get_child(_container->get_child_count() - 1);
            _container->remove_child(child);
            child->queue_free();
        }
        _slots.remove_at(_slots.size() - 1);
    }

    _add_button->set_disabled(_properties.size() == _max_entries || is_read_only());
    _update_move_buttons();

    _focus_pending_name_field();
}

void OrchestratorEditorPropertyPinProperties::setup(bool p_inputs, int p_max_entries) {
    _args = p_inputs;
    _max_entries = p_max_entries;
}

void OrchestratorEditorPropertyPinProperties::_notification(int p_what) {
    switch (p_what) {
        case NOTIFICATION_READY: {
            _margin = memnew(MarginContainer);
            _margin->set_theme_type_variation("MarginContainer4px");
            set_bottom_editor(_margin);
            add_child(_margin);

            _container = memnew(GridContainer);
            _container->set_columns(3);
            _container->add_theme_constant_override("separation", 5);

            VBoxContainer* outer = memnew(VBoxContainer);
            outer->add_theme_constant_override("separation", 5);
            outer->add_child(_container);

            _add_button = memnew(Button);
            _add_button->set_button_icon(SceneUtils::get_editor_icon("Add"));
            _add_button->set_text(vformat("Add %s", get_label()));
            _add_button->set_theme_type_variation("InspectorActionButton");
            _add_button->set_h_size_flags(SIZE_SHRINK_CENTER);
            _add_button->set_focus_mode(FOCUS_NONE);
            _add_button->set_disabled(is_read_only());
            _add_button->connect(SceneStringName(pressed), callable_mp_this(_add_property));
            outer->add_child(_add_button);

            _margin->add_child(outer);

            break;
        }
    }
}

void OrchestratorEditorPropertyPinProperties::_bind_methods() {
    ADD_SIGNAL(MethodInfo("move_up", PropertyInfo(Variant::INT, "index")));
    ADD_SIGNAL(MethodInfo("move_down", PropertyInfo(Variant::INT, "index")));
    ADD_SIGNAL(MethodInfo("remove", PropertyInfo(Variant::INT, "index")));
}