# Skill Tree Studio + Orchestrator：Android ARM64 编辑器构建包

本包把 Orchestrator 2.5.1-rc2 源码、Skill Tree Studio 插件源码和 Android ARM64 Editor 自动构建工作流放在一起。

## 当前包里有什么

- `project/addons/orchestrator/`：Orchestrator 2.5.1-rc2 插件资源与 GDExtension 描述文件。
- `project/addons/skill_tree_editor/`：Skill Tree Studio 1.6.5 源码（来自本次提供的 TypeInferenceFix 包）。
- `.github/workflows/android-arm64-editor.yml`：手动触发的 Android ARM64 Editor 构建工作流。
- `.github/actions/orchestrator-build/`：Orchestrator 上游构建动作。

## 如何拿到真正编译的 Android 文件

1. 把本目录全部内容上传到一个新的 GitHub 仓库（不要只上传 `project/` 子目录）。
2. 打开仓库的 **Actions** 页面。
3. 选择 **Build Android ARM64 Editor Extension**。
4. 点击 **Run workflow**，等待任务完成。
5. 在任务的 Artifacts 下载 `*-plugin-android-arm64-editor`。
6. 解压后，确认 `addons/orchestrator/liborchestrator.android.64.editor.so` 存在。

工作流会自动获取 Godot 4.7 与 godot-cpp 4.7 依赖，并按 Orchestrator 2.5.x 的 Android ARM64 Editor preset 构建。该 `.so` 对应 Godot Android 编辑器扩展，不是 Android 游戏导出模板库。

## 兼容性与边界

- Orchestrator 2.5.x 对应 Godot 4.7.x；本构建配置按 Godot 4.7 分支准备。
- 本工作流会编译 Orchestrator 原生扩展，并把 Skill Tree Studio 插件源码一起放入产物。
- **这不等于 Orchestrator 已经接管 Skill Tree Studio 的蓝图执行器。** 当前 Skill Tree Studio 仍保留自己的蓝图编辑器/执行器；真正的 Orchestrator 图编辑器适配、节点 API 桥接、运行时 Host 和全量中文翻译仍需后续开发与 Godot 真机验证。
- 当前执行环境没有 Godot、Android SDK/NDK、SCons 和完整子模块，因此这里没有伪造 `.so`，也没有声称本地编译或真机测试成功。

## 中文用语方向

后续界面本地化按中文软件习惯统一：
- Blueprint → 蓝图
- Graph / Graph Editor → 节点图 / 节点图编辑器
- Node → 节点
- Pin → 引脚
- Reroute → 转接点
- Breakpoint → 断点
- Watch → 监视
- Compile → 编译
- Build Error → 构建错误
- Execution Flow → 执行流程
- Variable → 变量
- Function → 函数

错误提示优先使用可行动的口语，例如“还没有连接前置节点”“这个节点缺少必填参数”，避免生硬直译。

## 许可

Orchestrator 源码及其 Apache-2.0 许可文件随包保留。请保留上游版权与许可声明；不要把上游独立保留权利的 Logo 当作本项目自有素材。
