// This file is part of the Godot Orchestrator project.
//
// Copyright (c) 2023-present Crater Crash Studios LLC and its contributors.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//		http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
#include "extension_interface.h"

#include "api/extension_db.h"
#include "common/guid.h"
#include "core/register_core_types.h"
#include "editor/register_editor_types.h"
#include "orchestration/register_orchestration_types.h"
#include "script/register_script_types.h"

#include <gdextension_interface.h>
#include <godot_cpp/core/defs.hpp>
#include <godot_cpp/godot.hpp>

using namespace godot;

namespace orchestrator {
    void initialize_extension_module(ModuleInitializationLevel p_level) {
        if (p_level == MODULE_INITIALIZATION_LEVEL_CORE) {
            ExtensionDB::create();
            register_core_singletons();
        }
        if (p_level == MODULE_INITIALIZATION_LEVEL_SERVERS) {
            register_orchestration_types();
            register_script_types();
        }
        if (p_level == MODULE_INITIALIZATION_LEVEL_SCENE) {
            register_script_extension();
            register_script_resource_formats();
            register_orchestration_node_types();

            create_core_singletons();
        }
        if (p_level == MODULE_INITIALIZATION_LEVEL_EDITOR) {
            register_orchestration_editor_types();
            register_editor_types();
        }
    }

    void uninitialize_extension_module(ModuleInitializationLevel p_level) {
        if (p_level == MODULE_INITIALIZATION_LEVEL_EDITOR) {
            unregister_editor_types();
            unregister_orchestration_editor_types();
        }
        if (p_level == MODULE_INITIALIZATION_LEVEL_SCENE) {
            unregister_orchestration_node_types();
            unregister_script_extension();
        }
        if (p_level == MODULE_INITIALIZATION_LEVEL_SERVERS) {
            unregister_script_resource_formats();
            unregister_script_types();
            unregister_orchestration_types();
            destroy_core_singletons();
        }
        if (p_level == MODULE_INITIALIZATION_LEVEL_CORE) {
            unregister_core_singletons();

            ExtensionDB::destroy();
            Guid::cleanup();
        }
    }

    extern "C" {
        GDExtensionBool GDE_EXPORT extension_library_init(GDExtensionInterfaceGetProcAddress p_get_proc_address,
                                                          GDExtensionClassLibraryPtr p_library,
                                                          GDExtensionInitialization* r_initialization) {
            GDExtensionBinding::InitObject init_obj(p_get_proc_address, p_library, r_initialization);
            init_obj.register_initializer(initialize_extension_module);
            init_obj.register_terminator(uninitialize_extension_module);
            init_obj.set_minimum_library_initialization_level(MODULE_INITIALIZATION_LEVEL_CORE);
            return init_obj.init();
        }
    }
}
