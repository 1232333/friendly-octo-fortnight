// This file is part of the Godot Orchestrator project.
//
// Copyright (c) 2023-present Crater Crash Studios LLC and its contributors.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//		http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
#include "editor/inspector/variable_inspector_plugin.h"

#include "common/macros.h"
#include "editor/inspector/properties/editor_property_type.h"
#include "orchestration/variable.h"

#include <godot_cpp/classes/editor_interface.hpp>

class OScriptVariableConstraintProvider : public OrchestratorEditorTypeConstraintProvider {
    Ref<OScriptVariable> _variable;

public:
    bool is_type_locked() const override {
        if (_variable.is_valid()) {
            const Variant value = _variable->get_default_value();
            switch (value.get_type()) {
                case Variant::ARRAY: {
                    const Array& array = value;
                    return !array.is_empty();
                }
                case Variant::DICTIONARY: {
                    const Dictionary& dictionary = value;
                    return !dictionary.is_empty();
                }
                default: {
                    break;
                }
            }
        }
        return false;
    }

    PackedStringArray get_exclusions() const override {
        return {};
    }

    Object* get_constraint_source() const override {
        return _variable.ptr();
    }

    explicit OScriptVariableConstraintProvider(const Ref<OScriptVariable>& p_variable)
        : _variable(p_variable) {}
};

bool OrchestratorEditorInspectorPluginVariable::_can_handle(Object* p_object) const {
    return p_object && p_object->get_class() == OScriptVariable::get_class_static();
}

bool OrchestratorEditorInspectorPluginVariable::_parse_property(Object* p_object, Variant::Type p_type, const String& p_name,
    PropertyHint p_hint, const String& p_hint_string, BitField<PropertyUsageFlags> p_usage, bool p_wide) {

    const Ref<OScriptVariable> variable = cast_to<OScriptVariable>(p_object);
    if (variable.is_null()) {
        return false;
    }

    if (p_name.match("info")) {
        OrchestratorEditorPropertyType* editor = memnew(OrchestratorEditorPropertyType);
        editor->setup("variable_type", true);
        editor->set_constraint_provider(std::make_unique<OScriptVariableConstraintProvider>(variable));
        add_property_editor(p_name, editor, true, "Variable Type");
        return true;
    }

    return false;
}
