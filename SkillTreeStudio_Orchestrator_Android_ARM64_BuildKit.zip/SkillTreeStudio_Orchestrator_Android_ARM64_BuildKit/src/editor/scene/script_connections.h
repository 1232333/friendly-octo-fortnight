// This file is part of the Godot Orchestrator project.
//
// Copyright (c) 2023-present Crater Crash Studios LLC and its contributors.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//		http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
#pragma once

#include <godot_cpp/classes/accept_dialog.hpp>

using namespace godot;

/// Forward declarations
namespace godot {
    class Tree;
}

/// A dialog that displays the script's active connections.
class OrchestratorScriptConnectionsDialog : public AcceptDialog {
    GDCLASS(OrchestratorScriptConnectionsDialog, AcceptDialog);

    Label* _method = nullptr;
    Tree* _tree = nullptr;

protected:
    static void _bind_methods() { }

    //~ Begin Wrapped Interface
    void _notification(int p_what);
    //~ End Wrapped Interface

    /// Dispatched when the user confirmed the dialog
    void _confirmed();

public:
    /// Popup and open the dialog
    /// @param p_method the method name
    /// @param p_nodes the nodes associated with the script
    void popup_connections(const String& p_method, const Vector<Node*>& p_nodes);

    OrchestratorScriptConnectionsDialog() = default;
};
