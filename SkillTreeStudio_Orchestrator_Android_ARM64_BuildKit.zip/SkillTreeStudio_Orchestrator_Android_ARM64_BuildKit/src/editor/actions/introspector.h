// This file is part of the Godot Orchestrator project.
//
// Copyright (c) 2023-present Crater Crash Studios LLC and its contributors.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//		http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
#pragma once

#include "api/extension_db.h"
#include "editor/actions/definition.h"
#include "orchestration/node.h"
#include "script/script_server.h"

/// A standalone component that is responsible for being able to read and generate a set of actions based on
/// provided class, object, or script metadata. It also can provide actions based on the visual scripting
/// language, built-in Godot types, and project configured autoloads.
class OrchestratorEditorIntrospector {

    using ActionBuilder = OrchestratorEditorActionBuilder;
    using Action = OrchestratorEditorActionDefinition;
    using ActionComparator = OrchestratorEditorActionDefinitionComparator;
    using ActionType = Action::ActionType;
    using GraphType = Action::GraphType;
    using ActionSet = OrchestratorEditorActionSet;

    template <typename T>
    static ActionBuilder _script_node_builder(const String& p_category, const String& p_name, const Dictionary& p_data = Dictionary())
    { return _script_node_builder(T::get_class_static(), p_category, p_name, p_data); }

    static ActionBuilder _script_node_builder(const String& p_node_type, const String& p_category, const String& p_name, const Dictionary& p_data = Dictionary());
    static void _create_categories_from_path(ActionSet& r_actions, const String& p_category_path, const String& p_icon = String());
    static PackedStringArray _get_native_class_hierarchy(const String& p_class_name);

    static String _get_type_icon(Variant::Type p_type);
    static String _get_type_name(Variant::Type p_type);
    static String _get_method_icon_name(const MethodInfo& p_method);
    static String _get_builtin_function_category_from_godot_category(const FunctionInfo& p_function_info);
    static PackedStringArray _build_member_keywords(const String& p_name, const String& p_class_name);
    static void _get_actions_for_class(const String& p_class_name, const String& p_category_name, const TypedArray<Dictionary>& p_methods, const TypedArray<Dictionary>& p_properties, const TypedArray<Dictionary>& p_signals, ActionSet& r_actions);
    static void _get_actions_for_named_class(const String& p_class_name, ActionSet& r_actions);
    static void _get_actions_for_global_class(const ScriptServer::GlobalClass& p_global_class, ActionSet& r_actions);

    static void _apply_method_overrides(const String& p_class_name, MethodInfo& r_method);

    static Ref<Action> _create_static_function_action(const String& p_category, const String& p_name, const String& p_class_name, const MethodInfo& p_method, const PackedStringArray& p_extra_keywords = PackedStringArray());
    static void _register_static_methods(const String& p_lookup_class, const String& p_register_class, const String& p_category, ActionSet& r_actions);
    static void _register_global_class_static_methods(const ScriptServer::GlobalClass& p_global_class, const String& p_category, ActionSet& r_actions);

    static void _register_constant(const String& p_node_type, const String& p_category, const String& p_owner, const String& p_constant_name, const Variant& p_value, const Dictionary& p_data, ActionSet& r_actions);
    static void _register_class_constants(const String& p_class_name, ActionSet& r_actions);

public:

    // registrar.filter->target_object->get_target()
    static void generate_actions_from_object(Object* p_object, ActionSet& r_actions);
    // registrar.filter->target_classes()
    static void generate_actions_from_classes(const PackedStringArray& p_class_names, ActionSet& r_actions);
    // No specific registrar filter
    static void generate_actions_from_class(const StringName& p_class_name, ActionSet& r_actions);
    static void generate_actions_from_script(const Ref<Script>& p_script, ActionSet& r_actions);

    static void generate_actions_from_script_nodes(ActionSet& r_actions);
    static void generate_actions_from_variant_types(ActionSet& r_actions);
    static void generate_actions_from_builtin_functions(ActionSet& r_actions);
    static void generate_actions_from_autoloads(ActionSet& r_actions);
    static void generate_actions_from_native_classes(ActionSet& r_actions);
    static void generate_actions_from_script_global_classes(ActionSet& r_actions);

    static Vector<Ref<Action>> generate_actions_from_category(const String& p_category, const String& p_icon = String());

    static void free_resources();
};
