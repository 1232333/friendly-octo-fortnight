// This file is part of the Godot Orchestrator project.
//
// Copyright (c) 2023-present Crater Crash Studios LLC and its contributors.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//		http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
#pragma once

#include <godot_cpp/classes/button.hpp>
#include <godot_cpp/classes/label.hpp>
#include <godot_cpp/classes/v_box_container.hpp>

using namespace godot;

/// Simple landing page that is shown when the user has no open orchestrations
class OrchestratorGettingStarted : public VBoxContainer {
    GDCLASS(OrchestratorGettingStarted, VBoxContainer);

    Button* _create_script = nullptr;
    Button* _open_script = nullptr;
    Button* _open_docs = nullptr;
    Label* _plugin_version = nullptr;

    //~ Begin Signal Handlers
    void _create_new() { emit_signal("create_requested"); }
    void _open() { emit_signal("open_requested"); }
    void _show_docs() { emit_signal("documentation_requested"); }
    //~ End Signal Handlers

protected:
    static void _bind_methods();

    //~ Begin Wrapped Interface
    void _notification(int p_what);
    //~ End Wrapped Interface

public:
    OrchestratorGettingStarted();
};
