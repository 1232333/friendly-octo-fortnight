// This file is part of the Godot Orchestrator project.
//
// Copyright (c) 2023-present Crater Crash Studios LLC and its contributors.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//		http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
#include "common/os_utils.h"

#include <godot_cpp/classes/os.hpp>

using namespace godot;

namespace OSUtils {
    bool prefer_meta_over_ctrl() {
        OS* os = OS::get_singleton();
        return os->has_feature("macos") || os->has_feature("web_macos") || os->has_feature("web_ios");
    }
}