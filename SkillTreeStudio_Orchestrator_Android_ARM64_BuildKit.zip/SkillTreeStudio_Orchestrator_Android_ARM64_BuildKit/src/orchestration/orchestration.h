// This file is part of the Godot Orchestrator project.
//
// Copyright (c) 2023-present Crater Crash Studios LLC and its contributors.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//		http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
#pragma once

#include "orchestration/connection.h"
#include "orchestration/function.h"
#include "orchestration/graph.h"
#include "orchestration/node.h"
#include "orchestration/signals.h"
#include "orchestration/variable.h"

#include <godot_cpp/classes/texture2d.hpp>
#include <godot_cpp/templates/rb_set.hpp>

using namespace godot;

/// Defines different types of orchestrations
enum OrchestrationType {
    OT_Script  //! An orchestration that acts as a Godot script
};

VARIANT_ENUM_CAST(OrchestrationType);

/// Forward declarations
class OrchestrationBinaryParser;
class OrchestrationTextParser;
class OScriptCache;
class OScript;

/// The common contract for different types of Orchestration resources.
///
/// Different resource types can implement this interface in order to act like an Orchestration.  This
/// permits Godot Script types or other Resource types (such as libraries) to act like an Orchestration
/// to share common behavior without needing to duplicate behavior.
///
/// This also allows the existing Orchestrator file format to be used without changing the data layout.
///
/// todo: rename OSciptXxX sub-resources to OrchestrationXXX sub-resources
///
class Orchestration : public Resource {
    GDCLASS(Orchestration, Resource);

    friend class OScriptGraph;
    friend class OrchestrationBinaryParser;
    friend class OrchestrationTextParser;
    friend class OScriptCache;
    friend class OScriptLanguage;

    // Utility struct that maintains the connections and auxillery lookups
    struct ConnectionCache {
    private:
        // All connections
        RBSet<OScriptConnection> _connections;
        // Connections [to_node,to_port] to [from_node,from_port]
        mutable HashMap<uint32_t, Vector<uint32_t>> _input_connections;
        // Connections [from_node,from_port] to [to_node,to_port]
        mutable HashMap<uint32_t, Vector<uint32_t>> _output_connections;
        mutable bool _dirty = false;

        void _rebuild() const;

    public:
        static uint32_t key(int p_node_id, int p_pin_index);
        static int node_from_key(uint32_t p_key);
        static int pin_index_from_key(uint32_t p_key);

        bool has(const OScriptConnection& p_connection) const { return _connections.has(p_connection); }

        void insert(const OScriptConnection& p_connection) { _connections.insert(p_connection); _dirty = true; }
        void erase(const OScriptConnection& p_connection) { _connections.erase(p_connection); _dirty = true; }
        void clear() { _connections.clear(); _dirty = true; }

        const RBSet<OScriptConnection>& all() const { return _connections; }
        const Vector<uint32_t>* inputs(uint32_t p_key) const { _rebuild(); return _input_connections.getptr(p_key); }
        const Vector<uint32_t>* outputs(uint32_t p_key) const { _rebuild(); return _output_connections.getptr(p_key); }
    };

    OrchestrationType _type;                               //! The orchestration type
    bool _initialized{ false };                            //! Whether the orchestration is initialized
    bool _edited{ false };                                 //! Tracks whether the orchestration has been edited
    bool _tool{ false };
    StringName _base_type;                                 //! The base type of the orchestration
    StringName _global_name;                               //! Global class name for script, e.g. `class_name`
    String _icon_path;                                     //! Path to script's custom icon, e.g. `@icon`
    ConnectionCache _connection_cache;                     //! Connections plus a lazily-built adjacency index
    HashMap<int, Ref<OScriptNode>> _nodes;                 //! Map of all nodes within this orchestration
    HashMap<StringName, Ref<OScriptFunction>> _functions;  //! Map of all orchestration functions
    HashMap<StringName, Ref<OScriptVariable>> _variables;  //! Map of all orchestration variables
    HashMap<StringName, Ref<OScriptSignal>> _signals;      //! Map of all user-defined signals
    HashMap<StringName, Ref<OScriptGraph>> _graphs;        //! Map of all defined graphs
    Resource* _self;                                       //! Reference to the outer resource type
    uint32_t _version{ 0 };                                //! Orchestration version
    String _brief_description;                             //! Brief description
    String _description;                                   //! Full description
    String _script_path;

protected:
    static void _bind_methods();

    //~ Begin Serialization Interface
    TypedArray<OScriptNode> _get_nodes_internal() const;
    void _set_nodes_internal(const TypedArray<OScriptNode>& p_nodes);
    TypedArray<int> _get_connections_internal() const;
    void _set_connections_internal(const TypedArray<int>& p_connections);
    TypedArray<OScriptGraph> _get_graphs_internal() const;
    void _set_graphs_internal(const TypedArray<OScriptGraph>& p_graphs);
    TypedArray<OScriptFunction> _get_functions_internal() const;
    void _set_functions_internal(const TypedArray<OScriptFunction>& p_functions);
    TypedArray<OScriptVariable> _get_variables_internal() const;
    void _set_variables_internal(const TypedArray<OScriptVariable>& p_variables);
    TypedArray<OScriptSignal> _get_signals_internal() const;
    void _set_signals_internal(const TypedArray<OScriptSignal>& p_signals);
    //~ End Serialization Interface

    /// Fixes any potential orphan nodes in the script
    /// @note This should generally not be an issue, except during development, but its a great sanity check
    virtual void _fix_orphans();

    /// Removes event nodes that share a function with another event node, or whose function no longer
    /// exists, as written by 2.4.x and 2.5.x.
    /// @note Ships in 2.4, 2.5 and 2.6; remove once support for 2.4 and 2.5 is dropped.
    void _fix_duplicate_event_nodes();

    /// Get whether there are any instances of this orchestration
    /// @return true if there are existing instances, false otherwise
    virtual bool _has_instances() const { return false; }

    //~ Begin Internal Connection API
    void _connect_nodes(int p_source_id, int p_source_port, int p_target_id, int p_target_port);
    void _disconnect_nodes(int p_source_id, int p_source_port, int p_target_id, int p_target_port);
    //~ End Internal Connection API

    /// Get all unique node ids for a specific node type
    /// @tparam T the node type
    /// @return a list of node unique IDs
    template <typename T>
    List<int> _get_node_type_node_ids() {
        List<int> ids;
        for (const KeyValue<int, Ref<OScriptNode>>& E : _nodes)
        {
            if (T* ptr = Object::cast_to<T>(E.value.ptr()))
                ids.push_back(ptr->get_id());
        }
        return ids;
    }

    void _update_all_self_nodes();

public:
    /// Get the orchestration type
    /// @return the orchestration type
    OrchestrationType get_type() const { return _type; }

    /// Get the path to the orchestration resource
    /// @return the file path
    String get_orchestration_path() const;

    /// Gets the instance class type of the script
    /// @returns <code>global_name</code> if set, otherwise <code>base_type</code>.
    StringName get_instance_class_type() const;

    /// Get the base type of the orchestration
    /// @return base class type of the orchestration
    StringName get_base_type() const;

    /// Set the base class type
    /// @param p_base_type the base type class name
    void set_base_type(const StringName& p_base_type);

    /// Get whether the orchestration runs in tool-mode
    /// @return true if the orchestration runs in tool-mode in the editor, false otherwise
    virtual bool get_tool() const;

    /// Set whether the orchestration runs in tool-mode
    /// @param p_tool true to run in the editor in tool-mode, false to run only at run-time
    virtual void set_tool(bool p_tool);

    /// Get the global class name assigned to the orchestration
    /// @return the global class name
    StringName get_global_name() const;

    /// Sets the global class name assigned to the orchestration
    /// @param p_global_name the script global class name
    void set_global_name(const StringName& p_global_name);

    /// Get the icon associated with the script class
    /// @return the icon path
    String get_icon_path() const;

    /// Get the icon associated with the script class
    /// @param p_path the script class icon
    void set_icon_path(const String& p_path);

    /// Gets the icon texture for the class
    /// @return the icon texture
    Ref<Texture2D> get_icon() const;

    /// Gets the icon name for the class
    /// @return the icon name
    String get_icon_name() const;

    /// Get the script's brief description
    /// @return the brief description
    String get_brief_description() const;

    /// Set the script's brief description
    /// @param p_brief_description the brief description
    void set_brief_description(const String& p_brief_description);

    /// Get the script's full description
    /// @return the full description
    String get_description() const;

    /// Sets the script full description
    /// @param p_description the full description
    void set_description(const String& p_description);

    /// Get a pointer to the underlying owning resource of the orchestration
    /// @return the owning resource, use with caution
    virtual Ref<Resource> get_self() const { return _self; }
    Ref<OScript> as_script();

    // Helper method
    void mark_dirty();

    void set_self(Resource* p_self);

    /// Get a pointer to this orchestration
    /// @return the orchestration
    virtual Orchestration* get_orchestration() { return this; }

    /// Get the next available node unique ID
    /// @return the next node unique ID
    int get_available_id() const;

    /// Check whether the orchestration is edited
    /// @return true if the orchestration was edited, false otherwise
    bool is_edited() const { return _edited; }

    /// Sets the orchestration as edited
    /// @param p_edited true if the orchestration was edited, false otherwise
    void set_edited(bool p_edited);

    /// Performs post initialization/load steps
    virtual void post_initialize();

    //~ Begin Node Interface
    void add_node(const Ref<OScriptGraph>& p_graph, const Ref<OScriptNode>& p_node);
    void remove_node(int p_node_id);
    /// @deprecated use OScriptGraph::has_node
    Ref<OScriptNode> get_node(int p_node_id) const;
    Vector<Ref<OScriptNode>> get_nodes() const;
    //~ End Node Interface

    //~ Begin Connection Interface
    const RBSet<OScriptConnection>& get_connections() const;
    /// @deprecated use OScriptGraph::unlink
    /// @note this method was left because OScriptNodePin needs this due to an order of operations issue
    void disconnect_nodes(int p_source_id, int p_source_port, int p_target_id, int p_target_port);
    Vector<Ref<OScriptNodePin>> get_connections(const OScriptNodePin* p_pin) const;
    void adjust_connections(const OScriptNode* p_node, int p_offset, int p_adjustment, EPinDirection p_dir = PD_MAX);
    /// Returns whether the pin has at least one connection, without resolving endpoint pins.
    bool has_connections(const OScriptNodePin* p_pin) const;
    /// Returns the sole connected pin, or an invalid reference when there are zero or more than one.
    /// Avoids materializing the full connection vector when callers only need a single endpoint.
    Ref<OScriptNodePin> get_single_connection(const OScriptNodePin* p_pin) const;
    //~ End Connection Interface

    //~ Begin Graph Interface
    bool has_graph(const StringName& p_name) const;
    Ref<OScriptGraph> create_graph(const StringName& p_name, int p_flags = 0);
    void remove_graph(const StringName& p_name);
    Ref<OScriptGraph> get_graph(const StringName& p_name) const;
    Ref<OScriptGraph> find_graph(const StringName& p_name) const;
    Ref<OScriptGraph> find_graph(const Ref<OScriptNode>& p_node) const;
    bool rename_graph(const StringName& p_old_name, const StringName& p_new_name);
    Vector<Ref<OScriptGraph>> get_graphs() const;
    PackedStringArray get_graph_names() const;
    //~ End Graph Interface

    //~ Begin Function API
    bool has_function(const StringName& p_name) const;
    Ref<OScriptFunction> create_function(const StringName& p_name, bool p_has_return);
    Ref<OScriptFunction> create_function(const MethodInfo& p_method, bool p_user_defined = false);
    Ref<OScriptFunction> create_function(const MethodInfo& p_method, int p_node_id, bool p_user_defined = false);
    Ref<OScriptFunction> duplicate_function(const StringName& p_name, bool p_include_code);
    Dictionary export_function(const StringName& p_name) const;
    Ref<OScriptFunction> import_function(const Dictionary& p_data, const StringName& p_name);
    bool import_function_body(const StringName& p_name, const Dictionary& p_graph_data);
    void remove_function(const StringName& p_name);
    Ref<OScriptFunction> find_function(const StringName& p_name) const;
    Ref<OScriptFunction> find_function(const Guid& p_guid) const;
    bool rename_function(const StringName& p_old_name, const StringName& p_new_name);
    PackedStringArray get_function_names() const;
    int get_function_node_id(const StringName& p_name) const;
    Vector<Ref<OScriptFunction>> get_functions() const;
    bool is_function_override(const StringName& p_name);
    //~ End Function Interface

    //~ Begin Variable Interface
    bool has_variable(const StringName& p_name) const;
    Ref<OScriptVariable> create_variable(const StringName& p_name, Variant::Type p_type = Variant::NIL);
    Ref<OScriptVariable> duplicate_variable(const StringName& p_name);
    void remove_variable(const StringName& p_name);
    Ref<OScriptVariable> get_variable(const StringName& p_name);
    bool rename_variable(const StringName& p_old_name, const StringName& p_new_name);
    Vector<Ref<OScriptVariable>> get_variables() const;
    PackedStringArray get_variable_names() const;
    bool can_remove_variable(const StringName& p_name) const;
    Ref<OScriptVariable> promote_to_variable(const Ref<OScriptNodePin>& p_pin);
    //~ End Variable Interface

    //~ Begin Signals Interface
    bool has_custom_signal(const StringName& p_name) const;
    Ref<OScriptSignal> create_custom_signal(const StringName& p_name);
    void remove_custom_signal(const StringName& p_name);
    Ref<OScriptSignal> get_custom_signal(const StringName& p_name);
    Ref<OScriptSignal> find_custom_signal(const StringName& p_name) const;
    bool rename_custom_user_signal(const StringName& p_old_name, const StringName& p_new_name);
    Vector<Ref<OScriptSignal>> get_custom_signals() const;
    PackedStringArray get_custom_signal_names() const;
    //~ End Signals Interface

    void copy_state(const Ref<Orchestration>& p_other);

    Orchestration();
    ~Orchestration() override = default;
};
