// This file is part of the Godot Orchestrator project.
//
// Copyright (c) 2023-present Crater Crash Studios LLC and its contributors.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//		http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
#include "orchestration/graph.h"

#include "common/resource_utils.h"
#include "orchestration/nodes.h"
#include "orchestration/orchestration.h"
#include "orchestration/serialization/format.h"

#include <godot_cpp/variant/utility_functions.hpp>
#include <godot_cpp/templates/hash_set.hpp>

TypedArray<int> OScriptGraph::_get_nodes() const {
    TypedArray<int> nodes;
    for (const int &node_id : _nodes) {
        nodes.push_back(node_id);
    }
    return nodes;
}

void OScriptGraph::_set_nodes(const TypedArray<int>& p_nodes) {
    _nodes.clear();
    for (uint32_t i = 0; i < p_nodes.size(); i++) {
        _nodes.insert(p_nodes[i]);
    }
    emit_changed();
}

TypedArray<Dictionary> OScriptGraph::_get_knots() const {
    TypedArray<Dictionary> results;
    for (const KeyValue<uint64_t, PackedVector2Array>& E : _knots) {
        Dictionary data;
        data["id"] = E.key;
        data["points"] = E.value;
        results.push_back(data);
    }
    return results;
}

void OScriptGraph::_set_knots(const TypedArray<Dictionary>& p_knots) {
    _knots.clear();
    for (uint32_t i = 0; i < p_knots.size(); i++) {
        const Dictionary& data = p_knots[i];
        const uint64_t id = data["id"];
        const PackedVector2Array points = data["points"];
        _knots[id] = points;
    }
}

TypedArray<int> OScriptGraph::_get_functions() const {
    TypedArray<int> functions;
    for (const int &function_node_id : _functions) {
        functions.push_back(function_node_id);
    }
    return functions;
}

void OScriptGraph::_set_functions(const TypedArray<int>& p_functions) {
    _functions.clear();
    for (uint32_t i = 0; i < p_functions.size(); i++) {
        _functions.insert(p_functions[i]);
    }
    emit_changed();
}

void OScriptGraph::_initialize_node(const Ref<OScriptNode>& p_node, const OScriptNodeInitContext& p_context, const Vector2& p_position) {
    // Configured first so that initialize, and every override it runs through, sees the node's state.
    p_node->configure(p_context);
    p_node->initialize(p_context);

    if (p_position != Vector2()) {
        p_node->set_position(p_position);
    }

    _orchestration->add_node(this, p_node);
    p_node->post_placed_new_node();

    // todo: the _orchestration->add_node calls this !?!?
    // add_node(p_node);
}

void OScriptGraph::_remove_node(int p_node_id) {
    _nodes.erase(p_node_id);

    HashSet<uint64_t> connection_ids;
    for (const KeyValue<uint64_t, PackedVector2Array>& E : _knots) {
        OScriptConnection C(E.key);
        if (C.is_linked_to(p_node_id)) {
            connection_ids.insert(C.id);
        }
    }

    if (!connection_ids.is_empty()) {
        for (const uint64_t& connection_id : connection_ids) {
            _knots.erase(connection_id);
        }
        emit_signal("knots_updated");
    }

    if (_functions.has(p_node_id)) {
        _functions.erase(p_node_id);
    }

    emit_signal("node_removed", p_node_id);
}

void OScriptGraph::post_initialize() {
    // OScriptNodeEvent nodes were not being registered with OScriptGraph properly for overrides
    for (const int node_id : _nodes) {
        Ref<OScriptNodeEvent> event = _orchestration->get_node(node_id);
        if (event.is_valid() && !_functions.has(node_id)) {
            WARN_PRINT(vformat(
                "Script '%s': Migrating registration in graph %s for node ID %d.",
                _orchestration->get_orchestration_path(), get_graph_name(), node_id));

            _functions.insert(node_id);
        }
    }

    // Fixup and function node references that are invalid
    RBSet<int>::Iterator iterator = _functions.begin();
    while (iterator != _functions.end()) {
        const int function_id = *iterator;
        if (!_orchestration->_nodes.has(function_id)) {
            WARN_PRINT(vformat(
                "Script '%s': Removed orphan function reference found in graph %s for node ID %d.",
                _orchestration->get_orchestration_path(), get_graph_name(), function_id));

            _functions.erase(function_id);
        }
        ++iterator;
    }
}

void OScriptGraph::_upgrade(uint32_t p_old_version, uint32_t p_new_version) {
    // Version 4: migrate knots to reroute nodes
    if (p_old_version < 4 && !_knots.is_empty()) {
        for (const KeyValue<uint64_t, PackedVector2Array>& E : _knots) {
            const OScriptConnection conn(E.key);
            const PackedVector2Array& positions = E.value;

            if (positions.is_empty()) {
                continue;
            }

            // Determine the type of the original connection (execution vs data)
            OScriptNodeReroute::ERerouteType conn_type = OScriptNodeReroute::REROUTE_ANY;
            {
                const Ref<OScriptNode> src_node = _orchestration->get_node(conn.from_node);
                if (src_node.is_valid()) {
                    const Ref<OScriptNodePin> src_pin = src_node->find_pin(conn.from_port, PD_Output);
                    if (src_pin.is_valid()) {
                        conn_type = src_pin->is_execution()
                            ? OScriptNodeReroute::REROUTE_CONTROL
                            : OScriptNodeReroute::REROUTE_DATA;
                    }
                }
            }

            // Create a chain of reroute nodes at each knot position
            int prev_source_id   = conn.from_node;
            int prev_source_port = conn.from_port;

            for (int i = 0; i < positions.size(); i++) {
                OScriptNodeInitContext ctx;
                const Ref<OScriptNodeReroute> reroute = create_node<OScriptNodeReroute>(ctx, positions[i]);
                if (!reroute.is_valid()) {
                    break;
                }

                // Establish the input connection first so force_reroute_type can read the source
                // pin's data type when it calls allocate_default_pins() during reconstruction.
                link(prev_source_id, prev_source_port, reroute->get_id(), 0);

                if (conn_type != OScriptNodeReroute::REROUTE_ANY) {
                    reroute->force_reroute_type(conn_type);
                }

                prev_source_id   = reroute->get_id();
                prev_source_port = 0;
            }

            // Connect last reroute to original target, remove original direct connection
            if (prev_source_id != conn.from_node || prev_source_port != static_cast<int>(conn.from_port)) {
                link(prev_source_id, prev_source_port, conn.to_node, conn.to_port);
                unlink(conn.from_node, conn.from_port, conn.to_node, conn.to_port);
            }
        }

        _knots.clear();
    }

    if (p_old_version < 4 && !_nodes.is_empty()) {
        // Do a single pass over the nodes to collect nodes
        Vector<Ref<OScriptNodeComment>> comments;
        for (int node_id : _nodes) {
            const Ref<OScriptNodeComment> comment = _orchestration->get_node(node_id);
            if (comment.is_valid()) {
                comments.push_back(comment);
            }
        }

        // Do a second pass, comparing of the node is overlapping any comment.
        // Given there is likely more non-comments than comments, this should be most efficient.
        for (int node_id : _nodes) {
            const Ref<OScriptNode> node = _orchestration->get_node(node_id);
            if (node.is_valid()) {
                if (const Ref<OScriptNodeComment>& comment = node; comment.is_valid()) {
                    continue;
                }

                const Rect2 node_rect(node->get_position(), node->get_size());
                for (const Ref<OScriptNodeComment>& comment : comments) {
                    const Rect2 comment_rect(comment->get_position(), comment->get_size());
                    if (comment_rect.intersects(node_rect)) {
                        comment->attach_node(node);
                        break;
                    }
                }
            }
        }

        for (Ref<OScriptNodeComment>& comment : comments) {
            comment->set_block_signals(true);
            Rect2 rect(comment->get_position(), comment->get_size());
            for (int node_id : comment->get_attached_nodes()) {
                const Ref<OScriptNode> node = _orchestration->get_node(node_id);
                rect = rect.merge(Rect2(node->get_position(), node->get_size()));
            }
            comment->set_size(rect.grow(20).size);
            comment->set_autoshrink_enabled(true);
            comment->set_block_signals(false);
        }
    }
}

Orchestration* OScriptGraph::get_orchestration() const {
    return _orchestration;
}

StringName OScriptGraph::get_graph_name() const {
    return _name;
}

void OScriptGraph::set_graph_name(const StringName& p_name) {
    if (!_name.match(p_name)) {
        _name = p_name;
        emit_changed();
    }
}

Vector2 OScriptGraph::get_viewport_offset() const {
    return _offset;
}

void OScriptGraph::set_viewport_offset(const Vector2& p_offset) {
    if (_offset != p_offset) {
        _offset = p_offset;
        emit_changed();
    }
}

double OScriptGraph::get_viewport_zoom() const {
    return _zoom;
}

void OScriptGraph::set_viewport_zoom(const double p_zoom) {
    if (!UtilityFunctions::is_equal_approx(_zoom, p_zoom)) {
        _zoom = p_zoom;
        emit_changed();
    }
}

BitField<OScriptGraph::GraphFlags> OScriptGraph::get_flags() const {
    return _flags;
}

void OScriptGraph::set_flags(BitField<GraphFlags> p_flags) {
    if (_flags != p_flags) {
        _flags = p_flags;
        emit_changed();
    }
}

void OScriptGraph::sanitize_nodes() {
    List<int> remove_queue;
    for (const int node_id : _nodes) {
        const Ref<OScriptNode> node = _orchestration->get_node(node_id);
        if (!node.is_valid()) {
            ERR_PRINT(
                vformat("Graph %s has node with id %d, but node is not found in the script metadata.",
                    get_graph_name(), node_id));
            remove_queue.push_back(node_id);
        }
    }

    while (!remove_queue.is_empty()) {
        _nodes.erase(remove_queue.front()->get());
        remove_queue.pop_front();
    }
}

Vector<Ref<OScriptNode>> OScriptGraph::get_nodes() const {
    List<int> removals;

    Vector<Ref<OScriptNode>> nodes;
    for (const int node_id : _nodes) {
        Ref<OScriptNode> node = _orchestration->get_node(node_id);
        if (node.is_valid())
            nodes.push_back(_orchestration->get_node(node_id));
    }
    return nodes;
}

RBSet<OScriptConnection> OScriptGraph::get_connections() const {
    RBSet<OScriptConnection> connections;
    for (const OScriptConnection& E : _orchestration->get_connections()) {
        if (_nodes.has(E.from_node) || _nodes.has(E.to_node)) {
            connections.insert(E);
        }
    }
    return connections;
}

void OScriptGraph::link(int p_source_id, int p_source_port, int p_target_id, int p_target_port) {
    _orchestration->_connect_nodes(p_source_id, p_source_port, p_target_id, p_target_port);
}

void OScriptGraph::unlink(int p_source_id, int p_source_port, int p_target_id, int p_target_port) {
    _orchestration->_disconnect_nodes(p_source_id, p_source_port, p_target_id, p_target_port);
}

Ref<OScriptNode> OScriptGraph::get_node(int p_node_id) const {
    return _orchestration->get_node(p_node_id);
}

void OScriptGraph::add_node(const Ref<OScriptNode>& p_node) {
    _nodes.insert(p_node->get_id());

    // script_view#_create_new_function
    const Ref<OScriptNodeFunctionEntry> function_entry = p_node;
    if (function_entry.is_valid() && _flags.has_flag(GF_FUNCTION) && !_functions.has(p_node->get_id())) {
        _functions.insert(p_node->get_id());
    }

    // script_view#_add_callback
    const Ref<OScriptNodeEvent> event_entry = p_node;
    if (event_entry.is_valid() && _flags.has_flag(GF_EVENT) && !_functions.has(p_node->get_id())) {
        _functions.insert(p_node->get_id());
    }

    emit_signal("node_added", p_node->get_id());
}

void OScriptGraph::remove_node(const Ref<OScriptNode>& p_node) {
    if (!has_node(p_node->get_id())) {
        return;
    }
    _remove_node(p_node->get_id());
}

void OScriptGraph::remove_all_nodes() {
    while (!_nodes.is_empty()) {
        const int node_id = _nodes.front()->get();
        _orchestration->remove_node(node_id);
    }
}

void OScriptGraph::move_node_to(const Ref<OScriptNode>& p_node, const Ref<OScriptGraph>& p_target) {
    ERR_FAIL_COND(p_node.is_null());
    ERR_FAIL_COND(p_target.is_null());

    if (p_target == this) {
        return;
    }

    // Hold a strong reference, p_node may alias a member of an object that observers of
    // "node_removed" release in response to the removal below.
    const Ref<OScriptNode> node = p_node;

    // The node remains registered with the orchestration, only its graph membership changes.
    // Orchestration::add_node cannot be used here as it rejects nodes that are already registered.
    remove_node(node);
    p_target->add_node(node);
}

Ref<OScriptNode> OScriptGraph::copy_node(int p_node_id, bool p_duplicate_resources) {
    const Ref<OScriptNode> node = get_node(p_node_id);
    if (!node.is_valid()) {
        ERR_PRINT("Cannot copy node with id " + itos(p_node_id));
        return nullptr;
    }

    // Duplicate node
    Ref<OScriptNode> duplicate = node->duplicate(p_duplicate_resources);

    // Partially initialize, only so state gets copied/set
    duplicate->_orchestration = _orchestration;
    duplicate->post_initialize();

    return duplicate;
}

Ref<OScriptNode> OScriptGraph::duplicate_node(int p_node_id, const Vector2& p_delta, bool p_duplicate_resources) {
    const Ref<OScriptNode> node = get_node(p_node_id);
    if (!node.is_valid()) {
        ERR_PRINT("Cannot duplicate node with id " + itos(p_node_id));
        return nullptr;
    }

    // Function entry and event nodes carry a function GUID, so an in-place copy would share the source's
    // function rather than define its own. Refuse here so no caller can create that state.
    if (!node->can_duplicate()) {
        ERR_PRINT(vformat("Cannot duplicate node with id %d (%s).", p_node_id, node->get_class()));
        return nullptr;
    }

    // Duplicate node
    Ref<OScriptNode> duplicate = node->duplicate(p_duplicate_resources);

    // Initialize the duplicate node
    // While the ID and Position are obvious, the other two maybe are not.
    // Setting OScript is necessary because the OScript pointer is not stored/persisted.
    // Additionally, there are other node properties that are maybe references to other objects or data
    // that is post-processed after placement but before rendering, and this allows this step to handle
    // that cleanly.
    duplicate->_orchestration = _orchestration;
    duplicate->set_id(_orchestration->get_available_id());
    duplicate->set_position(node->get_position() + p_delta);
    duplicate->post_initialize();

    _orchestration->add_node(this, duplicate);
    duplicate->post_placed_new_node();

    return duplicate;
}

Ref<OScriptNode> OScriptGraph::paste_node(const Ref<OScriptNode>& p_node, const Vector2& p_position) {
    Ref<OScriptNode> node = p_node->duplicate(true);
    node->_orchestration = _orchestration;
    node->set_id(_orchestration->get_available_id());
    node->set_position(p_position);
    node->post_initialize();

    _orchestration->add_node(this, node);
    node->post_placed_new_node();

    return node;
}

Dictionary OScriptGraph::export_nodes(const Vector<int>& p_node_ids) const {
    Dictionary data;
    data["format"] = OrchestrationFormat::FORMAT_VERSION;

    HashSet<int> exported;
    Array nodes;
    for (const int node_id : p_node_ids) {
        if (!_nodes.has(node_id)) {
            continue;
        }

        const Ref<OScriptNode> node = get_node(node_id);
        if (!node.is_valid()) {
            continue;
        }

        // The id is carried on the entry, the importer assigns a new one
        Dictionary properties = ResourceUtils::get_storage_properties(node);
        properties.erase("id");

        Dictionary entry;
        entry["class"] = node->get_class();
        entry["id"] = node_id;
        entry["properties"] = properties;

        nodes.push_back(entry);
        exported.insert(node_id);
    }
    data["nodes"] = nodes;

    // Connections are stored flat, four values per connection, matching the script file layout
    Array connections;
    Dictionary knots;
    for (const OScriptConnection& C : get_connections()) {
        if (!exported.has(C.from_node) || !exported.has(C.to_node)) {
            continue;
        }

        connections.push_back(static_cast<int>(C.from_node));
        connections.push_back(static_cast<int>(C.from_port));
        connections.push_back(static_cast<int>(C.to_node));
        connections.push_back(static_cast<int>(C.to_port));

        if (_knots.has(C.id)) {
            knots[static_cast<int64_t>(C.id)] = _knots[C.id];
        }
    }
    data["connections"] = connections;
    data["knots"] = knots;

    return data;
}

void OScriptGraph::import_nodes(const Dictionary& p_data, const Vector2& p_offset, HashMap<uint64_t, uint64_t>& r_remap, const HashSet<int>& p_skipped) {
    ERR_FAIL_NULL(_orchestration);

    const uint32_t version = p_data.get("format", OrchestrationFormat::FORMAT_VERSION);

    // Nodes created here, keyed by their new id, for the fix-ups that must run after linking
    HashMap<uint64_t, Dictionary> created;

    // Seeded entries that fail verification join the skipped set so nothing links to them.
    // Copied by hand, HashSet has no copy constructor from a const reference.
    HashSet<int> skipped;
    for (const int id : p_skipped) {
        skipped.insert(id);
    }

    const Array entries = p_data.get("nodes", Array());
    for (int i = 0; i < entries.size(); i++) {
        const Dictionary entry = entries[i];
        const int exported_id = entry.get("id", -1);
        if (exported_id < 0 || skipped.has(exported_id)) {
            continue;
        }

        const String class_name = entry.get("class", String());

        // A seeded entry is the caller's promise that the mapped node already stands in for the export.
        // The node is not created, but the promise is checked so connections never land on the wrong node.
        if (r_remap.has(exported_id)) {
            const uint64_t seeded_id = r_remap[exported_id];
            const Ref<OScriptNode> seeded = _orchestration->get_node(static_cast<int>(seeded_id));
            if (!seeded.is_valid() || String(seeded->get_class()) != class_name) {
                ERR_PRINT(vformat("Cannot import node %d, the node seeded for it (%d) is missing or is not a '%s'.", exported_id, seeded_id, class_name));
                r_remap.erase(exported_id);
                skipped.insert(exported_id);
            }
            continue;
        }

        const Ref<OScriptNode> node = OScriptNodeFactory::create_node_from_name(class_name, _orchestration);
        ERR_CONTINUE_MSG(!node.is_valid(), vformat("Cannot import node %d, unknown node type '%s'.", exported_id, class_name));

        const Dictionary properties = entry.get("properties", Dictionary());
        const Array keys = properties.keys();
        for (int j = 0; j < keys.size(); j++) {
            node->set(keys[j], properties[keys[j]]);
        }

        node->set_id(_orchestration->get_available_id());
        node->set_position(Vector2(properties.get("position", Vector2())) + p_offset);

        if (version < OrchestrationFormat::FORMAT_VERSION) {
            node->_upgrade(version, OrchestrationFormat::FORMAT_VERSION);
        }

        node->post_initialize();
        _orchestration->add_node(this, node);
        node->post_placed_new_node();

        r_remap[exported_id] = node->get_id();
        created[node->get_id()] = properties;
    }

    const Array connections = p_data.get("connections", Array());
    const Dictionary knots = p_data.get("knots", Dictionary());
    bool knots_changed = false;
    for (int i = 0; i + 3 < connections.size(); i += 4) {
        OScriptConnection exported;
        exported.from_node = static_cast<int>(connections[i]);
        exported.from_port = static_cast<int>(connections[i + 1]);
        exported.to_node = static_cast<int>(connections[i + 2]);
        exported.to_port = static_cast<int>(connections[i + 3]);

        if (!r_remap.has(exported.from_node) || !r_remap.has(exported.to_node)) {
            continue;
        }

        OScriptConnection imported;
        imported.from_node = r_remap[exported.from_node];
        imported.from_port = exported.from_port;
        imported.to_node = r_remap[exported.to_node];
        imported.to_port = exported.to_port;

        link(imported.from_node, imported.from_port, imported.to_node, imported.to_port);

        const int64_t exported_key = static_cast<int64_t>(exported.id);
        if (knots.has(exported_key)) {
            PackedVector2Array points = knots[exported_key];
            for (int j = 0; j < points.size(); j++) {
                points.set(j, points[j] + p_offset);
            }
            _knots[imported.id] = points;
            knots_changed = true;
        }
    }

    if (knots_changed) {
        emit_signal("knots_updated");
    }

    for (const KeyValue<uint64_t, Dictionary>& E : created) {
        const Ref<OScriptNode> node = _orchestration->get_node(E.key);
        if (!node.is_valid()) {
            continue;
        }

        // Linking may have promoted operator pins away from the exported types
        OScriptNodePromotableOperator::copy_pin_types(E.value, node);

        // Attachments still reference the exported ids
        const Ref<OScriptNodeComment> comment = node;
        if (comment.is_valid()) {
            comment->remap_attached_nodes(r_remap);
        }
    }
}

Vector<Ref<OScriptFunction>> OScriptGraph::get_functions() const {
    Vector<Ref<OScriptFunction>> functions;
    for (int function_id : _functions) {
        Ref<OScriptNodeFunctionTerminator> term = _orchestration->get_node(function_id);
        if (term.is_valid() && !functions.has(term->get_function()))
            functions.push_back(term->get_function());
    }
    return functions;
}

const HashMap<uint64_t, PackedVector2Array>& OScriptGraph::get_knots() const {
    return _knots;
}

void OScriptGraph::set_knots(const HashMap<uint64_t, PackedVector2Array>& p_knots) {
    _knots = p_knots;
    emit_signal("knots_updated");
}

void OScriptGraph::remove_connection_knot(uint64_t p_connection_id) {
    if (_knots.erase(p_connection_id)) {
        emit_signal("connection_knots_removed", p_connection_id);
    }
}

Ref<OScriptNode> OScriptGraph::create_node(const StringName& p_type, const OScriptNodeInitContext& p_context, const Vector2& p_position) {
    // If we wanted to split this into stages, we need to be concerned that initialize calls
    // the following, and we ideally would prefer to have nodes created detached without any
    // reference to an Orchestration.
    //
    // OScriptNodeCallMemberFunction calls get_orchestration()->get_base_type
    // OScriptNodeCallScriptFunction calls get_orchestration()->find_function
    // OScriptNodeFunctionEntry calls get_orchestration()->create_function
    // OScriptNodeEmitSignal calls get_orchestration()->get_custom_signal
    // OScriptNodeVariable calls get_orchestration()->get_variable
    //
    const Ref<OScriptNode> spawned = OScriptNodeFactory::create_node_from_name(p_type, _orchestration);
    if (spawned.is_valid()) {
        spawned->set_id(_orchestration->get_available_id());
        _initialize_node(spawned, p_context, p_position);
    }

    return spawned;
}

void OScriptGraph::_bind_methods() {
    BIND_BITFIELD_FLAG(GraphFlags::GF_NONE)
    BIND_BITFIELD_FLAG(GraphFlags::GF_RENAMABLE)
    BIND_BITFIELD_FLAG(GraphFlags::GF_DELETABLE)
    BIND_BITFIELD_FLAG(GraphFlags::GF_EVENT)
    BIND_BITFIELD_FLAG(GraphFlags::GF_FUNCTION)
    BIND_BITFIELD_FLAG(GraphFlags::GF_DEFAULT)

    ClassDB::bind_method(D_METHOD("set_graph_name", "graph_name"), &OScriptGraph::set_graph_name);
    ClassDB::bind_method(D_METHOD("get_graph_name"), &OScriptGraph::get_graph_name);
    ADD_PROPERTY(PropertyInfo(Variant::STRING, "graph_name"), "set_graph_name", "get_graph_name");

    ClassDB::bind_method(D_METHOD("set_viewport_offset", "offset"), &OScriptGraph::set_viewport_offset);
    ClassDB::bind_method(D_METHOD("get_viewport_offset"), &OScriptGraph::get_viewport_offset);
    ADD_PROPERTY(PropertyInfo(Variant::VECTOR2, "offset"), "set_viewport_offset", "get_viewport_offset");

    ClassDB::bind_method(D_METHOD("set_viewport_zoom", "zoom"), &OScriptGraph::set_viewport_zoom);
    ClassDB::bind_method(D_METHOD("get_viewport_zoom"), &OScriptGraph::get_viewport_zoom);
    ADD_PROPERTY(PropertyInfo(Variant::FLOAT, "zoom"), "set_viewport_zoom", "get_viewport_zoom");

    ClassDB::bind_method(D_METHOD("set_flags", "flags"), &OScriptGraph::set_flags);
    ClassDB::bind_method(D_METHOD("get_flags"), &OScriptGraph::get_flags);
    ADD_PROPERTY(PropertyInfo(Variant::INT, "flags"), "set_flags", "get_flags");

    ClassDB::bind_method(D_METHOD("_set_nodes", "nodes"), &OScriptGraph::_set_nodes);
    ClassDB::bind_method(D_METHOD("_get_nodes"), &OScriptGraph::_get_nodes);
    ADD_PROPERTY(PropertyInfo(Variant::ARRAY, "nodes"), "_set_nodes", "_get_nodes");

    ClassDB::bind_method(D_METHOD("_set_functions", "functions"), &OScriptGraph::_set_functions);
    ClassDB::bind_method(D_METHOD("_get_functions"), &OScriptGraph::_get_functions);
    ADD_PROPERTY(PropertyInfo(Variant::ARRAY, "functions"), "_set_functions", "_get_functions");

    ClassDB::bind_method(D_METHOD("_set_knots", "knots"), &OScriptGraph::_set_knots);
    ClassDB::bind_method(D_METHOD("_get_knots"), &OScriptGraph::_get_knots);
    ADD_PROPERTY(PropertyInfo(Variant::DICTIONARY, "knots"), "_set_knots", "_get_knots");

    ADD_SIGNAL(MethodInfo("node_added", PropertyInfo(Variant::INT, "node_id")));
    ADD_SIGNAL(MethodInfo("node_removed", PropertyInfo(Variant::INT, "node_id")));
    ADD_SIGNAL(MethodInfo("knots_updated"));
    ADD_SIGNAL(MethodInfo("connection_knots_removed", PropertyInfo(Variant::INT, "connection_id")));
}