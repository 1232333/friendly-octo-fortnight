// This file is part of the Godot Orchestrator project.
//
// Copyright (c) 2023-present Crater Crash Studios LLC and its contributors.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//		http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
#include "orchestration/nodes/scene_node.h"

#include "common/property_utils.h"
#include "common/scene_utils.h"
#include "common/string_utils.h"
#include "orchestration/orchestration.h"
#include "script/script_server.h"

#include <godot_cpp/classes/engine.hpp>
#include <godot_cpp/classes/node.hpp>
#include <godot_cpp/classes/scene_tree.hpp>
#include <godot_cpp/classes/script.hpp>

void OScriptNodeSceneNode::_get_property_list(List<PropertyInfo>* r_list) const {
    r_list->push_back(PropertyInfo(Variant::NODE_PATH, "node_path"));
    r_list->push_back(PropertyInfo(Variant::STRING, "target_class_name", PROPERTY_HINT_NONE, "", PROPERTY_USAGE_STORAGE));
}

bool OScriptNodeSceneNode::_get(const StringName& p_name, Variant& r_value) const {
    if (p_name.match("node_path")) {
        r_value = _node_path;
        return true;
    }
    if (p_name.match("target_class_name")) {
        r_value = _class_name;
        return true;
    }
    return false;
}

bool OScriptNodeSceneNode::_set(const StringName& p_name, const Variant& p_value) {
    if (p_name.match("node_path")) {
        _node_path = p_value;

        if (_initialized) {
            if (Node* node = _get_referenced_node()) {
                if (!_node_path.get_concatenated_names().begins_with("%") && node->is_unique_name_in_owner()) {
                    _node_path = "%" + node->get_name();
                }

                Ref<Script> script = node->get_script();

                String global_class;
                if (script.is_valid()) {
                    global_class = ScriptServer::get_global_name(script);
                }

                _class_name = StringUtils::default_if_empty(global_class, node->get_class());
            }
        }

        _notify_pins_changed();
        return true;
    } else if (p_name.match("target_class_name")) {
        _class_name = p_value;
        return true;
    }
    return false;
}

void OScriptNodeSceneNode::_upgrade(uint32_t p_version, uint32_t p_current_version) {
    if (p_version == 1 && p_current_version >= 2) {
        // Fixup - class name to be encoded on output pin
        if (_class_name.is_empty()) {
            const Ref<OScriptNodePin> output = find_pin(_node_path, PD_Output);
            if (output.is_valid() && !output->get_property_info().class_name.is_empty())
            {
                _class_name = output->get_property_info().class_name;
                reconstruct_node();
            }
        }
    }

    super::_upgrade(p_version, p_current_version);
}

Node* OScriptNodeSceneNode::_get_scene_base_node() const {
    if (_is_in_editor() && !_node_path.is_empty()) {
        return SceneUtils::get_scene_base_node(get_orchestration()->get_self());
    }
    return nullptr;
}

Node* OScriptNodeSceneNode::_get_referenced_node() const {
    if (Node* base_node = _get_scene_base_node()) {
        return base_node->get_node_or_null(_node_path);
    }
    return nullptr;
}

void OScriptNodeSceneNode::allocate_default_pins() {
    const String class_name = StringUtils::default_if_empty(_class_name, "Node");
    create_pin(PD_Output, PT_Data, PropertyUtils::make_object(_node_path, class_name))->no_pretty_format();
    super::allocate_default_pins();
}

String OScriptNodeSceneNode::get_tooltip_text() const {
    return "Return the specified scene node.";
}

String OScriptNodeSceneNode::get_node_title() const {
    return "Get Scene Node";
}

String OScriptNodeSceneNode::get_icon() const {
    return "NodeInfo";
}

String OScriptNodeSceneNode::get_help_topic() const {
    return vformat("class:%s", _class_name);
}

Ref<Resource> OScriptNodeSceneNode::get_inspect_object() {
    if (_is_in_editor()) {
        if (Node* base_node = _get_scene_base_node()) {
            set_meta("__base_node_relative", base_node);
        }
    }
    return super::get_inspect_object();
}

Ref<OScriptTargetObject> OScriptNodeSceneNode::resolve_target(const Ref<OScriptNodePin>& p_pin) const {
    if (_is_in_editor() && p_pin.is_valid() && p_pin->is_output() && !p_pin->is_execution()) {
        if (Node* scene_node = _get_referenced_node()) {
            return memnew(OScriptTargetObject(scene_node, false));
        }
    }
    return super::resolve_target(p_pin);
}

void OScriptNodeSceneNode::initialize(const OScriptNodeInitContext& p_context) {
    if (p_context.node_path) {
        _node_path = p_context.node_path.value();
    }
    if (p_context.class_name) {
        _class_name = p_context.class_name.value();
    }
    super::initialize(p_context);
}

bool OScriptNodeSceneNode::is_pure() const {
    return true;
}
