// This file is part of the Godot Orchestrator project.
//
// Copyright (c) 2023-present Crater Crash Studios LLC and its contributors.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//		http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
#include "orchestration/nodes/constants.h"

#include "api/extension_db.h"
#include "common/property_utils.h"
#include "common/string_utils.h"
#include "common/variant_utils.h"
#include "script/script_server.h"

#include <godot_cpp/classes/engine.hpp>

OScriptNodeConstant::OScriptNodeConstant() {
    _flags = CATALOGABLE;
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// OScriptNodeGlobalConstant

StringName OScriptNodeGlobalConstant::_get_default_constant_name() const {
    if (_constant_name.is_empty()) {
        PackedStringArray names = ExtensionDB::get_global_enum_value_names();
        if (!names.is_empty()) {
            return names[0];
        }
        return {};
    }
    return _constant_name;
}

void OScriptNodeGlobalConstant::_get_property_list(List<PropertyInfo>* r_list) const {
    const String constants = StringUtils::join(",", ExtensionDB::get_global_enum_value_names());
    r_list->push_front(PropertyInfo(Variant::STRING, "constant", PROPERTY_HINT_ENUM, constants));
}

bool OScriptNodeGlobalConstant::_get(const StringName& p_name, Variant& r_value) const {
    if (p_name.match("constant")) {
        r_value = _constant_name;
        return true;
    }
    return false;
}

bool OScriptNodeGlobalConstant::_set(const StringName& p_name, const Variant& p_value) {
    if (p_name.match("constant")) {
        _constant_name = p_value;
        _notify_pins_changed();
        return true;
    }
    return false;
}

bool OScriptNodeGlobalConstant::_property_can_revert(const StringName& p_name) const {
    return p_name.match("constant");
}

bool OScriptNodeGlobalConstant::_property_get_revert(const StringName& p_name, Variant& r_value) const {
    if (p_name.match("constant")) {
        const PackedStringArray enum_names = ExtensionDB::get_global_enum_value_names();
        if (!enum_names.is_empty()) {
            r_value = StringName(enum_names[0]);
            return true;
        }
    }
    return false;
}

void OScriptNodeGlobalConstant::_upgrade(uint32_t p_version, uint32_t p_current_version) {
    if (p_version == 1 && p_current_version >= 2) {
        // Fixup - make sure pin uses new enum semantics
        Ref<OScriptNodePin> constant = find_pin("constant", PD_Output);
        if (constant.is_valid() && !PropertyUtils::is_class_enum(constant->get_property_info())) {
            reconstruct_node();
        }
    }
    super::_upgrade(p_version, p_current_version);
}

void OScriptNodeGlobalConstant::post_initialize() {
    // Initially set the value from the pin
    Ref<OScriptNodePin> constant = find_pin("constant", PD_Output);
    if (constant.is_valid()) {
        _constant_name = constant->get_label();
    }

    // Seed from the list if pin had no value
    _constant_name = _get_default_constant_name();
    super::post_initialize();
}

void OScriptNodeGlobalConstant::allocate_default_pins() {
    EnumInfo ei = ExtensionDB::get_global_enum_by_value(_constant_name);
    if (ei.values.is_empty()) {
        ERR_FAIL_MSG("Failed to locate enum for " + _constant_name);
    }

    Ref<OScriptNodePin> constant = create_pin(PD_Output, PT_Data, PropertyUtils::make_enum_class("constant", ei.name));
    constant->set_label(_constant_name, false);

    super::allocate_default_pins();
}

String OScriptNodeGlobalConstant::get_tooltip_text() const {
    return "Return the value of a global constant";
}

String OScriptNodeGlobalConstant::get_node_title() const {
    return "Global Constant";
}

String OScriptNodeGlobalConstant::get_help_topic() const {
    return vformat("class_constant:@GlobalScope:%s", _constant_name);
}

String OScriptNodeGlobalConstant::get_icon() const {
    return "MemberConstant";
}

PackedStringArray OScriptNodeGlobalConstant::get_keywords() const {
    return PackedStringArray();
}

void OScriptNodeGlobalConstant::configure(const OScriptNodeInitContext& p_context) {
    super::configure(p_context);

    const Dictionary data = p_context.user_data.value_or(Dictionary());
    _constant_name = data.get("constant", StringName());
}

void OScriptNodeGlobalConstant::initialize(const OScriptNodeInitContext& p_context) {
    _constant_name = _get_default_constant_name();
    super::initialize(p_context);
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// OScriptNodeMathConstant

void OScriptNodeMathConstant::_get_property_list(List<PropertyInfo>* r_list) const {
    const String constants = StringUtils::join(",", ExtensionDB::get_math_constant_names());
    r_list->push_front(PropertyInfo(Variant::STRING, "constant", PROPERTY_HINT_ENUM, constants));
}

bool OScriptNodeMathConstant::_get(const StringName& p_name, Variant& r_value) const {
    if (p_name.match("constant")) {
        r_value = _constant_name;
        return true;
    }
    return false;
}

bool OScriptNodeMathConstant::_set(const StringName& p_name, const Variant& p_value) {
    if (p_name.match("constant")) {
        _constant_name = p_value;
        _notify_pins_changed();
        return true;
    }
    return false;
}

void OScriptNodeMathConstant::allocate_default_pins() {
    Ref<OScriptNodePin> constant = create_pin(PD_Output, PT_Data, PropertyUtils::make_typed("constant", Variant::FLOAT));
    constant->set_label(_constant_name, false);
    super::allocate_default_pins();
}

String OScriptNodeMathConstant::get_tooltip_text() const {
    return "Return the value of a math constant";
}

String OScriptNodeMathConstant::get_node_title() const {
    return "Math Constant";
}

String OScriptNodeMathConstant::get_help_topic() const {
    // todo: some math constants are not exposed to the documentation, i.e. "One"
    //       check if these can be exposed via OScriptLanguage instead?
    return vformat("class_constant:@GDScript:%s", _constant_name);
}

String OScriptNodeMathConstant::get_icon() const {
    return "MemberConstant";
}

PackedStringArray OScriptNodeMathConstant::get_keywords() const {
    return ExtensionDB::get_math_constant_names();
}

void OScriptNodeMathConstant::configure(const OScriptNodeInitContext& p_context) {
    super::configure(p_context);

    const Dictionary data = p_context.user_data.value_or(Dictionary());
    _constant_name = data.get("constant", "One");
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// OScriptNodeTypeConstant

HashMap<Variant::Type,HashMap<StringName,Variant>> OScriptNodeTypeConstant::_type_constants;
Vector<Variant::Type> OScriptNodeTypeConstant::_types;

void OScriptNodeTypeConstant::_get_property_list(List<PropertyInfo>* r_list) const {
    PackedStringArray array;
    for (const KeyValue<Variant::Type, HashMap<StringName, Variant>>& E: _type_constants) {
        array.push_back(VariantUtils::get_friendly_type_name(E.key));
    }

    const String types = StringUtils::join(",", array);
    r_list->push_front(PropertyInfo(Variant::INT, "basic_type", PROPERTY_HINT_ENUM, types, PROPERTY_USAGE_DEFAULT | PROPERTY_USAGE_UPDATE_ALL_IF_MODIFIED));

    PackedStringArray array_values;
    if (_type_constants.has(_type)) {
        for (const KeyValue<StringName, Variant>& E : _type_constants[_type]) {
            array_values.push_back(E.key);
        }
    }
    const String values = StringUtils::join(",", array_values);
    r_list->push_back(PropertyInfo(Variant::STRING, "constant", PROPERTY_HINT_ENUM, values));
}

bool OScriptNodeTypeConstant::_get(const StringName& p_name, Variant& r_value) const {
    if (p_name.match("basic_type")) {
        r_value = _types.find(_type);
        return true;
    } else if (p_name.match("constant")) {
        r_value = _constant_name;
        return true;
    }
    return false;
}

bool OScriptNodeTypeConstant::_set(const StringName& p_name, const Variant& p_value) {
    if (p_name.match("basic_type")) {
        const int index = p_value;
        if (index >= 0 && !_types.is_empty() && _type != _types[p_value]) {
            _type = _types[p_value];
            _constant_name = _type_constants[_type].begin()->key;
            _notify_pins_changed();
            notify_property_list_changed();
            return true;
        }
    } else if (p_name.match("constant")) {
        if (_constant_name != p_value) {
            _constant_name = p_value;
            _notify_pins_changed();
            return true;
        }
    }
    return false;
}

bool OScriptNodeTypeConstant::_property_can_revert(const StringName& p_name) const {
    if (p_name.match("basic_type") || p_name.match("constant")) {
        return true;
    }
    return false;
}

bool OScriptNodeTypeConstant::_property_get_revert(const StringName& p_name, Variant& r_value) const {
    if (!_type_constants.is_empty()) {
        if (p_name.match("basic_type")) {
            r_value = _type_constants.begin()->key;
            return true;
        } else if (p_name.match("constant")) {
            r_value = String(_type_constants[_type].begin()->key);
            return true;
        }
    }
    return false;
}

void OScriptNodeTypeConstant::_upgrade(uint32_t p_version, uint32_t p_current_version) {
    if (p_version == 1 && p_current_version >= 2) {
        // Fixup - Make sure that the class enum details are encoded
        Ref<OScriptNodePin> constant = find_pin("constant", PD_Output);
        if (constant.is_valid() && !PropertyUtils::is_class_enum(constant->get_property_info())) {
            reconstruct_node();
        }
    }
    super::_upgrade(p_version, p_current_version);
}

PropertyInfo OScriptNodeTypeConstant::_create_pin_property_info() {
    // Check whether constant is an enumeration
    BuiltInType type = ExtensionDB::get_builtin_type(_type);
    ERR_FAIL_COND_V_MSG(type.type != _type, PropertyInfo(), "Failed to resolve built-in type");

    for (const EnumInfo& E : type.enums) {
        for (const EnumValue& V : E.values) {
            if (V.name == _constant_name) {
                return PropertyUtils::make_class_enum("constant", type.name, E.name);
            }
        }
    }

    for (const ConstantInfo& C : type.constants) {
        if (C.name == _constant_name) {
            return PropertyUtils::make_typed("constant", _type);
        }
    }

    ERR_FAIL_V_MSG(PropertyInfo(), "Failed to find type constant " + _constant_name);
}

void OScriptNodeTypeConstant::allocate_default_pins() {
    String label = VariantUtils::get_friendly_type_name(_type);
    if (!_constant_name.is_empty()) {
        label += "::" + _constant_name;
    }

    Ref<OScriptNodePin> constant = create_pin(PD_Output, PT_Data, _create_pin_property_info());
    constant->set_label(label, false);
    super::allocate_default_pins();
}

String OScriptNodeTypeConstant::get_tooltip_text() const {
    return "Return the value of a variant type constant";
}

String OScriptNodeTypeConstant::get_node_title() const {
    return "Type Constant";
}

String OScriptNodeTypeConstant::get_help_topic() const {
    return vformat("class_constant:%s:%s", Variant::get_type_name(_type), _constant_name);
}

String OScriptNodeTypeConstant::get_icon() const {
    return "MemberConstant";
}

void OScriptNodeTypeConstant::configure(const OScriptNodeInitContext& p_context) {
    super::configure(p_context);

    const Dictionary data = p_context.user_data.value_or(Dictionary());
    _type = VariantUtils::to_type(data.get("type", Variant::NIL));
    _constant_name = data.get("constant", "");
}

void OScriptNodeTypeConstant::initialize(const OScriptNodeInitContext& p_context) {
    // Fall back to the first type and its first constant when the spawn data named neither or named
    // something this type does not define.
    if (!_type_constants.has(_type)) {
        _type = _types[0];
    }

    if (!_type_constants[_type].has(_constant_name)) {
        _constant_name = _type_constants[_type].begin()->key;
    }
    super::initialize(p_context);
}

void OScriptNodeTypeConstant::_bind_methods() {
    for (const BuiltInType& type : ExtensionDB::get_builtin_types()) {
        if (!type.constants.is_empty()) {
            _types.push_back(type.type);
            for (const ConstantInfo& ci : type.constants) {
                _type_constants[type.type][ci.name] = ci.value;
            }
        }
    }
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// OScriptNodeClassConstantBase

String OScriptNodeClassConstantBase::_get_enum_declaring_class(const String& p_class_name, const StringName& p_enum_name) const {
    String class_name = p_class_name;
    while (!class_name.is_empty()) {
        if (ClassDB::class_has_enum(class_name, p_enum_name, true)) {
            return class_name;
        }
        class_name = ClassDB::get_parent_class(class_name);
    }
    return {};
}

void OScriptNodeClassConstantBase::_get_property_list(List<PropertyInfo>* r_list) const {
    const PackedStringArray class_names = _get_class_names();
    if (!class_names.is_empty()) {
        const String choices = StringUtils::join(",", class_names);
        r_list->push_back(PropertyInfo(Variant::STRING, "class_name", PROPERTY_HINT_ENUM, choices));
    } else {
        r_list->push_back(PropertyInfo(Variant::STRING, "class_name", PROPERTY_HINT_TYPE_STRING, "Object"));
    }

    // Constant order is registration-dependent, sort for a stable, searchable choice list
    PackedStringArray constant_names = _get_class_constant_choices(_class_name);
    constant_names.sort();

    const String constants = StringUtils::join(",", constant_names);
    r_list->push_back(PropertyInfo(Variant::STRING, "constant", PROPERTY_HINT_ENUM, constants));
}

bool OScriptNodeClassConstantBase::_get(const StringName& p_name, Variant& r_value) const {
    if (p_name.match("class_name")) {
        r_value = _class_name;
        return true;
    } else if (p_name.match("constant")) {
        r_value = _constant_name;
        return true;
    }
    return false;
}

bool OScriptNodeClassConstantBase::_set(const StringName& p_name, const Variant& p_value) {
    if (p_name.match("class_name")) {
        if (_class_name != p_value) {
            _class_name = p_value;
            _constant_name = "";
            _notify_pins_changed();
            notify_property_list_changed();
            return true;
        }
    } else if (p_name.match("constant")) {
        if (_constant_name != p_value) {
            _constant_name = p_value;
            _notify_pins_changed();
            return true;
        }
    }
    return false;
}

void OScriptNodeClassConstantBase::_upgrade(uint32_t p_version, uint32_t p_current_version) {
    if (p_version == 1 && p_current_version >= 2) {
        // Fixup - make sure pin uses new enum semantics
        Ref<OScriptNodePin> constant = find_pin("constant", PD_Output);
        if (constant.is_valid() && !PropertyUtils::is_class_enum(constant->get_property_info()))
            reconstruct_node();
    }
    super::_upgrade(p_version, p_current_version);
}

Ref<OScriptNodePin> OScriptNodeClassConstantBase::_create_constant_pin() {
    if (ScriptServer::is_global_class(_class_name)) {
        const StringName enum_name = ScriptServer::get_global_class(_class_name).get_integer_constant_enum(_constant_name);
        if (!enum_name.is_empty()) {
            return create_pin(PD_Output, PT_Data, PropertyUtils::make_class_enum("constant", _class_name, enum_name));
        }
    } else {
        const StringName enum_name = ClassDB::class_get_integer_constant_enum(_class_name, _constant_name);
        if (!enum_name.is_empty()) {
            // The constant may be inherited, so the pin must reference the class that declares the
            // enum rather than the selected class, otherwise the pair cannot be resolved later.
            const String class_name = _get_enum_declaring_class(_class_name, enum_name);
            if (!class_name.is_empty()) {
                return create_pin(PD_Output, PT_Data, PropertyUtils::make_class_enum("constant", class_name, enum_name));
            }
        }
    }
    return create_pin(PD_Output, PT_Data, PropertyUtils::make_typed("constant", Variant::INT));
}

void OScriptNodeClassConstantBase::allocate_default_pins() {
    String label = _class_name;
    if (!_constant_name.is_empty()) {
        label += "::" + _constant_name;
    }

    _create_constant_pin()->set_label(label, false);
    super::allocate_default_pins();
}

String OScriptNodeClassConstantBase::get_tooltip_text() const {
    return "Return the value of a class-level constant";
}

String OScriptNodeClassConstantBase::get_node_title() const {
    return "Class Constant";
}

String OScriptNodeClassConstantBase::get_help_topic() const {
    String class_name = _class_name;
    while (!class_name.is_empty()) {
        PackedStringArray values = ClassDB::class_get_integer_constant_list(class_name, true);
        if (values.has(_constant_name)) {
            return vformat("class_constant:%s:%s", class_name, _constant_name);
        }
        class_name = ClassDB::get_parent_class(class_name);
    }
    return super::get_help_topic();
}

String OScriptNodeClassConstantBase::get_icon() const {
    return "MemberConstant";
}

void OScriptNodeClassConstantBase::configure(const OScriptNodeInitContext& p_context) {
    super::configure(p_context);

    // Each subclass seeds its own default class in its constructor, so only spawn data that names
    // a class overrides it.
    const Dictionary data = p_context.user_data.value_or(Dictionary());
    if (data.has("class_name")) {
        _class_name = data["class_name"];
    }
    _constant_name = data.get("constant", "");
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// OScriptNodeClassConstant

PackedStringArray OScriptNodeClassConstant::_get_class_constant_choices(const String& p_class_name) const {
    if (ScriptServer::is_global_class(p_class_name)) {
        return ScriptServer::get_global_class(p_class_name).get_integer_constant_list();
    }
    return ClassDB::class_get_integer_constant_list(p_class_name, false);
}

OScriptNodeClassConstant::OScriptNodeClassConstant() {
    _class_name = "Object";
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// OScriptNodeSingletonConstant

PackedStringArray OScriptNodeSingletonConstant::_get_singletons_with_constants() const {
    // Initialize the singleton list once using static-init
    static const PackedStringArray singletons_with_constants = [] {
        PackedStringArray array;
        for (const String& singleton : Engine::get_singleton()->get_singleton_list()) {
            // Enum members are also registered as integer constants, so this covers both.
            if (ClassDB::class_get_integer_constant_list(singleton, true).is_empty()) {
                continue;
            }
            array.push_back(singleton);
        }
        array.sort();
        return array;
    }();

    return singletons_with_constants;
}

PackedStringArray OScriptNodeSingletonConstant::_get_class_constant_choices(const String& p_class_name) const {
    return ClassDB::class_get_integer_constant_list(p_class_name, true);
}

PackedStringArray OScriptNodeSingletonConstant::_get_class_names() const {
    return _singletons;
}

OScriptNodeSingletonConstant::OScriptNodeSingletonConstant() {
    _class_name = "Input"; // Most common choice
    _singletons = _get_singletons_with_constants();
}