// This file is part of the Godot Orchestrator project.
//
// Copyright (c) 2023-present Crater Crash Studios LLC and its contributors.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//		http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
#pragma once

#include "orchestration/node.h"

/// Acquire a reference to a scene node.
///
/// This node is really only effective while the scene that contains the node is open in the editor.
/// To work with nodes in other unopened scenes requires work beyond what this implementation is
/// capable of doing at this time.
///
class OScriptNodeSceneNode : public OScriptNode {
    ORCHESTRATOR_NODE_CLASS(OScriptNodeSceneNode, OScriptNode);

    NodePath _node_path;    //! The node's path
    String _class_name;     //! Node's class type

protected:
    static void _bind_methods() { }

    //~ Begin Wrapped Interface
    void _get_property_list(List<PropertyInfo>* r_list) const;
    bool _get(const StringName& p_name, Variant& r_value) const;
    bool _set(const StringName& p_name, const Variant& p_value);
    //~ End Wrapped Interface

    //~ Begin OScriptNode Interface
    void _upgrade(uint32_t p_version, uint32_t p_current_version) override;
    //~ End OScriptNode Interface

    /// Get the node from scene that has this script, if possible.
    Node* _get_scene_base_node() const;

    /// Get the referenced node from the scene, if possible.
    Node* _get_referenced_node() const;

public:

    //~ Begin OScriptNode Interface
    void allocate_default_pins() override;
    String get_tooltip_text() const override;
    String get_node_title() const override;
    String get_node_title_color_name() const override { return "scene"; }
    String get_icon() const override;
    String get_help_topic() const override;
    Ref<Resource> get_inspect_object() override;
    Ref<OScriptTargetObject> resolve_target(const Ref<OScriptNodePin>& p_pin) const override;
    void initialize(const OScriptNodeInitContext& p_context) override;
    bool is_pure() const override;
    //~ End OScriptNode Interface

    NodePath get_scene_node_path() const { return _node_path; }
    String get_scene_node_class_name() const { return _class_name; }
};
