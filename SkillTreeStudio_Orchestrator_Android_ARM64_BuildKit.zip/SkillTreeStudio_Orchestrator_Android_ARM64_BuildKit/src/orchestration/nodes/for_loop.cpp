// This file is part of the Godot Orchestrator project.
//
// Copyright (c) 2023-present Crater Crash Studios LLC and its contributors.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//		http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
#include "orchestration/nodes/for_loop.h"

#include "common/callable_lambda.h"
#include "common/dictionary_utils.h"
#include "common/macros.h"
#include "common/property_utils.h"
#include "common/variant_utils.h"

void OScriptNodeForLoop::_get_property_list(List<PropertyInfo> *r_list) const {
    r_list->push_back(PropertyInfo(Variant::BOOL, "with_break", PROPERTY_HINT_NONE, "", PROPERTY_USAGE_STORAGE));
    r_list->push_back(PropertyInfo(Variant::INT, "start", PROPERTY_HINT_NONE, "", PROPERTY_USAGE_STORAGE));
    r_list->push_back(PropertyInfo(Variant::INT, "end", PROPERTY_HINT_NONE, "", PROPERTY_USAGE_STORAGE));
}

bool OScriptNodeForLoop::_get(const StringName& p_name, Variant& r_value) const {
    if (p_name.match("with_break")) {
        r_value = _with_break;
        return true;
    } else if (p_name.match("start")) {
        r_value = _start_index;
        return true;
    } else if (p_name.match("end")) {
        r_value = _end_index;
        return true;
    }
    return false;
}

bool OScriptNodeForLoop::_set(const StringName& p_name, const Variant& p_value) {
    if (p_name.match("with_break")) {
        _with_break = p_value;
        _notify_pins_changed();
        return true;
    } else if (p_name.match("start")) {
        _start_index = p_value;
        return true;
    } else if (p_name.match("end")) {
        _end_index = p_value;
        return true;
    }
    return false;
}

void OScriptNodeForLoop::post_initialize() {
    // Fixes issue where a break pin exists but the break status was not persisted
    if (!_with_break && find_pin("break", PD_Output).is_valid()) {
        _with_break = true;
    }

    // Automatically adjusts old nodes to having the new aborted node layout
    if (_with_break && !find_pin("aborted", PD_Output).is_valid()) {
        reconstruct_node();

        // This needs to be delayed until the end of frame due to pin index caching
        callable_mp_lambda(this, [&,this]() {
            const Ref<OScriptNodePin> aborted = find_pin("aborted", PD_Output);
            const Ref<OScriptNodePin> completed = find_pin("completed", PD_Output);
            if (aborted.is_valid() && completed.is_valid()) {
                const Vector<Ref<OScriptNodePin>> targets = completed->get_connections();
                if (!targets.is_empty()) {
                    aborted->link(targets[0]);
                }
            }
        }).call_deferred();
    }

    super::post_initialize();
}

void OScriptNodeForLoop::reallocate_pins_during_reconstruction(const Vector<Ref<OScriptNodePin>>& p_old_pins) {
    super::reallocate_pins_during_reconstruction(p_old_pins);

    for (const Ref<OScriptNodePin>& pin : p_old_pins) {
        if (pin->is_input() && !pin->is_execution()) {
            const Ref<OScriptNodePin> new_input = find_pin(pin->get_pin_name(), PD_Input);
            if (new_input.is_valid()) {
                new_input->set_default_value(pin->get_default_value());
            }
        }
    }
}

void OScriptNodeForLoop::allocate_default_pins() {
    create_pin(PD_Input, PT_Execution, PropertyUtils::make_exec("ExecIn"));
    create_pin(PD_Input, PT_Data, PropertyUtils::make_typed("first_index", Variant::INT), _start_index);
    create_pin(PD_Input, PT_Data, PropertyUtils::make_typed("last_index", Variant::INT), _end_index);

    if (_with_break) {
        create_pin(PD_Input, PT_Execution, PropertyUtils::make_exec("break"))->show_label();
    }

    create_pin(PD_Output, PT_Execution, PropertyUtils::make_exec("loop_body"))->show_label();
    create_pin(PD_Output, PT_Data, PropertyUtils::make_typed("index", Variant::INT))->show_label();
    create_pin(PD_Output, PT_Execution, PropertyUtils::make_exec("completed"))->show_label();

    if (_with_break) {
        create_pin(PD_Output, PT_Execution, PropertyUtils::make_exec("aborted"))->show_label();
    }

    super::allocate_default_pins();
}

String OScriptNodeForLoop::get_tooltip_text() const {
    return "Executes the 'Loop Body' for each index between the first and last index (inclusive).";
}

String OScriptNodeForLoop::get_node_title() const {
    return vformat("For Loop%s", _with_break ? " With Break" : "");
}

String OScriptNodeForLoop::get_icon() const {
    return "Loop";
}

bool OScriptNodeForLoop::is_loop_port(int p_port) const {
    // Body & Index
    return p_port <= 1;
}

bool OScriptNodeForLoop::is_loop_break_pin(const Ref<OScriptNodePin>& p_pin) {
    return _with_break && p_pin.is_valid() && p_pin->get_pin_name().match("break");
}

void OScriptNodeForLoop::get_actions(List<Ref<OScriptAction>>& p_action_list) {
    if (_with_break) {
        Callable callable = callable_mp_this(_set_with_break).bind(false);
        p_action_list.push_back(memnew(OScriptAction("Remove break pin", "Remove", callable)));
    } else {
        Callable callable = callable_mp_this(_set_with_break).bind(true);
        p_action_list.push_back(memnew(OScriptAction("Add break pin", "Add", callable)));
    }
    super::get_actions(p_action_list);
}

void OScriptNodeForLoop::initialize(const OScriptNodeInitContext& p_context) {
    if (p_context.user_data) {
        const Dictionary& data = p_context.user_data.value();
        if (data.has("with_break")) {
            _with_break = data["with_break"];
        }
    }
    super::initialize(p_context);
}

void OScriptNodeForLoop::_set_with_break(bool p_break_status) {
    _with_break = p_break_status;
    reconstruct_node();
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// OScriptNodeForEach
///

void OScriptNodeForEach::_get_property_list(List<PropertyInfo>* r_list) const {
    r_list->push_back(PropertyInfo(Variant::BOOL, "with_break", PROPERTY_HINT_NONE, "", PROPERTY_USAGE_STORAGE));
    r_list->push_back(PropertyInfo(Variant::INT, "collection_type", PROPERTY_HINT_NONE, "", PROPERTY_USAGE_STORAGE));
}

bool OScriptNodeForEach::_get(const StringName& p_name, Variant& r_value) const {
    if (p_name.match("with_break")) {
        r_value = _with_break;
        return true;
    } else if (p_name.match("collection_type")) {
        r_value = _collection_type;
        return true;
    }
    return false;
}

bool OScriptNodeForEach::_set(const StringName& p_name, const Variant& p_value) {
    if (p_name.match("with_break")) {
        _with_break = p_value;
        _notify_pins_changed();
        return true;
    } else if (p_name.match("collection_type")) {
        _collection_type = VariantUtils::to_type(p_value);
        _notify_pins_changed();
        return true;
    }
    return false;
}

void OScriptNodeForEach::post_initialize() {
    if (_collection_type == Variant::ARRAY) {
        bool reconstructed = false;

        // Automatically coerces old element pins to using NIL for Any rather than OBJECT
        Ref<OScriptNodePin> element = find_pin("element", PD_Output);
        if (element.is_valid() && element->get_type() == Variant::OBJECT) {
            element->set_type(Variant::NIL);
        }

        // Fixes issue where a break pin exists but the break status was not persisted
        if (!_with_break && find_pin("break", PD_Input).is_valid()) {
            _with_break = true;
        }

        // Automatically adjusts old nodes to having the new aborted node layout
        if (_with_break && !find_pin("aborted", PD_Output).is_valid()) {
            reconstruct_node();
            reconstructed = true;

            // This needs to be delayed until the end of frame due to pin index caching
            callable_mp_lambda(this, [&,this]() {
                const Ref<OScriptNodePin> aborted = find_pin("aborted", PD_Output);
                const Ref<OScriptNodePin> completed = find_pin("completed", PD_Output);
                if (aborted.is_valid() && completed.is_valid()) {
                    const Vector<Ref<OScriptNodePin>> targets = completed->get_connections();
                    if (!targets.is_empty()) {
                        aborted->link(targets[0]);
                    }
                }
            }).call_deferred();
        }

        // Fixup - reconstruct element pins
        if (!reconstructed && element.is_valid()) {
            if (PropertyUtils::is_nil_no_variant(element->get_property_info())) {
                reconstruct_node();
                reconstructed = true;
            }
        }
    }

    super::post_initialize();
}

void OScriptNodeForEach::allocate_default_pins() {
    create_pin(PD_Input, PT_Execution, PropertyUtils::make_exec("ExecIn"));

    if (_collection_type == Variant::DICTIONARY) {
        create_pin(PD_Input, PT_Data, PropertyUtils::make_typed("dictionary", Variant::DICTIONARY))->set_flag(OScriptNodePin::IGNORE_DEFAULT);
    } else {
        create_pin(PD_Input, PT_Data, PropertyUtils::make_typed("array", Variant::ARRAY))->set_flag(OScriptNodePin::IGNORE_DEFAULT);
    }

    if (_with_break) {
        create_pin(PD_Input, PT_Execution, PropertyUtils::make_exec("break"))->show_label();
    }

    create_pin(PD_Output, PT_Execution, PropertyUtils::make_exec("loop_body"))->show_label();
    if (_collection_type == Variant::DICTIONARY) {
        create_pin(PD_Output, PT_Data, PropertyUtils::make_variant("key"));
        create_pin(PD_Output, PT_Data, PropertyUtils::make_variant("value"));
    } else {
        create_pin(PD_Output, PT_Data, PropertyUtils::make_variant("element"));
        create_pin(PD_Output, PT_Data, PropertyUtils::make_typed("index", Variant::INT));
    }

    create_pin(PD_Output, PT_Execution, PropertyUtils::make_exec("completed"))->show_label();

    if (_with_break) {
        create_pin(PD_Output, PT_Execution, PropertyUtils::make_exec("aborted"))->show_label();
    }
}

String OScriptNodeForEach::get_tooltip_text() const {
    if (_collection_type == Variant::DICTIONARY) {
        return "Executes the 'Loop Body' for each key-value pair in the dictionary.";
    }
    return "Executes the 'Loop Body' for each element in the array.";
}

String OScriptNodeForEach::get_node_title() const {
    return vformat("For Each%s%s",
        _collection_type == Variant::DICTIONARY ? " Key-Value" : "",
        _with_break ? " With Break" : "");
}

String OScriptNodeForEach::get_icon() const {
    return "Loop";
}

PackedStringArray OScriptNodeForEach::get_keywords() const {
    if (_collection_type == Variant::DICTIONARY) {
        return Array::make("for", "each", "key", "value", "map", "dictionary", "dict", "loop", "range");
    }
    return Array::make("for", "each", "loop", "range", "array");
}

bool OScriptNodeForEach::is_loop_port(int p_port) const {
    // Array: Body, Index, Element
    // Dictionary: Body, Key, Value
    return p_port <= 2;
}

bool OScriptNodeForEach::is_loop_break_pin(const Ref<OScriptNodePin>& p_pin) {
    return _with_break && p_pin.is_valid() && p_pin->get_pin_name().match("break");
}

void OScriptNodeForEach::get_actions(List<Ref<OScriptAction>>& p_action_list) {
    if (_with_break) {
        Callable callable = callable_mp_this(_set_with_break).bind(false);
        p_action_list.push_back(memnew(OScriptAction("Remove break pin", "Remove", callable)));
    } else {
        Callable callable = callable_mp_this(_set_with_break).bind(true);
        p_action_list.push_back(memnew(OScriptAction("Add break pin", "Add", callable)));
    }
    super::get_actions(p_action_list);
}

void OScriptNodeForEach::configure(const OScriptNodeInitContext& p_context) {
    super::configure(p_context);

    // Every configurable value is assigned, defaulting the ones the context does not carry, so
    // that a node describing an action cannot inherit the configuration described before it.
    const Dictionary data = p_context.user_data.value_or(Dictionary());

    _with_break = data.get("with_break", false);
    _collection_type = VariantUtils::to_type(data.get("collection_type", Variant::ARRAY));
}

void OScriptNodeForEach::_set_with_break(bool p_break_status) {
    _with_break = p_break_status;
    reconstruct_node();
}

void OScriptNodeForEach::set_collection_type(Variant::Type p_type) {
    ERR_FAIL_COND_MSG(p_type != Variant::ARRAY && p_type != Variant::DICTIONARY, "ForEach must be ARRAY or DICTIONARY");
    if (_collection_type != p_type) {
        _collection_type = p_type;
        reconstruct_node();
    }
}
