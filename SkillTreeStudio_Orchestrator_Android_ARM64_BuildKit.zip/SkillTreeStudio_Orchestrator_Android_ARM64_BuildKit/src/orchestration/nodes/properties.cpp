// This file is part of the Godot Orchestrator project.
//
// Copyright (c) 2023-present Crater Crash Studios LLC and its contributors.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//		http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
#include "orchestration/nodes/properties.h"

#include "common/dictionary_utils.h"
#include "common/property_utils.h"
#include "common/scene_utils.h"
#include "orchestration/orchestration.h"
#include "script/script_server.h"

#include <godot_cpp/classes/node.hpp>
#include <godot_cpp/classes/scene_tree.hpp>

void OScriptNodeProperty::_get_property_list(List<PropertyInfo>* r_list) const {
    uint32_t mode_usage = PROPERTY_USAGE_STORAGE;
    uint32_t path_usage = PROPERTY_USAGE_STORAGE;
    if (!_node_path.is_empty()) {
        mode_usage |= PROPERTY_USAGE_EDITOR;
        mode_usage |= PROPERTY_USAGE_READ_ONLY;
        path_usage |= PROPERTY_USAGE_EDITOR;
    }

    const String modes = "Self,Instance,Node Path";
    r_list->push_back(PropertyInfo(Variant::INT, "mode", PROPERTY_HINT_ENUM, modes, mode_usage));

    // todo: deprecated, remove in a future release
    r_list->push_back(PropertyInfo(Variant::STRING, "target_class", PROPERTY_HINT_NONE, "", PROPERTY_USAGE_STORAGE));
    r_list->push_back(PropertyInfo(Variant::STRING, "property_name", PROPERTY_HINT_NONE, "", PROPERTY_USAGE_STORAGE));
    r_list->push_back(PropertyInfo(Variant::STRING, "property_hint", PROPERTY_HINT_NONE, "", PROPERTY_USAGE_STORAGE));

    r_list->push_back(PropertyInfo(Variant::NODE_PATH, "node_path", PROPERTY_HINT_NONE, "", path_usage));

    // todo:
    // For now we encode property details at the node and pin level, which is wasteful.
    // Given that property nodes are used infrequently, its not a high priority, but
    // this should be fixed to avoid the duplicity in the pin.
    r_list->push_back(PropertyInfo(Variant::DICTIONARY, "property", PROPERTY_HINT_NONE, "", PROPERTY_USAGE_STORAGE));
}

bool OScriptNodeProperty::_get(const StringName& p_name, Variant& r_value) const {
    if (p_name.match("mode")) {
        r_value = _call_mode;
        return true;
    } else if (p_name.match("target_class")) {
        r_value = _base_type;
        return true;
    } else if (p_name.match("property_name")) {
        r_value = _property.name;
        return true;
    } else if (p_name.match("property_hint")) {
        r_value = _property.hint_string;
        return true;
    } else if (p_name.match("property")) {
        r_value = DictionaryUtils::from_property(_property);
        return true;
    } else if (p_name.match("node_path")) {
        r_value = _node_path;
        return true;
    }
    return false;
}

bool OScriptNodeProperty::_set(const StringName& p_name, const Variant& p_value) {
    if (p_name.match("mode")) {
        _call_mode = CallMode(int(p_value));
        return true;
    } else if (p_name.match("target_class")) {
        _base_type = p_value;
        return true;
    } else if (p_name.match("property_name")) {
        _property.name = p_value;
        return true;
    } else if (p_name.match("property_hint")) {
        _property.hint_string = p_value;
        return true;
    } else if (p_name.match("property")) {
        _property = DictionaryUtils::to_property(p_value);
        _has_property = true;
        return true;
    } else if (p_name.match("node_path")) {
        _node_path = p_value;

        if (_initialized) {
            // Make sure that when changed, if it's a unique-named node, we use the unique name
            if (Node* base_node = _get_scene_base_node()) {
                if (Node* node = base_node->get_node_or_null(_node_path)) {
                    if (!_node_path.get_concatenated_names().begins_with("%") && node->is_unique_name_in_owner()) {
                        _node_path = "%" + node->get_name();
                    }
                }
            }
        }

        return true;
    }
    return false;
}

Node* OScriptNodeProperty::_get_scene_base_node() const {
    if (_is_in_editor() && !_node_path.is_empty()) {
        return SceneUtils::get_scene_base_node(get_orchestration()->get_self());
    }
    return nullptr;
}

bool OScriptNodeProperty::_property_exists(const TypedArray<Dictionary>& p_properties) const {
    for (int index = 0; index < p_properties.size(); ++index) {
        const Dictionary& property = p_properties[index];
        if (property.has("name") && _property.name.match(property["name"]))
            return true;
    }
    return false;
}

TypedArray<Dictionary> OScriptNodeProperty::_get_class_property_list(const String& p_class_name) const {
    if (ScriptServer::is_global_class(p_class_name)) {
        return ScriptServer::get_global_class(p_class_name).get_property_list();
    }
    return ClassDB::class_get_property_list(p_class_name);
}

bool OScriptNodeProperty::_get_class_property(const String& p_class_name, const String& p_name, PropertyInfo& r_property) {
    const TypedArray<Dictionary> properties = _get_class_property_list(p_class_name);
    for (int index = 0; index < properties.size(); index++) {
        const Dictionary& dict = properties[index];
        if (dict.has("name") && p_name.match(dict["name"])) {
            r_property = DictionaryUtils::to_property(dict);
            return true;
        }
    }
    return false;
}

bool OScriptNodeProperty::_is_same_or_parent(const String& p_target_class) const {
    return _orchestration->get_base_type() == p_target_class
        || ClassDB::is_parent_class(_orchestration->get_base_type(), p_target_class);
}

void OScriptNodeProperty::_upgrade(uint32_t p_version, uint32_t p_current_version) {
    if (p_version == 1 && p_current_version >= 2) {
        if (!_has_property) {
            if (_call_mode == CALL_INSTANCE) {
                String class_name = _base_type;
                if (class_name.is_empty()) {
                    // Base type was never encoded into the node.
                    // Attempt to resolve the base type based on the connection, if possible.
                    const Ref<OScriptNodePin> target = find_pin("target", PD_Input);
                    if (target.is_valid() && target->has_any_connections()) {
                        const Ref<OScriptNodePin> source = target->get_resolved_connection();
                        if (source.is_valid()) {
                            const PropertyInfo& pi = source->get_property_info();
                            if (pi.type == Variant::OBJECT && !pi.class_name.is_empty())
                                class_name = pi.class_name;
                        }
                    }
                }

                // todo: what if the target should be a super type?

                PropertyInfo property;
                if (_get_class_property(class_name, _property.name, property)) {
                    _base_type = class_name;
                    _property = property;
                    _has_property = true;
                }
            } else if (_call_mode == CALL_SELF) {
                PropertyInfo property;
                if (_get_class_property(get_orchestration()->get_base_type(), _property.name, property)) {
                    _property = property;
                    _has_property = true;
                }
            } else if (_call_mode == CALL_NODE_PATH) {
                // todo: how to fix this?
            }

            if (_has_property) {
                reconstruct_node();
            }
        }
    }

    super::_upgrade(p_version, p_current_version);
}

void OScriptNodeProperty::post_initialize() {
    // Cache property details in node
    for (const Ref<OScriptNodePin>& pin : get_all_pins()) {
        if (pin->get_pin_name().match(_property.name)) {
            _property = pin->get_property_info();
            break;
        }
    }

    super::post_initialize();
}

String OScriptNodeProperty::get_icon() const {
    return "MemberProperty";
}

String OScriptNodeProperty::get_help_topic() const {
    switch (_call_mode) {
        case CALL_INSTANCE:
            return vformat("class_property:%s:%s", _base_type, _property.name);
        case CALL_SELF:
            return vformat("class_property:%s:%s", get_orchestration()->get_base_type(), _property.name);
        case CALL_NODE_PATH: {
            if (SceneTree* st = SceneTree::get_singleton()) {
                Node* node = st->get_edited_scene_root()->get_node_or_null(_node_path);
                if (node) {
                    return vformat("class_property:%s:%s", node->get_class(), _property.name);
                }
            }
            break;
        }
        default:
            break;
    }
    return super::get_help_topic();
}

Ref<Resource> OScriptNodeProperty::get_inspect_object() {
    if (_is_in_editor()) {
        if (Node* base_node = _get_scene_base_node()) {
            set_meta("__base_node_relative", base_node);
        }
    }
    return super::get_inspect_object();
}

void OScriptNodeProperty::initialize(const OScriptNodeInitContext& p_context) {
    ERR_FAIL_COND_MSG(!p_context.property, "A property node requires a PropertyInfo");

    const PropertyInfo& pi = p_context.property.value();
    _property = pi;
    _has_property = true;

    if (p_context.node_path) {
        _call_mode = CALL_NODE_PATH;
        _node_path = p_context.node_path.value();
    } else if (p_context.class_name) {
        _call_mode = CALL_INSTANCE;
        _base_type = p_context.class_name.value();
    } else {
        _call_mode = CALL_SELF;
    }

    super::initialize(p_context);
}

void OScriptNodeProperty::_bind_methods() {
    BIND_ENUM_CONSTANT(CallMode::CALL_SELF)
    BIND_ENUM_CONSTANT(CallMode::CALL_INSTANCE)
    BIND_ENUM_CONSTANT(CallMode::CALL_NODE_PATH)
}

OScriptNodeProperty::OScriptNodeProperty() {
    _flags = NONE;
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// OScriptNodePropertyGet
///

void OScriptNodePropertyGet::allocate_default_pins() {
    if (_call_mode == CALL_INSTANCE) {
        Ref<OScriptNodePin> target = create_pin(PD_Input, PT_Data, PropertyUtils::make_object("target", _base_type));
        target->set_label(_base_type);
        target->no_pretty_format();
    }

    create_pin(PD_Output, PT_Data, _property);
}

String OScriptNodePropertyGet::get_tooltip_text() const {
    if (!_property.name.is_empty()) {
        String tooltip = vformat("Returns the value of the property '%s'.", _property.name);
        if (!_node_path.is_empty()) {
            tooltip += "\nNode Path: " + _node_path;
        }
        return tooltip;
    }
    return "Returns the value of a given property";
}

String OScriptNodePropertyGet::get_node_title() const {
    return vformat("Get %s%s", _property.name.capitalize(), _call_mode == CALL_SELF ? " (Self)" : "");
}

StringName OScriptNodePropertyGet::resolve_type_class(const Ref<OScriptNodePin>& p_pin) const {
    if (p_pin.is_valid() && p_pin->is_output()) {
        if (!_property.hint_string.is_empty()) {
            return _property.hint_string;
        }
        if (!_base_type.is_empty()) {
            return _base_type;
        }
    }
    return super::resolve_type_class(p_pin);
}

void OScriptNodePropertyGet::initialize(const OScriptNodeInitContext& p_context) {
    super::initialize(p_context);
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// OScriptNodePropertySet
///

void OScriptNodePropertySet::allocate_default_pins() {
    create_pin(PD_Input, PT_Execution, PropertyUtils::make_exec("ExecIn"));

    if (_call_mode == CALL_INSTANCE) {
        Ref<OScriptNodePin> target = create_pin(PD_Input, PT_Data, PropertyUtils::make_object("target", _base_type));
        target->set_label(_base_type);
        target->no_pretty_format();
    }

    create_pin(PD_Input, PT_Data, _property);
    create_pin(PD_Output, PT_Execution, PropertyUtils::make_exec("ExecOut"));
}

String OScriptNodePropertySet::get_tooltip_text() const {
    if (!_property.name.is_empty()) {
        String tooltip = vformat("Sets the value of the property '%s'", _property.name);
        if (!_node_path.is_empty()) {
            tooltip += "\nNode Path: " + _node_path;
        }
        return tooltip;
    }

    return "Sets the value for a given property";
}

String OScriptNodePropertySet::get_node_title() const {
    return vformat("Set %s%s", _property.name.capitalize(), _call_mode == CALL_SELF ? " (Self)" : "");
}

void OScriptNodePropertySet::set_default_value(const Variant& p_default_value) {
    find_pin(1, PD_Input)->set_default_value(p_default_value);
}