// This file is part of the Godot Orchestrator project.
//
// Copyright (c) 2023-present Crater Crash Studios LLC and its contributors.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//		http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
#include "orchestration/nodes/await.h"

#include "common/property_utils.h"

void OScriptNodeAwait::_upgrade(uint32_t p_version, uint32_t p_current_version) {
    if (find_pin("result", PD_Output).is_null()) {
        reconstruct_node();
    }
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// OScriptNodeAwaitSignal

void OScriptNodeAwaitSignal::allocate_default_pins() {
    create_pin(PD_Input, PT_Execution, PropertyUtils::make_exec("ExecIn"));
    create_pin(PD_Input, PT_Data, PropertyUtils::make_object("target"));
    create_pin(PD_Input, PT_Data, PropertyUtils::make_typed("signal_name", Variant::STRING));
    create_pin(PD_Output, PT_Execution, PropertyUtils::make_exec("ExecOut"));
    create_pin(PD_Output, PT_Data, PropertyUtils::make_variant("result"));
    super::allocate_default_pins();
}

String OScriptNodeAwaitSignal::get_tooltip_text() const {
    return "Yields/Awaits the script's execution until the given signal occurs.";
}

String OScriptNodeAwaitSignal::get_node_title() const {
    return "Await Signal";
}

void OScriptNodeAwaitSignal::on_pin_disconnected(const Ref<OScriptNodePin>& p_pin) {
    // Makes sure that signal list pin changes to string renderer
    if (p_pin.is_valid() && p_pin->get_pin_name().match("target")) {
        _notify_pins_changed();
    }
    super::on_pin_disconnected(p_pin);
}

PackedStringArray OScriptNodeAwaitSignal::get_suggestions(const Ref<OScriptNodePin>& p_pin) {
    if (p_pin.is_valid() && p_pin->is_input() && p_pin->get_pin_name().match("signal_name")) {
        const Ref<OScriptNodePin> target_pin = find_pin("target", PD_Input);
        if (target_pin.is_valid()) {
            return target_pin->resolve_signal_names(true);
        }
    }
    return super::get_suggestions(p_pin);
}