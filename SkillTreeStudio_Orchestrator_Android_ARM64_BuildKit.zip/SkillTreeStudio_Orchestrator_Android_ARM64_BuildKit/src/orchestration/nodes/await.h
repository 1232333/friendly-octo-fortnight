// This file is part of the Godot Orchestrator project.
//
// Copyright (c) 2023-present Crater Crash Studios LLC and its contributors.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//		http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
#pragma once

#include "orchestration/node.h"

/// Base class for all Await-based nodes
class OScriptNodeAwait : public OScriptNode {
    ORCHESTRATOR_NODE_CLASS(OScriptNodeAwait, OScriptNode);

protected:
    static void _bind_methods() { }

    //~ Begin OScriptNode Interface
    void _upgrade(uint32_t p_version, uint32_t p_current_version) override;
    //~ End OScriptNode Interface
};

/// Awaits Member Signals
class OScriptNodeAwaitSignal : public OScriptNodeAwait {
    ORCHESTRATOR_NODE_CLASS(OScriptNodeAwaitSignal, OScriptNodeAwait);

protected:
    static void _bind_methods() { }

public:
    //~ Begin OScriptNode Interface
    void allocate_default_pins() override;
    String get_tooltip_text() const override;
    String get_node_title() const override;
    String get_node_title_color_name() const override { return "signals"; }
    void on_pin_disconnected(const Ref<OScriptNodePin>& p_pin) override;
    PackedStringArray get_suggestions(const Ref<OScriptNodePin>& p_pin) override;
    //~ End OScriptNode Interface
};