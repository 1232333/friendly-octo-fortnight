// This file is part of the Godot Orchestrator project.
//
// Copyright (c) 2023-present Crater Crash Studios LLC and its contributors.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//		http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
#include "core/register_core_types.h"

#include "common/settings.h"
#include "core/godot/core_string_names.h"
#include "core/godot/scene_string_names.h"
#include "godot/config/project_settings_cache.h"
#include "script/script_server.h"

#include <godot_cpp/core/class_db.hpp>

void register_core_singletons() {
    GDREGISTER_INTERNAL_CLASS(OrchestratorSettings);
    GDREGISTER_INTERNAL_CLASS(OrchestratorProjectSettingsCache);
}

void unregister_core_singletons() {

}

void create_core_singletons() {
    CoreStringNames::create();
    SceneStringNames::create();
    ScriptServer::create();

    OrchestratorSettings::create();
    OrchestratorProjectSettingsCache::create();
}

void destroy_core_singletons() {
    OrchestratorProjectSettingsCache::destroy();
    OrchestratorSettings::destroy();

    ScriptServer::free();
    SceneStringNames::free();
    CoreStringNames::free();
}