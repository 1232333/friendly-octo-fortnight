// This file is part of the Godot Orchestrator project.
//
// Copyright (c) 2023-present Crater Crash Studios LLC and its contributors.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//		http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
#include "script/script_warning.h"

#ifdef DEBUG_ENABLED

// Taken from core/string/ustring.h
#define PNAME(m_value) (m_value)

String OScriptWarning::get_message() const {
    #define CHECK_SYMBOLS(m_amount) ERR_FAIL_COND_V(symbols.size() < m_amount, String());
	switch (code) {
		case UNASSIGNED_VARIABLE:
			CHECK_SYMBOLS(1);
			return vformat(R"(The variable "%s" is used before being assigned a value.)", symbols[0]);
		case UNASSIGNED_VARIABLE_OP_ASSIGN:
			CHECK_SYMBOLS(2);
			return vformat(R"(The variable "%s" is modified with the compound-assignment operator "%s=" but was not previously initialized.)", symbols[0], symbols[1]);
		case UNUSED_VARIABLE:
			CHECK_SYMBOLS(1);
			return vformat(R"(The local variable "%s" is declared but never used in the block. If this is intended, prefix it with an underscore: "_%s".)", symbols[0], symbols[0]);
		case UNUSED_LOCAL_CONSTANT:
			CHECK_SYMBOLS(1);
			return vformat(R"(The local constant "%s" is declared but never used in the block. If this is intended, prefix it with an underscore: "_%s".)", symbols[0], symbols[0]);
		case UNUSED_PRIVATE_CLASS_VARIABLE:
			CHECK_SYMBOLS(1);
			return vformat(R"(The class variable "%s" is declared but never used in the class.)", symbols[0]);
		case UNUSED_PARAMETER:
			CHECK_SYMBOLS(2);
			return vformat(R"*(The parameter "%s" is never used in the function "%s()". If this is intended, prefix it with an underscore: "_%s".)*", symbols[1], symbols[0], symbols[1]);
		case UNUSED_SIGNAL:
			CHECK_SYMBOLS(1);
			return vformat(R"(The signal "%s" is declared but never explicitly used in the class.)", symbols[0]);
		case SHADOWED_VARIABLE:
			CHECK_SYMBOLS(3);
			return vformat(R"(The local %s "%s" is shadowing an already-declared %s in the current class.)", symbols[0], symbols[1], symbols[2]);
		case SHADOWED_VARIABLE_BASE_CLASS:
			CHECK_SYMBOLS(4);
			if (symbols.size() > 4) {
				return vformat(R"(The local %s "%s" is shadowing an already-declared %s at line %s in the base class "%s".)", symbols[0], symbols[1], symbols[2], symbols[3], symbols[4]);
			}
			return vformat(R"(The local %s "%s" is shadowing an already-declared %s in the base class "%s".)", symbols[0], symbols[1], symbols[2], symbols[3]);
		case SHADOWED_GLOBAL_IDENTIFIER:
			CHECK_SYMBOLS(3);
			return vformat(R"(The %s "%s" has the same name as a %s.)", symbols[0], symbols[1], symbols[2]);
		case UNREACHABLE_CODE:
			CHECK_SYMBOLS(1);
			return vformat(R"*(Unreachable code (statement after return) in function "%s()".)*", symbols[0]);
		case UNREACHABLE_PATTERN:
			return "Unreachable pattern (pattern after wildcard or bind).";
		case STANDALONE_EXPRESSION:
			return "Standalone expression (the line may have no effect).";
		case STANDALONE_TERNARY:
			return "Standalone ternary operator (the return value is being discarded).";
		case INCOMPATIBLE_TERNARY:
			return "Values of the ternary operator are not mutually compatible.";
		case UNTYPED_DECLARATION:
			CHECK_SYMBOLS(2);
			if (symbols[0] == "Function") {
				return vformat(R"*(%s "%s()" has no static return type.)*", symbols[0], symbols[1]);
			}
			return vformat(R"(%s "%s" has no static type.)", symbols[0], symbols[1]);
		case INFERRED_DECLARATION:
			CHECK_SYMBOLS(2);
			return vformat(R"(%s "%s" has an implicitly inferred static type.)", symbols[0], symbols[1]);
		case UNSAFE_PROPERTY_ACCESS:
			CHECK_SYMBOLS(2);
			return vformat(R"(The property "%s" is not present on the inferred type "%s" (but may be present on a subtype).)", symbols[0], symbols[1]);
		case UNSAFE_METHOD_ACCESS:
			CHECK_SYMBOLS(2);
			return vformat(R"*(The method "%s()" is not present on the inferred type "%s" (but may be present on a subtype).)*", symbols[0], symbols[1]);
		case UNSAFE_CAST:
			CHECK_SYMBOLS(1);
			return vformat(R"(Casting "Variant" to "%s" is unsafe.)", symbols[0]);
		case UNSAFE_CALL_ARGUMENT:
			CHECK_SYMBOLS(5);
			return vformat(R"*(The argument %s of the %s "%s()" requires the subtype "%s" but the supertype "%s" was provided.)*", symbols[0], symbols[1], symbols[2], symbols[3], symbols[4]);
		case UNSAFE_VOID_RETURN:
			CHECK_SYMBOLS(2);
			return vformat(R"*(The method "%s()" returns "void" but it's trying to return a call to "%s()" that can't be ensured to also be "void".)*", symbols[0], symbols[1]);
		case RETURN_VALUE_DISCARDED:
			CHECK_SYMBOLS(1);
			return vformat(R"*(The function "%s()" returns a value that will be discarded if not used.)*", symbols[0]);
		case STATIC_CALLED_ON_INSTANCE:
			CHECK_SYMBOLS(2);
			return vformat(R"*(The function "%s()" is a static function but was called from an instance. Instead, it should be directly called from the type: "%s.%s()".)*", symbols[0], symbols[1], symbols[0]);
		case MISSING_TOOL:
			return R"(The base class script has the "@tool" annotation, but this script does not have it.)";
		case REDUNDANT_STATIC_UNLOAD:
			return R"(The "@static_unload" annotation is redundant because the file does not have a class with static variables.)";
		case REDUNDANT_AWAIT:
			return R"("await" keyword is unnecessary because the expression isn't a coroutine nor a signal.)";
		case MISSING_AWAIT:
			return R"("await" keyword might be desired because the expression is a coroutine.)";
		case ASSERT_ALWAYS_TRUE:
			return "Assert statement is redundant because the expression is always true.";
		case ASSERT_ALWAYS_FALSE:
			return "Assert statement will raise an error because the expression is always false.";
		case INTEGER_DIVISION:
			return "Integer division. Decimal part will be discarded.";
		case NARROWING_CONVERSION:
			return "Narrowing conversion (float is converted to int and loses precision).";
		case INT_AS_ENUM_WITHOUT_CAST:
			return "Integer used when an enum value is expected. If this is intended, cast the integer to the enum type using the \"as\" keyword.";
		case INT_AS_ENUM_WITHOUT_MATCH:
			CHECK_SYMBOLS(3);
			return vformat(R"(Cannot %s %s as Enum "%s": no enum member has matching value.)", symbols[0], symbols[1], symbols[2]);
		case ENUM_VARIABLE_WITHOUT_DEFAULT:
			CHECK_SYMBOLS(1);
			return vformat(R"(The variable "%s" has an enum type and does not set an explicit default value. The default will be set to "0".)", symbols[0]);
		case EMPTY_FILE:
			return "Empty script file.";
		case DEPRECATED_KEYWORD:
			CHECK_SYMBOLS(2);
			return vformat(R"(The "%s" keyword is deprecated and will be removed in a future release. Please replace it with "%s".)", symbols[0], symbols[1]);
		case CONFUSABLE_IDENTIFIER:
			CHECK_SYMBOLS(1);
			return vformat(R"(The identifier "%s" has misleading characters and might be confused with something else.)", symbols[0]);
		case CONFUSABLE_LOCAL_DECLARATION:
			CHECK_SYMBOLS(2);
			return vformat(R"(The %s "%s" is declared below in the parent block.)", symbols[0], symbols[1]);
		case CONFUSABLE_LOCAL_USAGE:
			CHECK_SYMBOLS(1);
			return vformat(R"(The identifier "%s" will be shadowed below in the block.)", symbols[0]);
		case CONFUSABLE_CAPTURE_REASSIGNMENT:
			CHECK_SYMBOLS(1);
			return vformat(R"(Reassigning lambda capture does not modify the outer local variable "%s".)", symbols[0]);
		case INFERENCE_ON_VARIANT:
			CHECK_SYMBOLS(1);
			return vformat("The %s type is being inferred from a Variant value, so it will be typed as Variant.", symbols[0]);
		case NATIVE_METHOD_OVERRIDE:
			CHECK_SYMBOLS(2);
			return vformat(R"*(The method "%s()" overrides a method from native class "%s". This won't be called by the engine and may not work as expected.)*", symbols[0], symbols[1]);
		case GET_NODE_DEFAULT_WITHOUT_ONREADY:
			CHECK_SYMBOLS(1);
			return vformat(R"*(The default value uses "%s" which won't return nodes in the scene tree before "_ready()" is called. Use the "@onready" annotation to solve this.)*", symbols[0]);
		case ONREADY_WITH_EXPORT:
			return R"("@onready" will set the default value after "@export" takes effect and will override it.)";
        #ifndef DISABLE_DEPRECATED
		// Never produced. These warnings migrated from 3.x by mistake.
		case PROPERTY_USED_AS_FUNCTION: // There is already an error.
		case CONSTANT_USED_AS_FUNCTION: // There is already an error.
		case FUNCTION_USED_AS_PROPERTY: // This is valid, returns `Callable`.
			break;
        #endif // DISABLE_DEPRECATED
		case WARNING_MAX:
			break; // Can't happen, but silences warning.
	}
	ERR_FAIL_V_MSG(String(), vformat(R"(Invalid OScript warning "%s".)", get_name_from_code(code)));
    #undef CHECK_SYMBOLS
}

int OScriptWarning::get_default_value(Code p_code) {
	ERR_FAIL_INDEX_V_MSG(p_code, WARNING_MAX, WarnLevel::IGNORE, "Getting default value of invalid warning code.");
	return default_warning_levels[p_code];
}

PropertyInfo OScriptWarning::get_property_info(Code p_code) {
	return PropertyInfo(Variant::INT, get_setting_path_from_code(p_code), PROPERTY_HINT_ENUM, "Ignore,Warn,Error");
}

String OScriptWarning::get_name() const {
	return get_name_from_code(code);
}

String OScriptWarning::get_name_from_code(Code p_code) {
	ERR_FAIL_COND_V(p_code < 0 || p_code >= WARNING_MAX, String());

	static const char *names[] = {
		PNAME("UNASSIGNED_VARIABLE"),
		PNAME("UNASSIGNED_VARIABLE_OP_ASSIGN"),
		PNAME("UNUSED_VARIABLE"),
		PNAME("UNUSED_LOCAL_CONSTANT"),
		PNAME("UNUSED_PRIVATE_CLASS_VARIABLE"),
		PNAME("UNUSED_PARAMETER"),
		PNAME("UNUSED_SIGNAL"),
		PNAME("SHADOWED_VARIABLE"),
		PNAME("SHADOWED_VARIABLE_BASE_CLASS"),
		PNAME("SHADOWED_GLOBAL_IDENTIFIER"),
		PNAME("UNREACHABLE_CODE"),
		PNAME("UNREACHABLE_PATTERN"),
		PNAME("STANDALONE_EXPRESSION"),
		PNAME("STANDALONE_TERNARY"),
		PNAME("INCOMPATIBLE_TERNARY"),
		PNAME("UNTYPED_DECLARATION"),
		PNAME("INFERRED_DECLARATION"),
		PNAME("UNSAFE_PROPERTY_ACCESS"),
		PNAME("UNSAFE_METHOD_ACCESS"),
		PNAME("UNSAFE_CAST"),
		PNAME("UNSAFE_CALL_ARGUMENT"),
		PNAME("UNSAFE_VOID_RETURN"),
		PNAME("RETURN_VALUE_DISCARDED"),
		PNAME("STATIC_CALLED_ON_INSTANCE"),
		PNAME("MISSING_TOOL"),
		PNAME("REDUNDANT_STATIC_UNLOAD"),
		PNAME("REDUNDANT_AWAIT"),
		PNAME("MISSING_AWAIT"),
		PNAME("ASSERT_ALWAYS_TRUE"),
		PNAME("ASSERT_ALWAYS_FALSE"),
		PNAME("INTEGER_DIVISION"),
		PNAME("NARROWING_CONVERSION"),
		PNAME("INT_AS_ENUM_WITHOUT_CAST"),
		PNAME("INT_AS_ENUM_WITHOUT_MATCH"),
		PNAME("ENUM_VARIABLE_WITHOUT_DEFAULT"),
		PNAME("EMPTY_FILE"),
		PNAME("DEPRECATED_KEYWORD"),
		PNAME("CONFUSABLE_IDENTIFIER"),
		PNAME("CONFUSABLE_LOCAL_DECLARATION"),
		PNAME("CONFUSABLE_LOCAL_USAGE"),
		PNAME("CONFUSABLE_CAPTURE_REASSIGNMENT"),
		PNAME("INFERENCE_ON_VARIANT"),
		PNAME("NATIVE_METHOD_OVERRIDE"),
		PNAME("GET_NODE_DEFAULT_WITHOUT_ONREADY"),
		PNAME("ONREADY_WITH_EXPORT"),
        #ifndef DISABLE_DEPRECATED
		"PROPERTY_USED_AS_FUNCTION",
		"CONSTANT_USED_AS_FUNCTION",
		"FUNCTION_USED_AS_PROPERTY",
        #endif // DISABLE_DEPRECATED
	};

	static_assert(std_size(names) == WARNING_MAX, "Amount of warning types don't match the amount of warning names.");
    return names[static_cast<int>(p_code)];
}

String OScriptWarning::get_setting_path_from_code(Code p_code) {
	return "debug/warnings/" + get_name_from_code(p_code).to_lower();
}

OScriptWarning::Code OScriptWarning::get_code_from_name(const String &p_name) {
	for (int i = 0; i < WARNING_MAX; i++) {
	    const Code code = static_cast<Code>(i);
	    if (get_name_from_code(code) == p_name) {
	        return code;
		}
	}

	return WARNING_MAX;
}

#endif // DEBUG_ENABLED