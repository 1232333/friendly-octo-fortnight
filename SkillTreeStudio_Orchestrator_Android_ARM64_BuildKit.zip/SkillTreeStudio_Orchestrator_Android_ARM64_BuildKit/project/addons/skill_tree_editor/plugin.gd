@tool
extends EditorPlugin

const StudioScript = preload("res://addons/skill_tree_editor/editor/studio_main.gd")
var studio: Control

func _enter_tree() -> void:
    studio = StudioScript.new()
    studio.name = "成长树"
    get_editor_interface().get_editor_main_screen().add_child(studio)
    studio.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    studio.hide()

func _exit_tree() -> void:
    if is_instance_valid(studio):
        get_editor_interface().get_editor_main_screen().remove_child(studio)
        studio.queue_free()
    studio = null

func _has_main_screen() -> bool:
    return true

func _make_visible(visible: bool) -> void:
    if is_instance_valid(studio):
        studio.visible = visible

func _get_plugin_name() -> String:
    return "成长树"

func _get_plugin_icon() -> Texture2D:
    return get_editor_interface().get_editor_theme().get_icon("Node2D", "EditorIcons")
