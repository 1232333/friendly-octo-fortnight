@tool
extends VBoxContainer
signal node_selected(node_id: String)

var tree_data: GrowthTree
var list: ItemList
var _visible_node_ids: Array[String] = []

func _ready() -> void:
	var title := Label.new()
	title.text = "已创建节点"
	title.add_theme_font_size_override("font_size", 15)
	add_child(title)
	list = ItemList.new()
	list.size_flags_vertical = Control.SIZE_EXPAND_FILL
	list.select_mode = ItemList.SELECT_SINGLE
	list.custom_minimum_size.y = 120
	add_child(list)
	list.item_selected.connect(_on_item_selected)

func set_tree(value: GrowthTree) -> void:
	tree_data = value
	refresh()

func refresh() -> void:
	if list == null:
		return
	var previously_selected := ""
	var selected_rows := list.get_selected_items()
	if not selected_rows.is_empty() and selected_rows[0] >= 0 and selected_rows[0] < _visible_node_ids.size():
		previously_selected = _visible_node_ids[selected_rows[0]]
	list.clear()
	_visible_node_ids.clear()
	if tree_data == null:
		return
	for item in tree_data.nodes:
		if item == null:
			continue
		var label := "%s  ·  %s" % [_type_name(item.node_type), item.title]
		if item.icon == null and not item.blueprint_visual_enabled:
			label += "  [透明]"
		elif item.icon == null:
			label += "  [蓝图外观]"
		list.add_item(label)
		_visible_node_ids.append(item.id)
	if not previously_selected.is_empty():
		select_id(previously_selected)

func select_id(node_id: String) -> void:
	if list == null:
		return
	var index := _visible_node_ids.find(node_id)
	if index >= 0:
		list.select(index)

func _on_item_selected(index: int) -> void:
	if index < 0 or index >= _visible_node_ids.size():
		return
	node_selected.emit(_visible_node_ids[index])

func _type_name(value: int) -> String:
	var names := ["被动技能", "科技研究", "时代", "天赋", "条件", "奖励", "普通", "分支", "事件", "主动技能", "终极技能", "技能强化", "科技解锁", "攻击天赋", "防御天赋", "生命天赋", "速度天赋", "暴击天赋"]
	return names[clampi(value, 0, names.size() - 1)]
