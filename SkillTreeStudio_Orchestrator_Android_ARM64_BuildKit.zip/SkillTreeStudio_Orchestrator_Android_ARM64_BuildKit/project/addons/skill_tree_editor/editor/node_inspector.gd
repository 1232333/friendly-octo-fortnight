@tool
extends VBoxContainer
signal changed
signal edit_script_requested

var current: GrowthTreeNode
var fields: Dictionary = {}
var content: VBoxContainer
var type_controls: Array[Control] = []
var building_type_fields := false
var blueprint_list: ItemList
const BlueprintScript = preload("res://addons/skill_tree_editor/data/node_blueprint.gd")

const TYPE_NAMES := ["被动技能节点", "科技研究节点", "时代节点", "天赋节点", "条件节点", "奖励节点", "普通节点", "分支节点", "事件节点", "主动技能节点", "终极技能节点", "技能强化节点", "科技解锁节点", "攻击天赋节点", "防御天赋节点", "生命天赋节点", "速度天赋节点", "暴击天赋节点"]

func _ready() -> void:
	add_theme_constant_override("separation", 10)
	var heading := Label.new()
	heading.text = "节点属性"
	heading.add_theme_font_size_override("font_size", 19)
	add_child(heading)
	var hint := Label.new()
	hint.text = "选择节点后编辑专属数据"
	hint.modulate = Color("#9ba8ba")
	add_child(hint)
	content = VBoxContainer.new()
	content.add_theme_constant_override("separation", 8)
	add_child(content)
	_build_general_fields()
	_build_blueprint_fields()
	edit_node(null)

func _label(text_value: String) -> void:
	var label := Label.new()
	label.text = text_value
	label.add_theme_color_override("font_color", Color("#c7d2e2"))
	content.add_child(label)
	if building_type_fields:
		type_controls.append(label)

func _add_control(key: String, control: Control) -> void:
	fields[key] = control
	control.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	content.add_child(control)
	if building_type_fields:
		type_controls.append(control)

func _build_general_fields() -> void:
	_label("节点名称")
	var title := LineEdit.new()
	title.placeholder_text = "输入节点名称"
	_add_control("title", title)
	title.text_changed.connect(func(v: String): _apply("title", v))
	_label("节点说明")
	var desc := TextEdit.new()
	desc.custom_minimum_size.y = 76
	desc.placeholder_text = "描述节点用途、效果或规则…"
	_add_control("description", desc)
	desc.text_changed.connect(func(): _apply("description", desc.text))
	_label("节点图片")
	var picker := EditorResourcePicker.new()
	picker.base_type = "Texture2D"
	_add_control("icon", picker)
	picker.resource_changed.connect(func(v: Resource):
		if current != null and (v == null or v is Texture2D):
			current.icon = v
			changed.emit()
	)
	var show := CheckBox.new()
	show.text = "在图片下方显示名称"
	_add_control("show_title", show)
	show.toggled.connect(func(v: bool): _apply("show_title", v))
	_label("最大等级")
	var levels := _spin(1, 999, 1)
	_add_control("max_level", levels)
	levels.value_changed.connect(func(v: float): _apply("max_level", int(v)))

func _build_blueprint_fields() -> void:
	_label("节点脚本 / 蓝图")
	var edit_script_button := Button.new()
	edit_script_button.text = "编辑脚本（打开节点蓝图）"
	edit_script_button.custom_minimum_size.y = 38
	content.add_child(edit_script_button)
	edit_script_button.pressed.connect(func():
		if current != null:
			edit_script_requested.emit()
	)
	var library_hint := Label.new()
	library_hint.text = "进入节点脚本页面后，长按蓝图画布空白处打开蓝图库。"
	library_hint.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	library_hint.add_theme_color_override("font_color", Color("#9ba8ba"))
	content.add_child(library_hint)
	_label("已绑定蓝图")
	blueprint_list = ItemList.new()
	blueprint_list.custom_minimum_size.y = 72
	content.add_child(blueprint_list)
	var remove_button := Button.new()
	remove_button.text = "解除选中蓝图"
	content.add_child(remove_button)
	remove_button.pressed.connect(_remove_blueprint)

func _remove_blueprint() -> void:
	if current == null or blueprint_list == null:
		return
	var selected := blueprint_list.get_selected_items()
	if selected.is_empty():
		return
	if selected[0] >= 0 and selected[0] < current.blueprint_refs.size():
		current.blueprint_refs.remove_at(selected[0])
		current.emit_changed()
		_refresh_blueprints()
		changed.emit()

func _refresh_blueprints() -> void:
	if blueprint_list == null:
		return
	blueprint_list.clear()
	if current == null:
		return
	for resource in current.blueprint_refs:
		if resource != null:
			var label := resource.resource_path.get_file() if not resource.resource_path.is_empty() else resource.resource_name
			blueprint_list.add_item(label)

func _spin(minimum: float, maximum: float, step_value: float = 1.0) -> SpinBox:
	var spin := SpinBox.new()
	spin.min_value = minimum
	spin.max_value = maximum
	spin.step = step_value
	spin.rounded = step_value >= 1.0
	return spin

func _line(key: String, caption: String, placeholder: String = "") -> void:
	_label(caption)
	var field := LineEdit.new()
	field.placeholder_text = placeholder
	_add_control(key, field)
	field.text_changed.connect(func(v: String): _apply(key, v))

func _multi(key: String, caption: String, placeholder: String = "") -> void:
	_label(caption)
	var field := TextEdit.new()
	field.custom_minimum_size.y = 68
	field.placeholder_text = placeholder
	_add_control(key, field)
	field.text_changed.connect(func(): _apply(key, field.text))

func _number(key: String, caption: String, minimum: float = -100000000.0, maximum: float = 100000000.0, step_value: float = 1.0) -> void:
	_label(caption)
	var field := _spin(minimum, maximum, step_value)
	_add_control(key, field)
	field.value_changed.connect(func(v: float): _apply(key, v))

func _choice(key: String, caption: String, labels: Array[String]) -> void:
	_label(caption)
	var field := OptionButton.new()
	for item in labels:
		field.add_item(item)
	_add_control(key, field)
	field.item_selected.connect(func(index: int): _apply(key, index))

func _build_type_fields(node_type: int) -> void:
	for child in type_controls:
		if is_instance_valid(child):
			child.queue_free()
	type_controls.clear()
	for key in fields.keys():
		if str(key).begins_with("type_"):
			fields.erase(key)
	building_type_fields = true
	match node_type:
		GrowthTreeNode.NodeType.PASSIVE:
			_line("type_passive_effect", "被动效果", "例如：每秒恢复生命")
			_number("type_passive_value", "效果数值", -100000, 100000, 0.1)
			_choice("type_passive_stack_mode", "叠加方式", ["不叠加", "加法叠加", "乘法叠加", "取最高值"])
		GrowthTreeNode.NodeType.TECHNOLOGY:
			_number("type_research_cost", "研究成本", 0, 100000000, 1)
			_line("type_era_requirement", "时代要求", "例如：蒸汽时代")
			_multi("type_unlock_content", "解锁内容", "填写解锁的建筑、单位、配方或功能")
		GrowthTreeNode.NodeType.ERA:
			_line("type_era_name", "时代名称", "例如：工业时代")
			_multi("type_era_entry_condition", "进入条件", "描述进入该时代必须满足的条件")
			_multi("type_era_reward", "时代奖励", "描述进入时代后获得的奖励")
		GrowthTreeNode.NodeType.TALENT:
			_choice("type_attribute_type", "属性类型", ["攻击力", "生命值", "防御力", "速度", "暴击率", "资源产量", "自定义"])
			_number("type_bonus_value", "加成数值", -100000, 100000, 0.1)
			_choice("type_bonus_mode", "数值方式", ["固定值", "百分比"])
		GrowthTreeNode.NodeType.CONDITION:
			_line("type_condition_expression", "判断条件", "例如：玩家等级 >= 10")
			_number("type_condition_value", "条件数值", -100000000, 100000000, 1)
			_line("type_true_branch_label", "满足后的分支名称", "满足")
			_line("type_false_branch_label", "不满足的分支名称", "不满足")
		GrowthTreeNode.NodeType.REWARD:
			_line("type_reward_type", "奖励类型", "例如：金币、道具、经验")
			_number("type_reward_amount", "奖励数量", 0, 100000000, 1)
			_multi("type_claim_condition", "领取条件", "填写领取奖励需要满足的条件")
		GrowthTreeNode.NodeType.SKILL_ACTIVE, GrowthTreeNode.NodeType.SKILL_ULTIMATE, GrowthTreeNode.NodeType.SKILL_UPGRADE:
			_multi("type_skill_effect", "技能效果", "描述技能具体效果")
			_number("type_skill_cooldown", "冷却时间（秒）", 0, 100000, 0.1)
			_number("type_skill_resource_cost", "资源消耗", 0, 100000000, 0.1)
			_line("type_skill_target", "技能目标", "例如：单体、范围、自己")
		GrowthTreeNode.NodeType.TECH_UNLOCK:
			_line("type_tech_unlock_id", "解锁内容 ID", "填写被解锁内容的唯一 ID")
			_multi("type_unlock_content", "解锁说明", "描述解锁的建筑、单位、配方或功能")
		GrowthTreeNode.NodeType.EVENT:
			_line("type_event_key", "事件标识", "例如：on_city_founded")
			_multi("type_event_effect", "事件效果", "描述事件触发后执行的效果")
		GrowthTreeNode.NodeType.BRANCH:
			_choice("type_branch_mode", "分支模式", ["单选分支", "多选分支", "条件分支"])
		GrowthTreeNode.NodeType.TALENT_ATTACK, GrowthTreeNode.NodeType.TALENT_DEFENSE, GrowthTreeNode.NodeType.TALENT_HEALTH, GrowthTreeNode.NodeType.TALENT_SPEED, GrowthTreeNode.NodeType.TALENT_CRIT:
			_number("type_bonus_value", "属性加成", -100000, 100000, 0.1)
			_choice("type_bonus_mode", "数值方式", ["固定值", "百分比"])
		GrowthTreeNode.NodeType.GENERIC:
			_multi("type_effect_text", "节点效果", "描述这个普通节点的作用")
	building_type_fields = false

func edit_node(item: GrowthTreeNode) -> void:
	current = null
	if item == null:
		_set_enabled(false)
		_refresh_blueprints()
		return
	_build_type_fields(item.node_type)
	_set_enabled(true)
	_set_value("title", item.title)
	_set_value("description", item.description)
	_set_value("icon", item.icon)
	_set_value("show_title", item.show_title)
	_set_value("max_level", item.max_level)
	_set_value("type_passive_effect", item.passive_effect)
	_set_value("type_passive_value", item.passive_value)
	_set_value("type_passive_stack_mode", item.passive_stack_mode)
	_set_value("type_research_cost", item.research_cost)
	_set_value("type_era_requirement", item.era_requirement)
	_set_value("type_unlock_content", item.unlock_content)
	_set_value("type_era_name", item.era_name)
	_set_value("type_era_entry_condition", item.era_entry_condition)
	_set_value("type_era_reward", item.era_reward)
	_set_value("type_attribute_type", ["attack", "health", "defense", "speed", "crit", "production", "custom"].find(item.attribute_type))
	_set_value("type_bonus_value", item.bonus_value)
	_set_value("type_bonus_mode", item.bonus_mode)
	_set_value("type_condition_expression", item.condition_expression)
	_set_value("type_condition_value", item.condition_value)
	_set_value("type_true_branch_label", item.true_branch_label)
	_set_value("type_false_branch_label", item.false_branch_label)
	_set_value("type_reward_type", item.reward_type)
	_set_value("type_reward_amount", item.reward_amount)
	_set_value("type_claim_condition", item.claim_condition)
	_set_value("type_skill_effect", item.skill_effect)
	_set_value("type_skill_cooldown", item.skill_cooldown)
	_set_value("type_skill_resource_cost", item.skill_resource_cost)
	_set_value("type_skill_target", item.skill_target)
	_set_value("type_event_key", item.event_key)
	_set_value("type_event_effect", item.event_effect)
	_set_value("type_branch_mode", item.branch_mode)
	_set_value("type_tech_unlock_id", item.tech_unlock_id)
	_set_value("type_effect_text", item.effect_text)
	current = item
	_refresh_blueprints()

func _set_enabled(enabled: bool) -> void:
	for control in fields.values():
		if control is LineEdit or control is TextEdit:
			control.editable = enabled
		elif control is SpinBox:
			control.editable = enabled
		elif control is BaseButton or control is OptionButton:
			control.disabled = not enabled
		elif control is EditorResourcePicker:
			control.editable = enabled

func _set_value(key: String, value: Variant) -> void:
	if not fields.has(key):
		return
	var control: Control = fields[key]
	if control is LineEdit:
		control.text = str(value)
	elif control is TextEdit:
		control.text = str(value)
	elif control is SpinBox:
		control.value = float(value)
	elif control is CheckBox:
		control.button_pressed = bool(value)
	elif control is OptionButton:
		if value != null and int(value) >= 0 and int(value) < control.item_count:
			control.select(int(value))
	elif control is EditorResourcePicker:
		control.edited_resource = value

func _apply(property: String, value: Variant) -> void:
	if current == null:
		return
	var key := property.trim_prefix("type_")
	if key == "attribute_type":
		var names := ["attack", "health", "defense", "speed", "crit", "production", "custom"]
		value = names[clampi(int(value), 0, names.size() - 1)]
	current.set(key, value)
	changed.emit()
