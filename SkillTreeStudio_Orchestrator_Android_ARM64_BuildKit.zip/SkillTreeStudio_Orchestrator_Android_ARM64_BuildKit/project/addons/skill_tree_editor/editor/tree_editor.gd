@tool
extends VBoxContainer

const CanvasScript = preload("res://addons/skill_tree_editor/editor/tree_canvas.gd")
const ListScript = preload("res://addons/skill_tree_editor/editor/node_list.gd")
const InspectorScript = preload("res://addons/skill_tree_editor/editor/node_inspector.gd")
const NodeScript = preload("res://addons/skill_tree_editor/data/growth_tree_node.gd")
const BlueprintScript = preload("res://addons/skill_tree_editor/data/node_blueprint.gd")
const BlueprintStudioScript = preload("res://addons/skill_tree_editor/blueprint/blueprint_studio.gd")

const TYPE_NAMES := ["被动技能", "科技研究", "时代", "天赋", "条件", "奖励", "普通", "分支", "事件", "主动技能", "终极技能", "技能强化", "科技解锁", "攻击天赋", "防御天赋", "生命天赋", "速度天赋", "暴击天赋"]
const TYPE_ICONS := []

var tree_data: GrowthTree
var canvas: Control
var node_list: VBoxContainer
var inspector: VBoxContainer
var status: Label
var path: String
var branch_select: OptionButton
var connect_button: Button
var blueprint_studio
var node_picker: Window
var node_picker_list: ItemList
var node_picker_search: LineEdit
var node_picker_detail: Label
var _picker_type_indices: Array[int] = []
var _picker_selected_type := -1

func _ready() -> void:
	size_flags_horizontal = Control.SIZE_EXPAND_FILL
	size_flags_vertical = Control.SIZE_EXPAND_FILL
	add_theme_constant_override("separation", 8)
	_build_toolbar()
	var outer := HSplitContainer.new()
	outer.size_flags_vertical = Control.SIZE_EXPAND_FILL
	outer.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	outer.split_offset = 220
	add_child(outer)
	var left_panel := _panel("节点管理")
	left_panel.custom_minimum_size.x = 190
	outer.add_child(left_panel)
	var left_content := _panel_content(left_panel)
	var add_node_button := Button.new()
	add_node_button.text = "＋ 创建节点"
	add_node_button.custom_minimum_size.y = 40
	add_node_button.pressed.connect(_open_node_picker)
	left_content.add_child(add_node_button)
	var list_caption := Label.new()
	list_caption.text = "已创建节点"
	list_caption.add_theme_color_override("font_color", Color("#9eacc0"))
	left_content.add_child(list_caption)
	node_list = ListScript.new()
	node_list.size_flags_vertical = Control.SIZE_EXPAND_FILL
	left_content.add_child(node_list)
	var inner := HSplitContainer.new()
	inner.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	inner.size_flags_vertical = Control.SIZE_EXPAND_FILL
	inner.split_offset = -300
	outer.add_child(inner)
	var canvas_panel := _panel("节点画布")
	canvas_panel.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	canvas_panel.size_flags_vertical = Control.SIZE_EXPAND_FILL
	inner.add_child(canvas_panel)
	canvas = CanvasScript.new()
	canvas.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	canvas.size_flags_vertical = Control.SIZE_EXPAND_FILL
	canvas.custom_minimum_size = Vector2(360, 300)
	_panel_content(canvas_panel).add_child(canvas)
	var inspector_panel := _panel("属性检查器")
	inspector_panel.custom_minimum_size.x = 260
	inner.add_child(inspector_panel)
	var scroll := ScrollContainer.new()
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	scroll.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	_panel_content(inspector_panel).add_child(scroll)
	inspector = InspectorScript.new()
	inspector.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	inspector.custom_minimum_size.x = 230
	scroll.add_child(inspector)
	node_list.node_selected.connect(_select_node)
	canvas.node_selected.connect(_select_node)
	canvas.tree_changed.connect(_changed)
	inspector.changed.connect(_changed)
	inspector.edit_script_requested.connect(_open_selected_node_script)
	status = Label.new()
	status.text = "点击左侧“＋ 创建节点”选择类型；节点可在画布移动，滚轮缩放，右键拖动平移。"
	status.add_theme_color_override("font_color", Color("#9eacc0"))
	add_child(status)
	blueprint_studio = BlueprintStudioScript.new()
	blueprint_studio.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	blueprint_studio.close_requested.connect(_close_blueprint_studio)
	var host := get_parent()
	if host != null:
		host.add_child(blueprint_studio)
		blueprint_studio.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	blueprint_studio.hide()

func _exit_tree() -> void:
	if is_instance_valid(blueprint_studio):
		blueprint_studio.queue_free()
	if is_instance_valid(node_picker):
		node_picker.queue_free()

func _panel(title_text: String) -> PanelContainer:
	var panel := PanelContainer.new()
	var style := StyleBoxFlat.new()
	style.bg_color = Color("#1b2330")
	style.border_color = Color("#2c394b")
	style.set_border_width_all(1)
	style.set_corner_radius_all(8)
	style.content_margin_left = 10
	style.content_margin_right = 10
	style.content_margin_top = 9
	style.content_margin_bottom = 9
	panel.add_theme_stylebox_override("panel", style)
	var box := VBoxContainer.new()
	box.add_theme_constant_override("separation", 8)
	panel.add_child(box)
	var heading := Label.new()
	heading.text = title_text
	heading.add_theme_font_size_override("font_size", 16)
	box.add_child(heading)
	return panel

func _panel_content(panel: PanelContainer) -> VBoxContainer:
	return panel.get_child(0) as VBoxContainer

func _open_node_picker() -> void:
	if tree_data == null:
		status.text = "请先创建或打开一棵成长树。"
		return
	if not is_instance_valid(node_picker):
		_build_node_picker()
	_filter_node_picker(node_picker_search.text)
	node_picker.popup_centered(Vector2i(620, 560))

func _build_node_picker() -> void:
	node_picker = Window.new()
	node_picker.title = "创建成长树节点 · 选择类型"
	node_picker.size = Vector2i(620, 560)
	node_picker.min_size = Vector2i(420, 380)
	node_picker.transient = true
	node_picker.exclusive = true
	var root_box := VBoxContainer.new()
	root_box.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	root_box.add_theme_constant_override("separation", 9)
	node_picker.add_child(root_box)
	var intro := Label.new()
	intro.text = "选择要创建的成长树节点类型。创建后会自动加入当前成长树并选中。"
	intro.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	root_box.add_child(intro)
	node_picker_search = LineEdit.new()
	node_picker_search.placeholder_text = "搜索节点类型…"
	node_picker_search.text_changed.connect(_filter_node_picker)
	root_box.add_child(node_picker_search)
	node_picker_list = ItemList.new()
	node_picker_list.size_flags_vertical = Control.SIZE_EXPAND_FILL
	node_picker_list.select_mode = ItemList.SELECT_SINGLE
	node_picker_list.item_selected.connect(_on_node_picker_selected)
	node_picker_list.item_activated.connect(_on_node_picker_activated)
	root_box.add_child(node_picker_list)
	node_picker_detail = Label.new()
	node_picker_detail.text = "选择一种类型以继续。"
	node_picker_detail.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	root_box.add_child(node_picker_detail)
	var buttons := HBoxContainer.new()
	root_box.add_child(buttons)
	var create_button := Button.new()
	create_button.text = "创建所选节点"
	create_button.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	create_button.pressed.connect(_create_picked_node)
	buttons.add_child(create_button)
	var cancel_button := Button.new()
	cancel_button.text = "取消"
	cancel_button.pressed.connect(node_picker.hide)
	buttons.add_child(cancel_button)
	add_child(node_picker)

func _filter_node_picker(query: String) -> void:
	if not is_instance_valid(node_picker_list):
		return
	node_picker_list.clear()
	_picker_type_indices.clear()
	_picker_selected_type = -1
	var needle := query.strip_edges().to_lower()
	for i in range(TYPE_NAMES.size()):
		var type_name: String = str(TYPE_NAMES[i])
		if needle.is_empty() or type_name.to_lower().contains(needle):
			node_picker_list.add_item(type_name + "节点")
			_picker_type_indices.append(i)
	if node_picker_list.item_count > 0:
		node_picker_list.select(0)
		_on_node_picker_selected(0)
	else:
		node_picker_detail.text = "没有匹配的节点类型。"

func _on_node_picker_selected(index: int) -> void:
	if index < 0 or index >= _picker_type_indices.size():
		return
	_picker_selected_type = _picker_type_indices[index]
	node_picker_detail.text = "将创建：%s节点。创建后可在右侧属性面板设置专属参数。" % TYPE_NAMES[_picker_selected_type]

func _on_node_picker_activated(index: int) -> void:
	_on_node_picker_selected(index)
	_create_picked_node()

func _create_picked_node() -> void:
	if _picker_selected_type < 0:
		status.text = "请先选择一种节点类型。"
		return
	var selected_type := _picker_selected_type
	node_picker.hide()
	_add_node(selected_type)

func _build_toolbar() -> void:
	var bar := PanelContainer.new()
	var style := StyleBoxFlat.new()
	style.bg_color = Color("#202a38")
	style.set_corner_radius_all(8)
	style.content_margin_left = 8
	style.content_margin_right = 8
	style.content_margin_top = 6
	style.content_margin_bottom = 6
	bar.add_theme_stylebox_override("panel", style)
	add_child(bar)
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 6)
	bar.add_child(row)
	_button(row, "← 返回", _back_to_home)
	_button(row, "连接前置", _connect)
	branch_select = OptionButton.new()
	branch_select.add_item("普通连接")
	branch_select.add_item("满足分支")
	branch_select.add_item("不满足分支")
	branch_select.select(0)
	branch_select.tooltip_text = "条件节点可用满足/不满足分支；同一节点可连接多个目标"
	row.add_child(branch_select)
	connect_button = Button.new()
	connect_button.text = "开始连接"
	connect_button.pressed.connect(_connect)
	row.add_child(connect_button)
	_button(row, "删除节点", _delete_node)
	_button(row, "保存", _save)

func _button(parent: Node, label: String, callback: Callable) -> void:
	var button := Button.new()
	button.text = label
	button.pressed.connect(callback)
	parent.add_child(button)

func open_tree(resource: GrowthTree, resource_path: String) -> void:
	if resource == null:
		status.text = "无法打开成长树：资源为空。"
		return
	tree_data = resource
	path = resource_path
	for node in tree_data.nodes:
		if node != null:
			node.migrate_legacy(tree_data.tree_type)
	canvas.set_tree(tree_data)
	node_list.set_tree(tree_data)
	inspector.edit_node(null)
	status.text = "已打开：%s  ·  %d 个节点  ·  %d 条连接" % [tree_data.tree_name, tree_data.nodes.size(), tree_data.connections.size()]

func _add_node(node_type: int) -> void:
	if tree_data == null:
		status.text = "请先创建或打开一棵成长树，再创建节点。"
		return
	if node_type < 0 or node_type >= TYPE_NAMES.size():
		status.text = "节点类型无效，无法创建。"
		return
	var item: GrowthTreeNode = NodeScript.new()
	if item == null:
		status.text = "节点脚本无法实例化，请先修复 GDScript 编译错误。"
		return
	item.id = "node_" + str(Time.get_ticks_usec())
	while tree_data.get_node_by_id(item.id) != null:
		item.id = "node_" + str(Time.get_ticks_usec()) + "_" + str(randi())
	item.node_type = node_type
	item.legacy_type_migrated = true
	item.title = TYPE_NAMES[node_type] + "节点"
	item.position = Vector2(120 + (tree_data.nodes.size() % 4) * 150, 90 + int(tree_data.nodes.size() / 4) * 120)
	if not tree_data.add_node(item):
		status.text = "创建节点失败：节点 ID 重复或节点数据无效。"
		return
	node_list.refresh()
	node_list.select_id(item.id)
	_select_node(item.id)
	canvas.queue_redraw()
	_changed()

func _select_node(node_id: String) -> void:
	if tree_data == null:
		return
	var item := tree_data.get_node_by_id(node_id)
	if item == null:
		return
	inspector.edit_node(item)
	canvas.selected_id = item.id
	canvas.focus_node(item.id)
	node_list.select_id(item.id)
	canvas.queue_redraw()

func _connect() -> void:
	if tree_data == null or canvas.selected_id.is_empty():
		status.text = "请先选择一个起点节点，再点击连接前置。"
		return
	canvas.connect_from = canvas.selected_id
	canvas.connect_branch_label = ""
	var source := tree_data.get_node_by_id(canvas.selected_id)
	if source != null and source.node_type == GrowthTreeNode.NodeType.CONDITION:
		if branch_select.selected == 1:
			canvas.connect_branch_label = source.true_branch_label
		elif branch_select.selected == 2:
			canvas.connect_branch_label = source.false_branch_label
	status.text = "连接模式：点击目标节点。可连续创建多条连接；按 Esc 取消。"

func _delete_node() -> void:
	if tree_data == null or canvas.selected_id.is_empty():
		return
	tree_data.remove_node(canvas.selected_id)
	canvas.selected_id = ""
	inspector.edit_node(null)
	node_list.refresh()
	canvas.queue_redraw()
	_changed()

func _changed() -> void:
	if tree_data != null:
		tree_data.emit_changed()
		node_list.refresh()
		status.text = "有未保存修改：%s  ·  %d 个节点 / %d 条连接" % [path, tree_data.nodes.size(), tree_data.connections.size()]

func _save() -> void:
	if tree_data == null or path.is_empty():
		return
	var error := ResourceSaver.save(tree_data, path)
	status.text = "保存成功：%s" % path if error == OK else "保存失败，错误码：%d" % error


func _open_selected_node_script() -> void:
	if tree_data == null or canvas.selected_id.is_empty():
		status.text = "请先选择一个成长树节点。"
		return
	var target := tree_data.get_node_by_id(canvas.selected_id)
	if target == null:
		return
	if target.blueprint_refs.is_empty():
		var fresh_blueprint: NodeBlueprint = BlueprintScript.new()
		fresh_blueprint.blueprint_id = "blueprint_" + str(Time.get_ticks_usec())
		fresh_blueprint.blueprint_name = target.title + "脚本"
		var blueprint_folder := "res://node_blueprints"
		var mkdir_error: Error = DirAccess.make_dir_recursive_absolute(ProjectSettings.globalize_path(blueprint_folder))
		if mkdir_error != OK and mkdir_error != ERR_ALREADY_EXISTS:
			status.text = "无法创建蓝图目录：%d" % mkdir_error
			return
		var blueprint_path := blueprint_folder.path_join(fresh_blueprint.blueprint_id + ".tres")
		var save_error: Error = ResourceSaver.save(fresh_blueprint, blueprint_path)
		if save_error != OK:
			status.text = "无法创建节点蓝图：%d" % save_error
			return
		fresh_blueprint.take_over_path(blueprint_path)
		target.blueprint_refs.append(fresh_blueprint)
		target.emit_changed()
		_changed()
		_save()
		_open_blueprint_editor(fresh_blueprint, blueprint_path, target)
		return
	var resource: Resource = target.blueprint_refs[0]
	if resource == null or not (resource is NodeBlueprint):
		status.text = "该节点绑定的蓝图资源无效。"
		return
	_open_blueprint_editor(resource as NodeBlueprint, resource.resource_path, target)

func _open_blueprint_editor(resource: NodeBlueprint, resource_path: String, owner_node: GrowthTreeNode) -> void:
	if not is_instance_valid(blueprint_studio):
		status.text = "蓝图工作室尚未初始化。"
		return
	blueprint_studio.open_blueprint(resource, resource_path, owner_node)
	hide()
	blueprint_studio.show()

func _close_blueprint_studio() -> void:
	blueprint_studio.hide()
	show()
	if tree_data != null:
		canvas.queue_redraw()

func _back_to_home() -> void:
	var root := get_parent()
	if root != null and root.has_method("show_home"):
		root.show_home()
