@tool
extends Control

const TreeScript = preload("res://addons/skill_tree_editor/data/growth_tree.gd")
const TreeEditorScript = preload("res://addons/skill_tree_editor/editor/tree_editor.gd")

var home: VBoxContainer
var editor: Control
var folder_edit: LineEdit
var tree_name_edit: LineEdit
var type_select: OptionButton
var tree_list: ItemList
var current_path_label: Label
var status: Label
var file_dialog: FileDialog
var folder_dialog: FileDialog
var _tree_paths: Array[String] = []
var current_folder := "res://growth_trees"

func _ready() -> void:
    set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    _build_home()
    _show_home()

func _build_home() -> void:
    home = VBoxContainer.new()
    home.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    home.add_theme_constant_override("separation", 12)
    home.add_theme_constant_override("margin_left", 18)
    home.add_theme_constant_override("margin_right", 18)
    home.add_theme_constant_override("margin_top", 16)
    home.add_theme_constant_override("margin_bottom", 14)
    add_child(home)

    var header := PanelContainer.new()
    var header_style := StyleBoxFlat.new()
    header_style.bg_color = Color("#202b3b")
    header_style.set_corner_radius_all(10)
    header_style.content_margin_left = 16
    header_style.content_margin_right = 16
    header_style.content_margin_top = 12
    header_style.content_margin_bottom = 12
    header.add_theme_stylebox_override("panel", header_style)
    home.add_child(header)
    var header_box := VBoxContainer.new()
    header_box.add_theme_constant_override("separation", 4)
    header.add_child(header_box)
    var title := Label.new()
    title.text = "成长树工作台"
    title.add_theme_font_size_override("font_size", 24)
    header_box.add_child(title)
    var subtitle := Label.new()
    subtitle.text = "创建、浏览和打开项目中的成长树资源"
    subtitle.add_theme_color_override("font_color", Color("#aab8ca"))
    header_box.add_child(subtitle)

    var content := HSplitContainer.new()
    content.size_flags_vertical = Control.SIZE_EXPAND_FILL
    content.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    content.split_offset = 340
    home.add_child(content)

    var create_panel := _make_panel("新建成长树")
    create_panel.custom_minimum_size.x = 300
    content.add_child(create_panel)
    var create_box := create_panel.get_child(0) as VBoxContainer
    create_box.add_child(_field_label("成长树名称"))
    tree_name_edit = LineEdit.new()
    tree_name_edit.placeholder_text = "例如：魔法科技树"
    tree_name_edit.custom_minimum_size.y = 38
    create_box.add_child(tree_name_edit)
    create_box.add_child(_field_label("成长树类型"))
    type_select = OptionButton.new()
    type_select.add_item("科技树")
    type_select.add_item("技能树")
    type_select.add_item("天赋树")
    type_select.add_item("自定义成长树")
    type_select.select(1)
    type_select.custom_minimum_size.y = 36
    create_box.add_child(type_select)
    create_box.add_child(_field_label("保存目录"))
    var folder_row := HBoxContainer.new()
    create_box.add_child(folder_row)
    folder_edit = LineEdit.new()
    folder_edit.text = current_folder
    folder_edit.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    folder_row.add_child(folder_edit)
    var browse_button := Button.new()
    browse_button.text = "浏览…"
    browse_button.pressed.connect(_choose_folder)
    folder_row.add_child(browse_button)
    var create_button := Button.new()
    create_button.text = "＋ 创建并进入编辑器"
    create_button.custom_minimum_size.y = 42
    create_button.pressed.connect(_create_tree)
    create_box.add_child(create_button)
    var mkdir_button := Button.new()
    mkdir_button.text = "创建目录"
    mkdir_button.pressed.connect(_create_folder)
    create_box.add_child(mkdir_button)
    var spacer := Control.new()
    spacer.size_flags_vertical = Control.SIZE_EXPAND_FILL
    create_box.add_child(spacer)
    var note := Label.new()
    note.text = "只在项目 res:// 目录内创建资源，不会修改项目外部文件。"
    note.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    note.add_theme_color_override("font_color", Color("#8292a8"))
    create_box.add_child(note)

    var library_panel := _make_panel("已有成长树")
    content.add_child(library_panel)
    var library_box := library_panel.get_child(0) as VBoxContainer
    var folder_header := HBoxContainer.new()
    library_box.add_child(folder_header)
    var folder_caption := Label.new()
    folder_caption.text = "浏览目录"
    folder_caption.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
    folder_header.add_child(folder_caption)
    var refresh_button := Button.new()
    refresh_button.text = "刷新"
    refresh_button.pressed.connect(_refresh)
    folder_header.add_child(refresh_button)
    var open_file_button := Button.new()
    open_file_button.text = "从文件打开…"
    open_file_button.pressed.connect(_open_file_dialog)
    folder_header.add_child(open_file_button)
    current_path_label = Label.new()
    current_path_label.text = current_folder
    current_path_label.clip_text = true
    current_path_label.add_theme_color_override("font_color", Color("#91a4bb"))
    library_box.add_child(current_path_label)
    tree_list = ItemList.new()
    tree_list.size_flags_vertical = Control.SIZE_EXPAND_FILL
    tree_list.select_mode = ItemList.SELECT_SINGLE
    tree_list.custom_minimum_size.y = 220
    tree_list.item_activated.connect(_open_item)
    library_box.add_child(tree_list)
    var open_button := Button.new()
    open_button.text = "打开选中的成长树"
    open_button.custom_minimum_size.y = 40
    open_button.pressed.connect(_open_selected)
    library_box.add_child(open_button)

    status = Label.new()
    status.text = "双击列表中的资源可直接打开；也可以使用“从文件打开…”。"
    status.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    status.add_theme_color_override("font_color", Color("#aab8ca"))
    home.add_child(status)

    file_dialog = FileDialog.new()
    file_dialog.title = "打开成长树资源"
    file_dialog.file_mode = FileDialog.FILE_MODE_OPEN_FILE
    file_dialog.access = FileDialog.ACCESS_RESOURCES
    file_dialog.filters = PackedStringArray(["*.tres, *.res ; Godot Resource"])
    file_dialog.file_selected.connect(_load_tree_file)
    home.add_child(file_dialog)

    folder_dialog = FileDialog.new()
    folder_dialog.title = "选择成长树目录"
    folder_dialog.file_mode = FileDialog.FILE_MODE_OPEN_DIR
    folder_dialog.access = FileDialog.ACCESS_RESOURCES
    folder_dialog.dir_selected.connect(_on_folder_selected)
    home.add_child(folder_dialog)
    _refresh()

func _make_panel(panel_title: String) -> PanelContainer:
    var panel := PanelContainer.new()
    panel.size_flags_vertical = Control.SIZE_EXPAND_FILL
    var style := StyleBoxFlat.new()
    style.bg_color = Color("#18212d")
    style.border_color = Color("#2b394b")
    style.set_border_width_all(1)
    style.set_corner_radius_all(9)
    style.content_margin_left = 12
    style.content_margin_right = 12
    style.content_margin_top = 12
    style.content_margin_bottom = 12
    panel.add_theme_stylebox_override("panel", style)
    var box := VBoxContainer.new()
    box.add_theme_constant_override("separation", 9)
    panel.add_child(box)
    var heading := Label.new()
    heading.text = panel_title
    heading.add_theme_font_size_override("font_size", 17)
    box.add_child(heading)
    return panel

func _field_label(value: String) -> Label:
    var label := Label.new()
    label.text = value
    label.add_theme_color_override("font_color", Color("#aab8ca"))
    return label

func _show_home() -> void:
    if is_instance_valid(home):
        home.show()
    if is_instance_valid(editor):
        editor.hide()

func show_home() -> void:
    _show_home()
    _refresh()

func _choose_folder() -> void:
    folder_dialog.current_dir = folder_edit.text.strip_edges()
    folder_dialog.popup_centered_ratio(0.72)

func _on_folder_selected(selected: String) -> void:
    folder_edit.text = selected
    _refresh()

func _create_folder() -> void:
    var folder := folder_edit.text.strip_edges()
    if not folder.begins_with("res://"):
        status.text = "目录必须位于项目内，并以 res:// 开头。"
        return
    var error: Error = DirAccess.make_dir_recursive_absolute(ProjectSettings.globalize_path(folder))
    if error == OK or error == ERR_ALREADY_EXISTS:
        current_folder = folder
        status.text = "目录已就绪：" + folder
        _refresh()
    else:
        status.text = "创建目录失败，错误码：%d" % error

func _create_tree() -> void:
    var folder := folder_edit.text.strip_edges()
    var tree_name := tree_name_edit.text.strip_edges()
    if tree_name.is_empty():
        status.text = "请填写成长树名称。"
        return
    if not folder.begins_with("res://"):
        status.text = "保存目录必须以 res:// 开头。"
        return
    var dir_error: Error = DirAccess.make_dir_recursive_absolute(ProjectSettings.globalize_path(folder))
    if dir_error != OK and dir_error != ERR_ALREADY_EXISTS:
        status.text = "目录创建失败：%d" % dir_error
        return
    var safe_name := tree_name.validate_filename()
    if safe_name.is_empty():
        status.text = "名称不能作为有效文件名。"
        return
    var resource_path := folder.path_join(safe_name + ".tres")
    if FileAccess.file_exists(ProjectSettings.globalize_path(resource_path)):
        status.text = "同名文件已存在，请更换名称。"
        return
    var data: GrowthTree = TreeScript.new()
    data.tree_name = tree_name
    data.folder_path = folder
    data.tree_type = type_select.selected
    var save_error: Error = ResourceSaver.save(data, resource_path)
    if save_error != OK:
        status.text = "创建资源失败，错误码：%d" % save_error
        return
    current_folder = folder
    folder_edit.text = folder
    tree_name_edit.clear()
    _refresh()
    _open_tree(data, resource_path)

func _refresh() -> void:
    if not is_instance_valid(tree_list) or not is_instance_valid(folder_edit):
        return
    tree_list.clear()
    _tree_paths.clear()
    var folder := folder_edit.text.strip_edges()
    if folder.is_empty() or not folder.begins_with("res://"):
        status.text = "请输入有效的项目目录（res://…）。"
        return
    current_folder = folder
    if is_instance_valid(current_path_label):
        current_path_label.text = folder
    _scan_tree_files(folder)
    var candidates: Array[String] = _tree_paths.duplicate()
    _tree_paths.clear()
    for resource_path in candidates:
        var loaded: Resource = ResourceLoader.load(resource_path)
        if loaded == null or not (loaded is GrowthTree):
            continue
        var tree := loaded as GrowthTree
        _tree_paths.append(resource_path)
        var display_name := "%s    ·    %s" % [tree.tree_name, resource_path.trim_prefix(folder).trim_prefix("/")]
        tree_list.add_item(display_name)
    if tree_list.item_count == 0:
        status.text = "此目录下未找到可识别的成长树资源。可用“从文件打开…”选择 .tres 文件。"
    else:
        status.text = "找到 %d 个成长树资源。双击即可打开。" % tree_list.item_count

func _scan_tree_files(folder: String) -> void:
    var absolute := ProjectSettings.globalize_path(folder)
    var dir := DirAccess.open(absolute)
    if dir == null:
        return
    dir.list_dir_begin()
    var filename := dir.get_next()
    while not filename.is_empty():
        if filename != "." and filename != ".." and filename != ".godot":
            var child_path := folder.path_join(filename)
            if dir.current_is_dir():
                _scan_tree_files(child_path)
            elif filename.ends_with(".tres") or filename.ends_with(".res"):
                _tree_paths.append(child_path)
        filename = dir.get_next()
    dir.list_dir_end()

func _open_selected() -> void:
    var selected := tree_list.get_selected_items()
    if selected.is_empty():
        status.text = "请先选择一个成长树文件。"
        return
    _load_tree_file(_tree_paths[selected[0]])

func _open_item(index: int) -> void:
    if index >= 0 and index < _tree_paths.size():
        _load_tree_file(_tree_paths[index])

func _open_file_dialog() -> void:
    file_dialog.current_dir = current_folder
    file_dialog.popup_centered_ratio(0.75)

func _load_tree_file(resource_path: String) -> void:
    var loaded: Resource = ResourceLoader.load(resource_path, "", ResourceLoader.CACHE_MODE_REPLACE)
    if loaded == null:
        status.text = "读取失败：%s。请确认文件及其依赖资源完整。" % resource_path
        return
    if not (loaded is GrowthTree):
        status.text = "该文件不是成长树资源（GrowthTree）：%s" % resource_path
        return
    var tree := loaded as GrowthTree
    if tree.tree_name.is_empty():
        tree.tree_name = resource_path.get_file().get_basename()
    _open_tree(tree, resource_path)

func _open_tree(data: GrowthTree, resource_path: String) -> void:
    if data == null:
        status.text = "无法打开：资源为空。"
        return
    if is_instance_valid(editor):
        remove_child(editor)
        editor.queue_free()
    # Instantiate the native base node first, then attach the editor script.
    # This avoids calling new() on a GDScript resource in this editor context.
    var editor_instance := VBoxContainer.new()
    editor_instance.set_script(TreeEditorScript)
    editor = editor_instance
    editor.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    add_child(editor)
    editor.call("open_tree", data, resource_path)
    home.hide()
    editor.show()
