@tool
extends Control
signal node_selected(node_id: String)
signal tree_changed

const INVISIBLE_HIT_SIZE := Vector2(96, 56)
var tree_data: GrowthTree
var selected_id := ""
var drag_id := ""
var drag_offset := Vector2.ZERO
var connect_from := ""
var connect_branch_label := ""
var zoom := 1.0
var pan := Vector2(40, 40)
var show_grid := true

func set_tree(value: GrowthTree) -> void:
	tree_data = value
	selected_id = ""
	queue_redraw()

func _world_to_screen(point: Vector2) -> Vector2:
	return point * zoom + pan

func _screen_to_world(point: Vector2) -> Vector2:
	return (point - pan) / zoom

func _node_rect(item: GrowthTreeNode) -> Rect2:
	if item.icon != null:
		var icon_size := item.blueprint_size if item.blueprint_size_enabled else item.icon.get_size()
		return Rect2(_world_to_screen(item.position), icon_size * zoom)
	if item.blueprint_visual_enabled:
		return Rect2(_world_to_screen(item.position), item.blueprint_size * zoom)
	return Rect2(_world_to_screen(item.position), INVISIBLE_HIT_SIZE * zoom)

func _draw() -> void:
	draw_rect(Rect2(Vector2.ZERO, size), Color("#141922"), true)
	if show_grid:
		var step := 32.0 * zoom
		if step > 7.0:
			var x := fposmod(pan.x, step)
			while x < size.x:
				draw_line(Vector2(x, 0), Vector2(x, size.y), Color("#222b38"), 1.0)
				x += step
			var y := fposmod(pan.y, step)
			while y < size.y:
				draw_line(Vector2(0, y), Vector2(size.x, y), Color("#222b38"), 1.0)
				y += step
	if tree_data == null:
		return
	for edge in tree_data.connections:
		if edge == null:
			continue
		var source := tree_data.get_node_by_id(edge.from_id)
		var target := tree_data.get_node_by_id(edge.to_id)
		if source == null or target == null:
			continue
		var a := _node_rect(source).get_center()
		var b := _node_rect(target).get_center()
		var color := Color("#f0b85a") if source.node_type == GrowthTreeNode.NodeType.CONDITION else Color("#70b7ff")
		draw_line(a, b, color, 2.2, true)
		var direction := (b - a).normalized()
		var side := Vector2(-direction.y, direction.x)
		draw_colored_polygon(PackedVector2Array([b, b - direction * 11.0 + side * 5.0, b - direction * 11.0 - side * 5.0]), color)
		if not edge.branch_label.is_empty():
			draw_string(ThemeDB.fallback_font, (a + b) * 0.5 + Vector2(4, -6), edge.branch_label, HORIZONTAL_ALIGNMENT_LEFT, -1, 12, Color("#f4d18b"))
	for item in tree_data.nodes:
		if item == null or not item.is_visible:
			continue
		var rect := _node_rect(item)
		if item.blueprint_visual_enabled and item.icon == null:
			var center := rect.get_center()
			if item.blueprint_shape == 0:
				draw_circle(center, minf(rect.size.x, rect.size.y) * 0.5, item.blueprint_color)
			elif item.blueprint_shape == 1:
				draw_rect(rect, item.blueprint_color, true)
			elif item.blueprint_shape == 2:
				var hex_half: Vector2 = rect.size * 0.5
				draw_colored_polygon(PackedVector2Array([center + Vector2(-hex_half.x * 0.5, -hex_half.y), center + Vector2(hex_half.x * 0.5, -hex_half.y), center + Vector2(hex_half.x, 0), center + Vector2(hex_half.x * 0.5, hex_half.y), center + Vector2(-hex_half.x * 0.5, hex_half.y), center + Vector2(-hex_half.x, 0)]), item.blueprint_color)
			elif item.blueprint_shape == 3:
				var diamond_half: Vector2 = rect.size * 0.5
				draw_colored_polygon(PackedVector2Array([center + Vector2(0, -diamond_half.y), center + Vector2(diamond_half.x, 0), center + Vector2(0, diamond_half.y), center + Vector2(-diamond_half.x, 0)]), item.blueprint_color)
			else:
				draw_rect(rect, item.blueprint_color, true)
			if item.id == selected_id:
				draw_rect(rect.grow(4.0), Color("#ffd166"), false, 2.0)
		if item.icon != null:
			draw_texture_rect(item.icon, rect, false, item.blueprint_color if item.blueprint_visual_enabled else Color.WHITE)
			if item.show_title:
				draw_string(ThemeDB.fallback_font, Vector2(rect.position.x, rect.end.y + 18.0 * zoom), item.title,
					HORIZONTAL_ALIGNMENT_CENTER, maxf(rect.size.x, 80.0), maxi(10, int(14 * zoom)), Color.WHITE)
			if item.id == selected_id:
				draw_rect(rect.grow(4.0), Color("#ffd166"), false, 2.0)
	# Transparent nodes deliberately draw nothing, including selection outlines.

func _hit_node(point: Vector2) -> GrowthTreeNode:
	if tree_data == null:
		return null
	for i in range(tree_data.nodes.size() - 1, -1, -1):
		var item := tree_data.nodes[i]
		if item != null and item.is_visible and _node_rect(item).has_point(point):
			return item
	return null

func _gui_input(event: InputEvent) -> void:
	if event is InputEventMouseButton:
		if event.button_index == MOUSE_BUTTON_WHEEL_UP and event.pressed:
			zoom = clampf(zoom * 1.1, 0.25, 3.5)
			queue_redraw()
			accept_event()
		elif event.button_index == MOUSE_BUTTON_WHEEL_DOWN and event.pressed:
			zoom = clampf(zoom / 1.1, 0.25, 3.5)
			queue_redraw()
			accept_event()
		elif event.button_index == MOUSE_BUTTON_LEFT and event.pressed:
			_select_or_connect_at(event.position)
		elif event.button_index == MOUSE_BUTTON_LEFT and not event.pressed:
			drag_id = ""
		elif event.button_index == MOUSE_BUTTON_RIGHT and event.pressed:
			pan += event.relative
			queue_redraw()
	elif event is InputEventScreenTouch:
		var touch_position: Vector2 = get_global_transform_with_canvas().affine_inverse() * event.position
		if event.pressed:
			_select_or_connect_at(touch_position)
		else:
			drag_id = ""
	elif event is InputEventScreenDrag:
		var drag_position: Vector2 = get_global_transform_with_canvas().affine_inverse() * event.position
		_move_dragged_node(drag_position)
	elif event is InputEventMouseMotion:
		if not drag_id.is_empty() and tree_data != null:
			_move_dragged_node(event.position)
		elif Input.is_mouse_button_pressed(MOUSE_BUTTON_RIGHT):
			pan += event.relative
			queue_redraw()
	elif event is InputEventKey and event.pressed and event.keycode == KEY_ESCAPE:
		connect_from = ""
		queue_redraw()

func _select_or_connect_at(screen_position: Vector2) -> void:
	if tree_data == null:
		return
	var hit: GrowthTreeNode = _hit_node(screen_position)
	if hit == null:
		return
	if not connect_from.is_empty():
		if tree_data.add_connection(connect_from, hit.id, connect_branch_label):
			tree_changed.emit()
		connect_from = ""
		connect_branch_label = ""
	else:
		selected_id = hit.id
		drag_id = hit.id
		drag_offset = _screen_to_world(screen_position) - hit.position
		node_selected.emit(selected_id)
	queue_redraw()

func _move_dragged_node(screen_position: Vector2) -> void:
	if drag_id.is_empty() or tree_data == null:
		return
	var item: GrowthTreeNode = tree_data.get_node_by_id(drag_id)
	if item != null:
		item.position = _screen_to_world(screen_position) - drag_offset
		tree_changed.emit()
		queue_redraw()

func begin_connection() -> void:
	if not selected_id.is_empty():
		connect_from = selected_id

func focus_node(node_id: String) -> void:
	if tree_data == null:
		return
	var item := tree_data.get_node_by_id(node_id)
	if item != null:
		selected_id = node_id
		pan = size * 0.5 - item.position * zoom
		queue_redraw()
