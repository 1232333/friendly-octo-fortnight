@tool
extends RefCounted
class_name BlueprintActionRegistry

var actions: Dictionary = {}

func _init() -> void:
	register_action("node.set_title", "修改节点名称", "节点操作", ["node", "string"], "bool")
	register_action("node.set_description", "修改节点描述", "节点操作", ["node", "string"], "bool")
	register_action("node.set_level", "设置节点等级", "属性操作", ["node", "number"], "bool")
	register_action("node.add_level", "增加节点等级", "属性操作", ["node", "number"], "bool")
	register_action("node.unlock", "解锁节点", "状态操作", ["node"], "bool")
	register_action("node.lock", "锁定节点", "状态操作", ["node"], "bool")
	register_action("node.set_visible", "设置节点可见性", "外观操作", ["node", "bool"], "bool")
	register_action("node.set_color", "设置节点颜色", "外观操作", ["node", "color"], "bool")
	register_action("node.set_icon", "替换节点图片", "外观操作", ["node", "texture2d"], "bool")
	register_action("node.set_shape", "设置节点形状", "外观操作", ["node", "integer"], "bool")
	register_action("node.set_size", "设置节点尺寸", "外观操作", ["node", "vector2"], "bool")
	register_action("node.set_custom_data", "写入自定义数据", "数据操作", ["node", "string", "variant"], "bool")
	register_action("node.attach_blueprint", "绑定子蓝图", "蓝图操作", ["node", "resource"], "bool")
	register_action("tree.create_node", "创建新节点", "成长树操作", ["string", "vector2"], "node")
	register_action("tree.connect", "连接两个节点", "连接操作", ["node", "node"], "bool")

func register_action(action_id: String, display_name: String, category: String, input_types: Array, output_type: String, handler: Callable = Callable()) -> void:
	if action_id.strip_edges().is_empty():
		return
	actions[action_id] = {
		"id": action_id,
		"name": display_name,
		"category": category,
		"inputs": input_types.duplicate(),
		"output": output_type,
		"handler": handler
	}

func set_handler(action_id: String, handler: Callable) -> bool:
	if not actions.has(action_id) or not handler.is_valid():
		return false
	actions[action_id]["handler"] = handler
	return true

func get_action(action_id: String) -> Dictionary:
	return actions.get(action_id, {})

func get_actions() -> Array[Dictionary]:
	var result: Array[Dictionary] = []
	for value in actions.values():
		result.append(value)
	return result

func get_categories() -> PackedStringArray:
	var result := PackedStringArray()
	for action in actions.values():
		var category: String = action.get("category", "其他")
		if not result.has(category):
			result.append(category)
	return result
