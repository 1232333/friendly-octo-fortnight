@tool
extends RefCounted
class_name NodeBlueprintRuntime

const ExecutorScript = preload("res://addons/skill_tree_editor/blueprint/blueprint_executor.gd")

signal blueprint_started(node_id: String, blueprint_id: String, event_name: String)
signal blueprint_finished(node_id: String, blueprint_id: String, event_name: String, results: Array)
signal runtime_error(message: String)

var execution_limit_per_event: int = 32

func trigger_node_event(target_node: GrowthTreeNode, event_name: String, tree: GrowthTree) -> Array:
	var all_results: Array = []
	if target_node == null:
		runtime_error.emit("触发蓝图事件失败：目标节点为空")
		return all_results
	if tree == null:
		runtime_error.emit("触发蓝图事件失败：成长树为空")
		return all_results
	var executed_count := 0
	for blueprint_resource in target_node.blueprint_refs:
		if blueprint_resource == null or not (blueprint_resource is NodeBlueprint):
			continue
		if executed_count >= execution_limit_per_event:
			runtime_error.emit("单次节点事件绑定蓝图数量超过安全上限")
			break
		var blueprint := blueprint_resource as NodeBlueprint
		var has_event := false
		for event_data in blueprint.events:
			if str(event_data.get("event", "")) == event_name:
				has_event = true
				break
		if not has_event:
			continue
		executed_count += 1
		blueprint_started.emit(target_node.id, blueprint.blueprint_id, event_name)
		var executor := ExecutorScript.new(tree)
		executor.context_node_id = target_node.id
		var results: Array = executor.execute_blueprint_event(blueprint, event_name)
		all_results.append_array(results)
		blueprint_finished.emit(target_node.id, blueprint.blueprint_id, event_name, results)
	return all_results
