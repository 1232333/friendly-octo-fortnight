@tool
extends RefCounted
class_name BlueprintNodeAPI

const NodeScript = preload("res://addons/skill_tree_editor/data/growth_tree_node.gd")

var tree: GrowthTree

func _init(target_tree: GrowthTree = null) -> void:
	tree = target_tree

func set_title(node_id: String, value: String) -> bool:
	var node = _find(node_id)
	if node == null:
		return false
	node.title = value
	node.emit_changed()
	return true

func set_description(node_id: String, value: String) -> bool:
	var node = _find(node_id)
	if node == null:
		return false
	node.description = value
	node.emit_changed()
	return true

func set_level(node_id: String, value: float) -> bool:
	var node = _find(node_id)
	if node == null:
		return false
	node.current_level = clampi(int(value), 0, node.max_level)
	node.emit_changed()
	return true

func add_level(node_id: String, amount: float) -> bool:
	var node = _find(node_id)
	if node == null:
		return false
	node.current_level = clampi(node.current_level + int(amount), 0, node.max_level)
	node.emit_changed()
	return true

func set_visible(node_id: String, value: bool) -> bool:
	var node = _find(node_id)
	if node == null:
		return false
	node.is_visible = value
	node.emit_changed()
	return true

func set_icon(node_id: String, value: Texture2D) -> bool:
	var node = _find(node_id)
	if node == null:
		return false
	node.icon = value
	node.emit_changed()
	return true

func set_color(node_id: String, value: Color) -> bool:
	var node = _find(node_id)
	if node == null:
		return false
	node.blueprint_color = value
	node.blueprint_visual_enabled = true
	node.emit_changed()
	return true

func set_shape(node_id: String, shape: int) -> bool:
	var node = _find(node_id)
	if node == null:
		return false
	node.blueprint_shape = clampi(shape, 0, 3)
	node.blueprint_visual_enabled = true
	node.emit_changed()
	return true

func set_size(node_id: String, value: Vector2) -> bool:
	var node = _find(node_id)
	if node == null or value.x <= 0.0 or value.y <= 0.0:
		return false
	node.blueprint_size = value.clamp(Vector2(8, 8), Vector2(1024, 1024))
	node.blueprint_size_enabled = true
	node.blueprint_visual_enabled = true
	node.emit_changed()
	return true

func set_custom_data(node_id: String, key: String, value: Variant) -> bool:
	var node = _find(node_id)
	if node == null or key.strip_edges().is_empty():
		return false
	node.custom_data[key] = value
	node.emit_changed()
	return true

func unlock(node_id: String) -> bool:
	var node = _find(node_id)
	if node == null:
		return false
	node.is_unlocked = true
	node.emit_changed()
	return true

func lock(node_id: String) -> bool:
	var node = _find(node_id)
	if node == null:
		return false
	node.is_unlocked = false
	node.emit_changed()
	return true

func create_node(title: String, position: Vector2) -> GrowthTreeNode:
	if tree == null:
		return null
	var item: GrowthTreeNode = NodeScript.new()
	item.id = "blueprint_node_" + str(Time.get_ticks_usec())
	item.title = title
	item.position = position
	item.legacy_type_migrated = true
	if tree.add_node(item):
		tree.emit_changed()
		return item
	return null

func connect_nodes(from_id: String, to_id: String) -> bool:
	if tree == null:
		return false
	var success: bool = tree.add_connection(from_id, to_id)
	if success:
		tree.emit_changed()
	return success

func attach_blueprint(node_id: String, blueprint: Resource) -> bool:
	var node = _find(node_id)
	if node == null or blueprint == null:
		return false
	for existing in node.blueprint_refs:
		if existing == blueprint:
			return false
	node.blueprint_refs.append(blueprint)
	node.emit_changed()
	return true

func detach_blueprint(node_id: String, blueprint: Resource) -> bool:
	var node = _find(node_id)
	if node == null or blueprint == null:
		return false
	var index: int = node.blueprint_refs.find(blueprint)
	if index < 0:
		return false
	node.blueprint_refs.remove_at(index)
	node.emit_changed()
	return true

func get_node(node_id: String) -> GrowthTreeNode:
	return _find(node_id)

func get_children(node_id: String) -> PackedStringArray:
	if tree == null:
		return PackedStringArray()
	return tree.get_children(node_id)

func get_parents(node_id: String) -> PackedStringArray:
	if tree == null:
		return PackedStringArray()
	return tree.get_prerequisites(node_id)

func _find(node_id: String) -> GrowthTreeNode:
	if tree == null:
		return null
	return tree.get_node_by_id(node_id)
