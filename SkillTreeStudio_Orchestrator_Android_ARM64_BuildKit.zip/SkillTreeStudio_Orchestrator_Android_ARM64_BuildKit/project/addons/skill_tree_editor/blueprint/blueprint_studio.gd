@tool
extends Control

signal close_requested
signal blueprint_saved(blueprint: Resource, target_node: Resource)
signal blueprint_canvas_long_pressed(screen_position: Vector2)

const BlueprintScript = preload("res://addons/skill_tree_editor/data/node_blueprint.gd")
const RegistryScript = preload("res://addons/skill_tree_editor/blueprint/registries/blueprint_action_registry.gd")

const EVENT_NAMES := ["NodeCreated", "NodeClicked", "NodeUnlocked", "NodeLevelChanged", "NodeVisibilityChanged"]

var blueprint: NodeBlueprint
var resource_path := "res://node_blueprints/new_blueprint.tres"
var graph: GraphEdit
var action_list: ItemList
var status: Label
var name_edit: LineEdit
var description_edit: TextEdit
var event_select: OptionButton
var search_edit: LineEdit
var parameter_panel: VBoxContainer
var selected_node_id := ""
var _node_counter := 0
var _registry: BlueprintActionRegistry
var file_dialog: FileDialog
var _parameter_controls: Dictionary = {}
var _loading_graph := false
var target_node: GrowthTreeNode
var canvas_node_picker: Window
var canvas_picker_list: ItemList
var canvas_picker_search: LineEdit
var _canvas_insert_position := Vector2.ZERO
var _canvas_picker_actions: Array[Dictionary] = []
var _canvas_hold_active := false
var _canvas_hold_elapsed := 0.0
var _canvas_hold_position := Vector2.ZERO
var _canvas_hold_fired := false
const CANVAS_LONG_PRESS_SECONDS := 0.65
const CANVAS_LONG_PRESS_MOVE_THRESHOLD := 18.0

func _ready() -> void:
	_registry = RegistryScript.new()
	_build_ui()
	_clear_parameter_panel("选择蓝图节点以编辑参数")

func _process(delta: float) -> void:
	if not _canvas_hold_active or _canvas_hold_fired:
		return
	_canvas_hold_elapsed += delta
	if _canvas_hold_elapsed >= CANVAS_LONG_PRESS_SECONDS:
		_canvas_hold_fired = true
		blueprint_canvas_long_pressed.emit(_canvas_hold_position)

func _on_graph_gui_input(event: InputEvent) -> void:
	if event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT:
		if event.pressed:
			_canvas_hold_position = event.position
			_canvas_hold_active = not _graph_node_at(event.position)
			_canvas_hold_elapsed = 0.0
			_canvas_hold_fired = false
		else:
			_canvas_hold_active = false
	elif event is InputEventScreenTouch:
		var local_position: Vector2 = graph.get_global_transform_with_canvas().affine_inverse() * event.position
		if event.pressed:
			_canvas_hold_position = local_position
			_canvas_hold_active = not _graph_node_at(local_position)
			_canvas_hold_elapsed = 0.0
			_canvas_hold_fired = false
		else:
			_canvas_hold_active = false
	elif event is InputEventMouseMotion and _canvas_hold_active:
		if event.position.distance_to(_canvas_hold_position) > CANVAS_LONG_PRESS_MOVE_THRESHOLD:
			_canvas_hold_active = false
	elif event is InputEventScreenDrag and _canvas_hold_active:
		var drag_position: Vector2 = graph.get_global_transform_with_canvas().affine_inverse() * event.position
		if drag_position.distance_to(_canvas_hold_position) > CANVAS_LONG_PRESS_MOVE_THRESHOLD:
			_canvas_hold_active = false

func _graph_node_at(local_position: Vector2) -> bool:
	if not is_instance_valid(graph):
		return false
	for child in graph.get_children():
		if child is GraphNode:
			var graph_node := child as GraphNode
			if Rect2(graph_node.position_offset - graph.scroll_offset, graph_node.size).has_point(local_position):
				return true
	return false


func open_blueprint(resource: NodeBlueprint, path: String, owner_node: GrowthTreeNode) -> void:
	blueprint = resource
	resource_path = path
	target_node = owner_node
	if not is_instance_valid(name_edit) or not is_instance_valid(graph):
		return
	_clear_graph()
	if blueprint == null:
		name_edit.text = ""
		description_edit.text = ""
		_node_counter = 0
		_clear_parameter_panel("长按蓝图画布空白处，选择要添加的逻辑节点")
		status.text = "当前节点：%s · 尚未绑定蓝图，长按画布空白处添加逻辑节点" % (owner_node.title if owner_node != null else "无节点")
		return
	name_edit.text = blueprint.blueprint_name
	description_edit.text = blueprint.description
	_node_counter = blueprint.graph_nodes.size()
	for item in blueprint.graph_nodes:
		var action: Dictionary = _registry.get_action(str(item.get("action_id", "")))
		if action.is_empty():
			action = {"id": item.get("action_id", "unknown"), "name": "未知操作", "category": "缺失", "inputs": [], "output": "void"}
		var node_id: String = str(item.get("id", ""))
		var node_position: Vector2 = item.get("position", Vector2.ZERO)
		var saved_parameters: Dictionary = item.get("parameters", {})
		_create_graph_node(action, node_id, node_position, false, saved_parameters)
	for edge in blueprint.graph_connections:
		var from_id: String = str(edge.get("from", ""))
		var to_id: String = str(edge.get("to", ""))
		if graph.get_node_or_null(NodePath(from_id)) != null and graph.get_node_or_null(NodePath(to_id)) != null:
			graph.connect_node(from_id, int(edge.get("from_port", 0)), to_id, int(edge.get("to_port", 0)))
	status.text = "正在编辑节点：%s · 蓝图：%s" % [owner_node.title if owner_node != null else "未知节点", blueprint.blueprint_name]

func _build_ui() -> void:
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var root := VBoxContainer.new()
	root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	root.add_theme_constant_override("separation", 8)
	add_child(root)
	var toolbar := HBoxContainer.new()
	root.add_child(toolbar)
	_add_button(toolbar, "← 返回技能树", _back)
	_add_button(toolbar, "打开", _open_dialog)
	_add_button(toolbar, "保存", _save)
	_add_button(toolbar, "编译并绑定事件", _compile_selected_event)
	_add_button(toolbar, "检查", _validate)
	name_edit = LineEdit.new()
	name_edit.placeholder_text = "蓝图名称"
	name_edit.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	toolbar.add_child(name_edit)
	var event_row := HBoxContainer.new()
	root.add_child(event_row)
	var event_label := Label.new()
	event_label.text = "触发事件："
	event_row.add_child(event_label)
	event_select = OptionButton.new()
	for event_name in EVENT_NAMES:
		event_select.add_item(event_name)
	event_row.add_child(event_select)
	var split := HSplitContainer.new()
	split.size_flags_vertical = Control.SIZE_EXPAND_FILL
	split.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	split.split_offset = 220
	root.add_child(split)
	var left := _panel("节点库 / Actions")
	left.custom_minimum_size.x = 190
	split.add_child(left)
	var left_content := left.get_child(0) as VBoxContainer
	search_edit = LineEdit.new()
	search_edit.placeholder_text = "搜索节点 / 操作…"
	search_edit.text_changed.connect(_filter_actions)
	left_content.add_child(search_edit)
	action_list = ItemList.new()
	action_list.size_flags_vertical = Control.SIZE_EXPAND_FILL
	left_content.add_child(action_list)
	_refresh_action_list()
	_add_button(left_content, "＋ 添加选中节点", _add_selected_action)
	graph = GraphEdit.new()
	graph.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	graph.size_flags_vertical = Control.SIZE_EXPAND_FILL
	graph.minimap_enabled = true
	graph.show_grid = true
	graph.right_disconnects = true
	graph.add_valid_connection_type(0, 0)
	graph.connection_request.connect(_on_connection_request)
	graph.disconnection_request.connect(_on_disconnection_request)
	graph.node_selected.connect(_on_graph_node_selected)
	graph.delete_nodes_request.connect(_on_delete_graph_nodes)
	graph.gui_input.connect(_on_graph_gui_input)
	blueprint_canvas_long_pressed.connect(_open_canvas_node_picker)
	split.add_child(graph)
	var right := _panel("节点详情 / Details")
	right.custom_minimum_size.x = 270
	split.add_child(right)
	var right_content := right.get_child(0) as VBoxContainer
	var help := Label.new()
	help.text = "传统蓝图工作流：从左侧添加操作节点，通过右侧输出引脚连接到下一个节点。连线决定执行顺序。选中节点后，在此编辑每个输入参数。"
	help.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	right_content.add_child(help)
	var separator := HSeparator.new()
	right_content.add_child(separator)
	var parameter_scroll := ScrollContainer.new()
	parameter_scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	parameter_scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	right_content.add_child(parameter_scroll)
	parameter_panel = VBoxContainer.new()
	parameter_panel.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	parameter_scroll.add_child(parameter_panel)
	description_edit = TextEdit.new()
	description_edit.custom_minimum_size.y = 85
	description_edit.placeholder_text = "蓝图用途说明"
	right_content.add_child(description_edit)
	file_dialog = FileDialog.new()
	file_dialog.file_mode = FileDialog.FILE_MODE_OPEN_FILE
	file_dialog.access = FileDialog.ACCESS_RESOURCES
	file_dialog.filters = PackedStringArray(["*.tres ; Node Blueprint Resource"])
	file_dialog.file_selected.connect(_load_blueprint)
	root.add_child(file_dialog)
	status = Label.new()
	status.text = "传统节点蓝图工作室已就绪"
	root.add_child(status)

func _open_canvas_node_picker(local_position: Vector2) -> void:
	if blueprint == null or target_node == null:
		status.text = "请先从成长树节点进入蓝图编辑器，才能添加蓝图逻辑节点。"
		return
	_canvas_insert_position = local_position - graph.scroll_offset
	if not is_instance_valid(canvas_node_picker):
		_build_canvas_node_picker()
	_filter_canvas_node_picker(canvas_picker_search.text)
	canvas_node_picker.popup_centered(Vector2i(520, 500))

func _build_canvas_node_picker() -> void:
	canvas_node_picker = Window.new()
	canvas_node_picker.title = "添加蓝图逻辑节点"
	canvas_node_picker.size = Vector2i(520, 500)
	canvas_node_picker.min_size = Vector2i(360, 320)
	canvas_node_picker.transient = true
	canvas_node_picker.exclusive = true
	var box := VBoxContainer.new()
	box.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	box.add_theme_constant_override("separation", 8)
	canvas_node_picker.add_child(box)
	var hint := Label.new()
	hint.text = "选择要放入蓝图画布的逻辑/操作节点。"
	box.add_child(hint)
	canvas_picker_search = LineEdit.new()
	canvas_picker_search.placeholder_text = "搜索节点名称、分类或操作 ID…"
	canvas_picker_search.text_changed.connect(_filter_canvas_node_picker)
	box.add_child(canvas_picker_search)
	canvas_picker_list = ItemList.new()
	canvas_picker_list.size_flags_vertical = Control.SIZE_EXPAND_FILL
	canvas_picker_list.select_mode = ItemList.SELECT_SINGLE
	canvas_picker_list.item_activated.connect(_on_canvas_picker_activated)
	box.add_child(canvas_picker_list)
	var row := HBoxContainer.new()
	box.add_child(row)
	var add_button := Button.new()
	add_button.text = "添加到画布"
	add_button.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	add_button.pressed.connect(_add_canvas_picker_selection)
	row.add_child(add_button)
	var cancel_button := Button.new()
	cancel_button.text = "取消"
	cancel_button.pressed.connect(canvas_node_picker.hide)
	row.add_child(cancel_button)
	add_child(canvas_node_picker)

func _filter_canvas_node_picker(query: String) -> void:
	if not is_instance_valid(canvas_picker_list):
		return
	canvas_picker_list.clear()
	_canvas_picker_actions.clear()
	var needle := query.strip_edges().to_lower()
	for action in _registry.get_actions():
		var searchable := "%s %s %s" % [action.get("name", ""), action.get("category", ""), action.get("id", "")]
		if needle.is_empty() or searchable.to_lower().contains(needle):
			canvas_picker_list.add_item("%s    ·    %s" % [action.get("name", "操作"), action.get("category", "通用")])
			_canvas_picker_actions.append(action)
	if canvas_picker_list.item_count > 0:
		canvas_picker_list.select(0)

func _on_canvas_picker_activated(index: int) -> void:
	if index >= 0 and index < _canvas_picker_actions.size():
		_add_canvas_action(_canvas_picker_actions[index])

func _add_canvas_picker_selection() -> void:
	var selected := canvas_picker_list.get_selected_items()
	if selected.is_empty() or selected[0] >= _canvas_picker_actions.size():
		status.text = "请先选择一个蓝图逻辑节点。"
		return
	_add_canvas_action(_canvas_picker_actions[selected[0]])

func _add_canvas_action(action: Dictionary) -> void:
	if blueprint == null or target_node == null:
		status.text = "当前没有可绑定的成长树节点。"
		return
	_node_counter += 1
	var node_id := "bp_node_%d" % _node_counter
	while graph.get_node_or_null(NodePath(node_id)) != null:
		_node_counter += 1
		node_id = "bp_node_%d" % _node_counter
	_create_graph_node(action, node_id, _canvas_insert_position, true, {})
	canvas_node_picker.hide()
	status.text = "已添加蓝图节点：%s" % action.get("name", "操作")

func _panel(title_text: String) -> PanelContainer:
	var panel := PanelContainer.new()
	var box := VBoxContainer.new()
	box.add_theme_constant_override("separation", 8)
	panel.add_child(box)
	var heading := Label.new()
	heading.text = title_text
	heading.add_theme_font_size_override("font_size", 16)
	box.add_child(heading)
	return panel

func _add_button(parent: Node, caption: String, callback: Callable) -> void:
	var button := Button.new()
	button.text = caption
	button.pressed.connect(callback)
	parent.add_child(button)

func _refresh_action_list(filter_text: String = "") -> void:
	if action_list == null:
		return
	action_list.clear()
	var needle := filter_text.strip_edges().to_lower()
	for action in _registry.get_actions():
		var display := "%s  ·  %s" % [action.get("name", ""), action.get("category", "")]
		if needle.is_empty() or display.to_lower().contains(needle) or str(action.get("id", "")).to_lower().contains(needle):
			action_list.add_item(display)

func _filter_actions(value: String) -> void:
	_refresh_action_list(value)

func _new_blueprint() -> void:
	blueprint = BlueprintScript.new()
	blueprint.blueprint_id = "blueprint_" + str(Time.get_ticks_usec())
	blueprint.blueprint_name = "新建节点蓝图"
	blueprint.graph_nodes.clear()
	blueprint.graph_connections.clear()
	blueprint.events.clear()
	resource_path = "res://node_blueprints/%s.tres" % blueprint.blueprint_id
	_node_counter = 0
	selected_node_id = ""
	name_edit.text = blueprint.blueprint_name
	description_edit.text = ""
	_clear_graph()
	_clear_parameter_panel("从左侧添加一个操作节点开始")
	status.text = "已创建空白蓝图"

func _clear_graph() -> void:
	if not is_instance_valid(graph):
		return
	_loading_graph = true
	for child in graph.get_children():
		if child is GraphNode:
			graph.remove_child(child)
			child.queue_free()
	graph.clear_connections()
	_loading_graph = false

func _open_dialog() -> void:
	DirAccess.make_dir_recursive_absolute(ProjectSettings.globalize_path("res://node_blueprints"))
	file_dialog.current_dir = "res://node_blueprints"
	file_dialog.popup_centered_ratio(0.7)

func _load_blueprint(path: String) -> void:
	var loaded: Resource = ResourceLoader.load(path)
	if loaded == null or not (loaded is NodeBlueprint):
		status.text = "所选资源不是有效的节点蓝图"
		return
	blueprint = loaded as NodeBlueprint
	resource_path = path
	name_edit.text = blueprint.blueprint_name
	description_edit.text = blueprint.description
	_clear_graph()
	_node_counter = blueprint.graph_nodes.size()
	for item in blueprint.graph_nodes:
		var action: Dictionary = _registry.get_action(str(item.get("action_id", "")))
		if action.is_empty():
			action = {"id": item.get("action_id", "unknown"), "name": "未知操作", "category": "缺失", "inputs": [], "output": "void"}
		var node_id := str(item.get("id", ""))
		var node_position: Vector2 = item.get("position", Vector2.ZERO)
		_create_graph_node(action, node_id, node_position, false, item.get("parameters", {}))
	for edge in blueprint.graph_connections:
		var from_id := str(edge.get("from", ""))
		var to_id := str(edge.get("to", ""))
		if graph.get_node_or_null(NodePath(from_id)) != null and graph.get_node_or_null(NodePath(to_id)) != null:
			graph.connect_node(from_id, int(edge.get("from_port", 0)), to_id, int(edge.get("to_port", 0)))
	status.text = "已打开蓝图：%s" % path

func _add_selected_action() -> void:
	var selected: PackedInt32Array = action_list.get_selected_items()
	if selected.is_empty():
		status.text = "请先选择一个操作节点"
		return
	var visible_actions: Array[Dictionary] = []
	var needle := search_edit.text.strip_edges().to_lower()
	for action in _registry.get_actions():
		var display := (str(action.get("name", "")) + " " + str(action.get("category", "")) + " " + str(action.get("id", ""))).to_lower()
		if needle.is_empty() or display.contains(needle):
			visible_actions.append(action)
	if selected[0] >= visible_actions.size():
		return
	_add_graph_node(visible_actions[selected[0]])

func _add_graph_node(action: Dictionary) -> void:
	_node_counter += 1
	var node_id := "bp_node_%d" % _node_counter
	while graph.get_node_or_null(NodePath(node_id)) != null:
		_node_counter += 1
		node_id = "bp_node_%d" % _node_counter
	var node_position := Vector2(80 + (_node_counter % 3) * 260, 70 + int(_node_counter / 3) * 180)
	_create_graph_node(action, node_id, node_position, true, {})
	status.text = "已添加：%s" % action.get("name", "操作")

func _default_parameter(type_name: String) -> Variant:
	match type_name:
		"node": return "$self"
		"number": return 1.0
		"integer": return 1
		"bool": return true
		"color": return "#70b7ff"
		"vector2": return "64,64"
		_: return ""

func _create_graph_node(action: Dictionary, node_id: String, node_position: Vector2, append_data: bool, saved_parameters: Dictionary) -> void:
	var graph_node := GraphNode.new()
	graph_node.title = str(action.get("name", "蓝图操作"))
	graph_node.name = node_id
	graph_node.position_offset = node_position
	graph_node.custom_minimum_size = Vector2(230, 110)
	var category_label := Label.new()
	category_label.text = "%s  |  %s" % [action.get("category", "通用"), action.get("id", "")]
	category_label.add_theme_color_override("font_color", Color("#9fb4ce"))
	graph_node.add_child(category_label)
	var port_label := Label.new()
	port_label.text = "执行流  ●────────────────▶"
	port_label.add_theme_color_override("font_color", Color("#71c7a0"))
	graph_node.add_child(port_label)
	graph_node.set_slot(0, true, 0, Color("#71c7a0"), true, 0, Color("#71c7a0"))
	graph.add_child(graph_node)
	if append_data:
		var parameters: Dictionary = {}
		var inputs: Array = action.get("inputs", [])
		for index in range(inputs.size()):
			parameters["arg_%d" % index] = _default_parameter(str(inputs[index]))
		blueprint.graph_nodes.append({"id": node_id, "action_id": action.get("id", ""), "position": node_position, "parameters": parameters})
	else:
		var data_index := _find_node_data_index(node_id)
		if data_index >= 0:
			blueprint.graph_nodes[data_index]["parameters"] = saved_parameters.duplicate(true)

func _find_node_data_index(node_id: String) -> int:
	for index in range(blueprint.graph_nodes.size()):
		if str(blueprint.graph_nodes[index].get("id", "")) == node_id:
			return index
	return -1

func _on_graph_node_selected(node: GraphNode) -> void:
	selected_node_id = str(node.name)
	_show_node_parameters(selected_node_id)

func _show_node_parameters(node_id: String) -> void:
	if blueprint == null or not is_instance_valid(parameter_panel):
		return
	_clear_parameter_panel("")
	var data_index := _find_node_data_index(node_id)
	if data_index < 0:
		return
	var data: Dictionary = blueprint.graph_nodes[data_index]
	var action: Dictionary = _registry.get_action(str(data.get("action_id", "")))
	if action.is_empty():
		_clear_parameter_panel("该操作未注册")
		return
	var heading := Label.new()
	heading.text = str(action.get("name", "操作参数"))
	heading.add_theme_font_size_override("font_size", 15)
	parameter_panel.add_child(heading)
	var inputs: Array = action.get("inputs", [])
	var parameters: Dictionary = data.get("parameters", {})
	_parameter_controls.clear()
	for index in range(inputs.size()):
		var key := "arg_%d" % index
		var type_name := str(inputs[index])
		var row := VBoxContainer.new()
		parameter_panel.add_child(row)
		var label := Label.new()
		label.text = "输入 %d · %s" % [index + 1, type_name]
		row.add_child(label)
		if type_name == "bool":
			var check := CheckBox.new()
			check.text = "启用"
			check.button_pressed = bool(parameters.get(key, true))
			check.toggled.connect(_on_parameter_changed.bind(node_id, key, "bool"))
			row.add_child(check)
			_parameter_controls[key] = check
		else:
			var edit := LineEdit.new()
			edit.text = str(parameters.get(key, _default_parameter(type_name)))
			edit.placeholder_text = "输入 %s" % type_name
			edit.text_changed.connect(_on_parameter_changed.bind(node_id, key, type_name))
			row.add_child(edit)
			_parameter_controls[key] = edit
	var hint := Label.new()
	hint.text = "节点参数会保存到蓝图资源，并在编译时按引脚顺序传入操作。"
	hint.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	parameter_panel.add_child(hint)

func _clear_parameter_panel(message: String) -> void:
	if not is_instance_valid(parameter_panel):
		return
	for child in parameter_panel.get_children():
		parameter_panel.remove_child(child)
		child.queue_free()
	_parameter_controls.clear()
	if not message.is_empty():
		var label := Label.new()
		label.text = message
		label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		parameter_panel.add_child(label)

func _parse_parameter(raw: Variant, type_name: String) -> Variant:
	if type_name == "bool":
		return bool(raw)
	if type_name == "color" and raw is Color:
		return raw
	if type_name == "vector2" and raw is Vector2:
		return raw
	if (type_name == "resource" or type_name == "texture2d") and raw is Resource:
		return raw
	var value := str(raw).strip_edges()
	match type_name:
		"number": return value.to_float()
		"integer": return value.to_int()
		"color": return Color.from_string(value, Color.WHITE)
		"vector2":
			var parts := value.split(",")
			if parts.size() == 2:
				return Vector2(parts[0].strip_edges().to_float(), parts[1].strip_edges().to_float())
			return Vector2.ZERO
		"resource", "texture2d":
			if value.begins_with("res://"):
				return load(value)
			return null
		_: return value

func _on_parameter_changed(value: Variant, node_id: String, key: String, type_name: String) -> void:
	var data_index := _find_node_data_index(node_id)
	if data_index < 0:
		return
	var parameters: Dictionary = blueprint.graph_nodes[data_index].get("parameters", {})
	parameters[key] = _parse_parameter(value, type_name)
	blueprint.graph_nodes[data_index]["parameters"] = parameters

func _on_connection_request(from_node: StringName, from_port: int, to_node: StringName, to_port: int) -> void:
	if blueprint == null or not is_instance_valid(graph):
		status.text = "蓝图画布尚未准备好。"
		return
	if from_node == to_node:
		status.text = "蓝图节点不能连接自己"
		return
	if _would_create_cycle(str(from_node), str(to_node)):
		status.text = "这条连线会形成循环，已拒绝连接。"
		return
	for edge in blueprint.graph_connections:
		if str(edge.get("from", "")) == str(from_node) and str(edge.get("to", "")) == str(to_node):
			status.text = "这条连线已经存在"
			return
	var error: Error = graph.connect_node(from_node, from_port, to_node, to_port)
	if error == OK:
		blueprint.graph_connections.append({"from": str(from_node), "from_port": from_port, "to": str(to_node), "to_port": to_port})
		status.text = "执行流连接成功"
	else:
		status.text = "连接失败：%d" % error


func _would_create_cycle(from_id: String, to_id: String) -> bool:
	# Adding A -> B creates a cycle exactly when B can already reach A.
	var pending: Array[String] = [to_id]
	var visited: Dictionary = {}
	while not pending.is_empty():
		var current_id: String = pending.pop_back()
		if current_id == from_id:
			return true
		if visited.has(current_id):
			continue
		visited[current_id] = true
		for edge in blueprint.graph_connections:
			if str(edge.get("from", "")) == current_id:
				pending.append(str(edge.get("to", "")))
	return false

func _on_disconnection_request(from_node: StringName, from_port: int, to_node: StringName, to_port: int) -> void:
	graph.disconnect_node(from_node, from_port, to_node, to_port)
	for index in range(blueprint.graph_connections.size() - 1, -1, -1):
		var edge: Dictionary = blueprint.graph_connections[index]
		if str(edge.get("from", "")) == str(from_node) and int(edge.get("from_port", 0)) == from_port and str(edge.get("to", "")) == str(to_node) and int(edge.get("to_port", 0)) == to_port:
			blueprint.graph_connections.remove_at(index)

func _on_delete_graph_nodes(nodes: Array[StringName]) -> void:
	for node_name in nodes:
		var node_id := str(node_name)
		var graph_node := graph.get_node_or_null(NodePath(node_id))
		if graph_node != null:
			graph.remove_child(graph_node)
			graph_node.queue_free()
		var data_index := _find_node_data_index(node_id)
		if data_index >= 0:
			blueprint.graph_nodes.remove_at(data_index)
		for index in range(blueprint.graph_connections.size() - 1, -1, -1):
			var edge: Dictionary = blueprint.graph_connections[index]
			if str(edge.get("from", "")) == node_id or str(edge.get("to", "")) == node_id:
				blueprint.graph_connections.remove_at(index)
	selected_node_id = ""
	_clear_parameter_panel("选中一个蓝图节点以编辑参数")

func _topological_order() -> Dictionary:
	var ids: Array[String] = []
	var indegree: Dictionary = {}
	var outgoing: Dictionary = {}
	for item in blueprint.graph_nodes:
		var node_id := str(item.get("id", ""))
		if node_id.is_empty() or ids.has(node_id):
			return {"ok": false, "error": "存在空 ID 或重复 ID"}
		ids.append(node_id)
		indegree[node_id] = 0
		outgoing[node_id] = []
	for edge in blueprint.graph_connections:
		var source := str(edge.get("from", ""))
		var target := str(edge.get("to", ""))
		if not indegree.has(source) or not indegree.has(target):
			return {"ok": false, "error": "连线指向不存在的节点"}
		outgoing[source].append(target)
		indegree[target] = int(indegree[target]) + 1
	var ready: Array[String] = []
	for node_id in ids:
		if int(indegree[node_id]) == 0:
			ready.append(node_id)
	var ordered: Array[String] = []
	while not ready.is_empty():
		var current: String = ready.pop_front()
		ordered.append(current)
		for next_id in outgoing[current]:
			indegree[next_id] = int(indegree[next_id]) - 1
			if int(indegree[next_id]) == 0:
				ready.append(str(next_id))
	if ordered.size() != ids.size():
		return {"ok": false, "error": "检测到循环连线，执行流必须是无环图"}
	return {"ok": true, "order": ordered}

func _compile_selected_event() -> void:
	if blueprint == null:
		status.text = "当前节点尚未创建蓝图，请先长按画布空白处打开蓝图库。"
		return
	var compiled: Dictionary = _compile_graph()
	if not bool(compiled.get("ok", false)):
		status.text = "编译失败：" + str(compiled.get("error", "未知错误"))
		return
	var event_name: String = str(EVENT_NAMES[event_select.selected])
	var found := false
	for index in range(blueprint.events.size()):
		if str(blueprint.events[index].get("event", "")) == event_name:
			blueprint.events[index] = {"event": event_name, "steps": compiled.get("steps", [])}
			found = true
			break
	if not found:
		blueprint.events.append({"event": event_name, "steps": compiled.get("steps", [])})
	blueprint.emit_changed()
	status.text = "编译成功：%s 绑定 %d 个执行步骤" % [event_name, compiled.get("steps", []).size()]

func _compile_graph() -> Dictionary:
	if blueprint == null:
		return {"ok": false, "error": "当前没有已绑定的蓝图资源"}
	var order_data: Dictionary = _topological_order()
	if not bool(order_data.get("ok", false)):
		return order_data
	var steps: Array[Dictionary] = []
	for node_id in order_data.get("order", []):
		var data_index := _find_node_data_index(str(node_id))
		if data_index < 0:
			return {"ok": false, "error": "找不到蓝图节点数据：" + str(node_id)}
		var data: Dictionary = blueprint.graph_nodes[data_index]
		var action_id := str(data.get("action_id", ""))
		var action: Dictionary = _registry.get_action(action_id)
		if action.is_empty():
			return {"ok": false, "error": "未注册的操作：" + action_id}
		var parameters: Dictionary = data.get("parameters", {})
		var arguments: Array = []
		var inputs: Array = action.get("inputs", [])
		for index in range(inputs.size()):
			var key := "arg_%d" % index
			if not parameters.has(key):
				return {"ok": false, "error": "%s 缺少参数 %d" % [action.get("name", action_id), index + 1]}
			arguments.append(_parse_parameter(parameters[key], str(inputs[index])))
		steps.append({"action_id": action_id, "arguments": arguments})
	return {"ok": true, "steps": steps}

func _validate() -> void:
	var result := _compile_graph()
	if bool(result.get("ok", false)):
		status.text = "检查通过：%d 个操作节点、%d 条连线；可编译为 %d 步" % [blueprint.graph_nodes.size(), blueprint.graph_connections.size(), result.get("steps", []).size()]
	else:
		status.text = "检查失败：" + str(result.get("error", "未知错误"))

func _save() -> void:
	if blueprint == null:
		return
	if not is_instance_valid(graph) or not is_instance_valid(name_edit) or not is_instance_valid(description_edit):
		status.text = "蓝图编辑器尚未初始化完成，暂时无法保存。"
		return
	blueprint.blueprint_name = name_edit.text.strip_edges()
	blueprint.description = description_edit.text
	var folder := "res://node_blueprints"
	var dir_error: Error = DirAccess.make_dir_recursive_absolute(ProjectSettings.globalize_path(folder))
	if dir_error != OK and dir_error != ERR_ALREADY_EXISTS:
		status.text = "无法创建蓝图目录：%d" % dir_error
		return
	var safe_name := blueprint.blueprint_name.validate_filename()
	if safe_name.is_empty():
		safe_name = blueprint.blueprint_id
	if resource_path.is_empty() or resource_path == "res://node_blueprints/new_blueprint.tres":
		resource_path = folder.path_join(safe_name + ".tres")
	if not is_instance_valid(graph):
		status.text = "蓝图画布尚未初始化，无法保存。"
		return
	for graph_child in graph.get_children():
		if graph_child is GraphNode:
			var data_index := _find_node_data_index(str(graph_child.name))
			if data_index >= 0:
				blueprint.graph_nodes[data_index]["position"] = graph_child.position_offset
	blueprint.graph_connections.clear()
	for edge in graph.get_connection_list():
		blueprint.graph_connections.append({"from": str(edge.get("from_node", "")), "from_port": int(edge.get("from_port", 0)), "to": str(edge.get("to_node", "")), "to_port": int(edge.get("to_port", 0))})
	var error: Error = ResourceSaver.save(blueprint, resource_path)
	status.text = "蓝图已保存：%s" % resource_path if error == OK else "保存失败，错误码：%d" % error
	if error == OK:
		blueprint_saved.emit(blueprint, target_node)

func _back() -> void:
	close_requested.emit()
