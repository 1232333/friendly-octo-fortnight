@tool
extends RefCounted
class_name BlueprintExecutor

const NodeAPIScript = preload("res://addons/skill_tree_editor/blueprint/apis/node_api.gd")
const RegistryScript = preload("res://addons/skill_tree_editor/blueprint/registries/blueprint_action_registry.gd")

signal action_executed(action_id: String, succeeded: bool)
signal execution_error(message: String)

var node_api: BlueprintNodeAPI
var registry: BlueprintActionRegistry
var execution_limit: int = 256
var context_node_id: String = ""
var _running := false

func _init(tree: GrowthTree = null) -> void:
	node_api = NodeAPIScript.new(tree)
	registry = RegistryScript.new()
	registry.set_handler("node.set_title", Callable(node_api, "set_title"))
	registry.set_handler("node.set_description", Callable(node_api, "set_description"))
	registry.set_handler("node.set_level", Callable(node_api, "set_level"))
	registry.set_handler("node.add_level", Callable(node_api, "add_level"))
	registry.set_handler("node.unlock", Callable(node_api, "unlock"))
	registry.set_handler("node.lock", Callable(node_api, "lock"))
	registry.set_handler("node.set_visible", Callable(node_api, "set_visible"))
	registry.set_handler("node.set_color", Callable(node_api, "set_color"))
	registry.set_handler("node.set_icon", Callable(node_api, "set_icon"))
	registry.set_handler("node.set_shape", Callable(node_api, "set_shape"))
	registry.set_handler("node.set_size", Callable(node_api, "set_size"))
	registry.set_handler("node.set_custom_data", Callable(node_api, "set_custom_data"))
	registry.set_handler("node.attach_blueprint", Callable(node_api, "attach_blueprint"))
	registry.set_handler("tree.create_node", Callable(node_api, "create_node"))
	registry.set_handler("tree.connect", Callable(node_api, "connect_nodes"))

func register_custom_action(action_id: String, display_name: String, category: String, input_types: Array, output_type: String, handler: Callable) -> bool:
	if not handler.is_valid():
		return false
	registry.register_action(action_id, display_name, category, input_types, output_type, handler)
	return true

func execute_action(action_id: String, arguments: Array) -> Variant:
	if _running:
		execution_error.emit("蓝图正在执行，拒绝重入调用")
		return false
	var definition := registry.get_action(action_id)
	if definition.is_empty():
		execution_error.emit("未注册的蓝图操作：" + action_id)
		return false
	var handler: Callable = definition.get("handler", Callable())
	if not handler.is_valid():
		execution_error.emit("蓝图操作尚未绑定执行函数：" + action_id)
		return false
	if not _validate_arguments(definition.get("inputs", []), arguments):
		execution_error.emit("蓝图操作参数类型或数量不正确：" + action_id)
		return false
	var resolved_arguments: Array = arguments.duplicate()
	for argument_index in range(resolved_arguments.size()):
		if resolved_arguments[argument_index] is String and (str(resolved_arguments[argument_index]) == "$self" or str(resolved_arguments[argument_index]) == "@self"):
			resolved_arguments[argument_index] = context_node_id
	_running = true
	var result: Variant = handler.callv(resolved_arguments)
	_running = false
	var success: bool = not (result is bool and result == false) and result != null
	action_executed.emit(action_id, success)
	return result

func _validate_arguments(input_types: Array, arguments: Array) -> bool:
	if input_types.size() != arguments.size():
		return false
	for index in range(input_types.size()):
		var type_name := str(input_types[index])
		var value: Variant = arguments[index]
		match type_name:
			"node", "string":
				if not (value is String):
					return false
			"number":
				if not (value is int or value is float):
					return false
			"integer":
				if not (value is int):
					return false
			"bool":
				if not (value is bool):
					return false
			"color":
				if not (value is Color):
					return false
			"vector2":
				if not (value is Vector2):
					return false
			"resource":
				if not (value is Resource):
					return false
			"texture2d":
				if not (value is Texture2D):
					return false
	return true

func execute_sequence(steps: Array) -> Array:
	var results: Array = []
	if steps.size() > execution_limit:
		execution_error.emit("蓝图步骤数量超过安全上限：%d" % execution_limit)
		return results
	for step in steps:
		if not (step is Dictionary):
			execution_error.emit("蓝图步骤格式错误，必须是 Dictionary")
			break
		var action_id := str(step.get("action_id", ""))
		var arguments: Array = step.get("arguments", [])
		results.append(execute_action(action_id, arguments))
	return results

func execute_blueprint_event(blueprint: NodeBlueprint, event_name: String) -> Array:
	var results: Array = []
	if blueprint == null:
		execution_error.emit("蓝图资源为空")
		return results
	for event_data in blueprint.events:
		if str(event_data.get("event", "")) == event_name:
			var steps: Array = event_data.get("steps", [])
			results.append_array(execute_sequence(steps))
	return results
