@tool
extends Resource
class_name GrowthTreeConnection

@export var from_id: String = ""
@export var to_id: String = ""
@export var branch_label: String = ""
