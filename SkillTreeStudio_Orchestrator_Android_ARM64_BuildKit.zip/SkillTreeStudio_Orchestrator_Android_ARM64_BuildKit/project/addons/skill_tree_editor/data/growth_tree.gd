@tool
extends Resource
class_name GrowthTree

enum TreeType { TECHNOLOGY, SKILL, TALENT, CUSTOM }

@export var tree_name: String = "新成长树"
@export var tree_type: TreeType = TreeType.SKILL
@export var folder_path: String = "res://growth_trees"
@export var nodes: Array[GrowthTreeNode] = []
@export var connections: Array[GrowthTreeConnection] = []

func get_node_by_id(node_id: String) -> GrowthTreeNode:
	for item in nodes:
		if item != null and item.id == node_id:
			return item
	return null

func add_node(item: GrowthTreeNode) -> bool:
	if item == null or item.id.is_empty() or get_node_by_id(item.id) != null:
		return false
	nodes.append(item)
	return true

func remove_node(node_id: String) -> void:
	for i in range(nodes.size() - 1, -1, -1):
		if nodes[i] != null and nodes[i].id == node_id:
			nodes.remove_at(i)
	for i in range(connections.size() - 1, -1, -1):
		var edge := connections[i]
		if edge != null and (edge.from_id == node_id or edge.to_id == node_id):
			connections.remove_at(i)

func has_connection(from_id: String, to_id: String) -> bool:
	for edge in connections:
		if edge != null and edge.from_id == from_id and edge.to_id == to_id:
			return true
	return false

func _path_exists(start_id: String, target_id: String, visited: Dictionary = {}) -> bool:
	if start_id == target_id:
		return true
	if visited.has(start_id):
		return false
	visited[start_id] = true
	for edge in connections:
		if edge != null and edge.from_id == start_id:
			if _path_exists(edge.to_id, target_id, visited):
				return true
	return false

func add_connection(from_id: String, to_id: String, branch_label: String = "") -> bool:
	if from_id == to_id or get_node_by_id(from_id) == null or get_node_by_id(to_id) == null:
		return false
	if has_connection(from_id, to_id) or _path_exists(to_id, from_id):
		return false
	var edge := GrowthTreeConnection.new()
	edge.from_id = from_id
	edge.to_id = to_id
	edge.branch_label = branch_label
	connections.append(edge)
	return true

func get_prerequisites(node_id: String) -> PackedStringArray:
	var result := PackedStringArray()
	for edge in connections:
		if edge != null and edge.to_id == node_id:
			result.append(edge.from_id)
	return result

func get_children(node_id: String) -> PackedStringArray:
	var result := PackedStringArray()
	for edge in connections:
		if edge != null and edge.from_id == node_id:
			result.append(edge.to_id)
	return result
