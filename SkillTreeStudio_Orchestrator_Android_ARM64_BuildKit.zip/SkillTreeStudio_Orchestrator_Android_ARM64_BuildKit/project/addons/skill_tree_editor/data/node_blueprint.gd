@tool
extends Resource
class_name NodeBlueprint

@export var blueprint_id: String = ""
@export var blueprint_name: String = "新建节点蓝图"
@export_multiline var description: String = ""
@export var version: int = 1
@export var events: Array[Dictionary] = []
@export var graph_nodes: Array[Dictionary] = []
@export var graph_connections: Array[Dictionary] = []
@export var exposed_variables: Array[Dictionary] = []
@export var required_permissions: PackedStringArray = PackedStringArray(["node.read", "node.write", "appearance.write"])
