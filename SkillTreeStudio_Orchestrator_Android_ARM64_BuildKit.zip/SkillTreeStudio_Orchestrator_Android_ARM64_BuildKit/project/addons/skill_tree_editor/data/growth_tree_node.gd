@tool
extends Resource
class_name GrowthTreeNode

enum NodeType { PASSIVE, TECHNOLOGY, ERA, TALENT, CONDITION, REWARD, GENERIC, BRANCH, EVENT, SKILL_ACTIVE, SKILL_ULTIMATE, SKILL_UPGRADE, TECH_UNLOCK, TALENT_ATTACK, TALENT_DEFENSE, TALENT_HEALTH, TALENT_SPEED, TALENT_CRIT }

@export var id: String = ""
@export var node_type: NodeType = NodeType.PASSIVE
@export var title: String = "新节点"
@export_multiline var description: String = ""
@export var icon: Texture2D
@export var show_title: bool = false
@export var position: Vector2 = Vector2.ZERO
@export_range(1, 999, 1) var max_level: int = 1

# 被动技能节点
@export var passive_effect: String = ""
@export var passive_value: float = 0.0
@export_enum("不叠加", "加法叠加", "乘法叠加", "取最高值") var passive_stack_mode: int = 1

# 科技节点
@export var research_cost: float = 0.0
@export var era_requirement: String = ""
@export_multiline var unlock_content: String = ""

# 时代节点
@export var era_name: String = ""
@export_multiline var era_entry_condition: String = ""
@export_multiline var era_reward: String = ""

# 天赋节点
@export var attribute_type: String = "attack"
@export var bonus_value: float = 0.0
@export_enum("固定值", "百分比") var bonus_mode: int = 0

# 条件节点
@export var condition_expression: String = ""
@export var condition_value: float = 0.0
@export var true_branch_label: String = "满足"
@export var false_branch_label: String = "不满足"

# 奖励节点
@export var reward_type: String = "资源"
@export var reward_amount: float = 1.0
@export_multiline var claim_condition: String = ""

# Active skill, event, branch, and technology-unlock data used by the inspector.
@export_multiline var skill_effect: String = ""
@export_range(0.0, 100000.0, 0.1) var skill_cooldown: float = 0.0
@export_range(0.0, 100000000.0, 0.1) var skill_resource_cost: float = 0.0
@export var skill_target: String = ""
@export var event_key: String = ""
@export_multiline var event_effect: String = ""
@export_enum("单选分支", "多选分支", "条件分支") var branch_mode: int = 0
@export var tech_unlock_id: String = ""

# v1.1.x compatibility fields; retained so older .tres resources still load.
@export var cost: float = 0.0
@export var attribute_key: String = "attack"
@export var bonus_is_percent: bool = false
@export var effect_text: String = ""
@export var legacy_type_migrated: bool = false

# Blueprint-controlled runtime and appearance properties.
@export_range(0, 999, 1) var current_level: int = 0
@export var is_unlocked: bool = false
@export var is_enabled: bool = true
@export var is_visible: bool = true
@export var blueprint_visual_enabled: bool = false
@export var blueprint_size_enabled: bool = false
@export_enum("圆形", "矩形", "六边形", "菱形") var blueprint_shape: int = 0
@export var blueprint_size: Vector2 = Vector2(72, 72)
@export var blueprint_color: Color = Color.WHITE
@export var custom_data: Dictionary = {}
@export var blueprint_refs: Array[Resource] = []

func migrate_legacy(tree_type: int) -> void:
	if legacy_type_migrated:
		return
	match tree_type:
		0:
			node_type = NodeType.TECHNOLOGY
			research_cost = cost
			unlock_content = effect_text
		1:
			node_type = NodeType.PASSIVE
			passive_effect = effect_text
			passive_value = bonus_value
		2:
			node_type = NodeType.TALENT
			attribute_type = attribute_key
			bonus_mode = 1 if bonus_is_percent else 0
			bonus_value = bonus_value
	legacy_type_migrated = true
