cmake_minimum_required(VERSION 3.20)
project(chinese_script_m1 LANGUAGES CXX)

set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
set(CMAKE_POSITION_INDEPENDENT_CODE ON)

if(NOT EXISTS "${CMAKE_CURRENT_SOURCE_DIR}/godot-cpp/CMakeLists.txt")
    message(FATAL_ERROR
        "godot-cpp not found. Run: git clone --depth 1 --branch 4.4 "
        "https://github.com/godotengine/godot-cpp.git godot-cpp")
endif()

add_subdirectory(godot-cpp)

add_library(chinese_script SHARED
    src/register_types.cpp
    src/language/chinese_language.cpp
    src/script/chinese_script.cpp
    src/runtime/script_instance.cpp
    src/frontend/m1_parser.cpp
)

target_include_directories(chinese_script PRIVATE
    "${CMAKE_CURRENT_SOURCE_DIR}/src"
)

target_link_libraries(chinese_script PRIVATE godot-cpp)

set_target_properties(chinese_script PROPERTIES
    OUTPUT_NAME "chinese_script"
    PREFIX "lib"
    LIBRARY_OUTPUT_DIRECTORY
        "${CMAKE_CURRENT_SOURCE_DIR}/addons/chinese_script_language/bin"
    RUNTIME_OUTPUT_DIRECTORY
        "${CMAKE_CURRENT_SOURCE_DIR}/addons/chinese_script_language/bin"
)
