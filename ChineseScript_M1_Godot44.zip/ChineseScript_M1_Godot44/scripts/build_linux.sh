#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"

if [[ ! -f godot-cpp/CMakeLists.txt ]]; then
  git clone --depth 1 --branch 4.4 https://github.com/godotengine/godot-cpp.git godot-cpp
fi

cmake -S . -B build -DCMAKE_BUILD_TYPE=Debug
cmake --build build --parallel
echo "Built: addons/chinese_script_language/bin/libchinese_script.so"
