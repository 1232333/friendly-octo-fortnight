# 华文脚本 M1 — Godot 4.4 GDExtension

这是 M1 最小运行时工程骨架：注册 `ScriptLanguageExtension`，创建 `ScriptExtension`，通过 Godot 4.3+ 的 `script_instance_create3` 接口建立脚本实例，并在 Node 收到 `NOTIFICATION_READY` 时执行中文脚本中的 `打印("...")`。

## 目标

- Godot 4.4 / godot-cpp 4.4
- GDExtension，不重新编译 Godot
- `.zh` 源码，UTF-8
- `Node2D` 挂载
- `_ready` 通知桥接
- M1 语法：

  ```text
  类 测试节点，继承 节点二D：
      当准备完成：
          打印("华文脚本运行成功")
  ```

## 重要说明

此包是 M1 源码工程，不包含预编译动态库。当前执行环境没有 Godot 4.4 SDK / godot-cpp 构建树，因此没有声称已经完成编译或引擎内运行验证。尤其是 `ScriptLanguageExtension` 的编辑器列表刷新和脚本资源加载行为，必须在目标 Godot 小版本中实测。

M1 只支持：
- 一个类声明
- 原生基类名（当前映射 `节点二D` → `Node2D`、`节点` → `Node`、`资源` → `Resource`）
- `当准备完成` 生命周期段落
- `打印("字符串")`

暂不支持属性、方法声明、表达式、信号、继承中文脚本、`@tool`、调试器和热重载。

## 构建（Linux x86_64 / ARM64）

在项目根目录：

```bash
git clone --depth 1 --branch 4.4 https://github.com/godotengine/godot-cpp.git godot-cpp
cmake -S . -B build -DCMAKE_BUILD_TYPE=Debug
cmake --build build --parallel
```

动态库输出位置：

```text
addons/chinese_script_language/bin/libchinese_script.so
```

之后用 Godot 4.4 打开项目并运行 `test/main.tscn`。

## 在 Android / Termux 上

本包没有把 Linux `.so` 冒充 Android ARM64 动态库。Android 需要使用 Android ABI 对应的编译器/NDK sysroot，并针对 Android 目标重新构建 godot-cpp 与本扩展；编译产物必须放入 `.gdextension` 对应的 Android library 项。现有 Plugin Factory / Termux 工具链可以在确认其 NDK/ABI 参数后接入，但不能只改文件名。

## 结构

```text
addons/chinese_script_language/
  chinese_script.gdextension
  bin/
src/
  frontend/m1_parser.*
  language/chinese_language.*
  script/chinese_script.*
  runtime/script_instance.*
  register_types.cpp
test/
  main.tscn
  test.zh
CMakeLists.txt
```

## ABI 设计

实例通过 Godot 4.3 起提供的 `script_instance_create3` 创建。M1 只填充必要的 owner、script、language、notification、free 回调；属性和方法回调留给后续里程碑。不要把普通 C++ `ChineseInstanceData*` 直接作为 Godot 的 `ScriptInstance` 指针返回。

## M1 验收

1. 编译并将动态库放入 bin。
2. 用 Godot 4.4 打开项目。
3. 运行主场景。
4. Output 应出现：`华文脚本运行成功`。
5. 如果 `.zh` 没有被自动识别，先查看 Godot 启动日志中的 GDExtension 加载结果和 ScriptServer 语言注册结果；不要先改成 GDScript 翻译方案。
