#include "language/chinese_language.h"
#include "runtime/script_instance.h"
#include "script/chinese_script.h"

#include <godot_cpp/classes/engine.hpp>
#include <godot_cpp/core/class_db.hpp>
#include <godot_cpp/core/memory.hpp>
#include <godot_cpp/variant/utility_functions.hpp>
#include <godot_cpp/godot.hpp>

using namespace godot;

static ChineseLanguage *s_language = nullptr;

void initialize_chinese_script(ModuleInitializationLevel p_level) {
    if (p_level != MODULE_INITIALIZATION_LEVEL_SCENE) {
        return;
    }

    ClassDB::register_class<ChineseScript>();
    ClassDB::register_class<ChineseLanguage>();

    s_language = memnew(ChineseLanguage);
    ChineseLanguage::set_singleton(s_language);

    const Error err = Engine::get_singleton()->register_script_language(s_language);
    if (err != OK) {
        UtilityFunctions::push_error("华文脚本：注册 ScriptLanguage 失败，错误码：", err);
    }
}

void uninitialize_chinese_script(ModuleInitializationLevel p_level) {
    if (p_level != MODULE_INITIALIZATION_LEVEL_SCENE) {
        return;
    }

    if (s_language) {
        Engine::get_singleton()->unregister_script_language(s_language);
        ChineseLanguage::set_singleton(nullptr);
        memdelete(s_language);
        s_language = nullptr;
    }
}

extern "C" {

GDExtensionBool GDE_EXPORT chinese_script_library_init(
        GDExtensionInterfaceGetProcAddress p_get_proc_address,
        GDExtensionClassLibraryPtr p_library,
        GDExtensionInitialization *r_initialization) {

    set_script_instance_create3(p_get_proc_address);

    GDExtensionBinding::InitObject init_obj(
            p_get_proc_address,
            p_library,
            r_initialization);

    init_obj.register_initializer(initialize_chinese_script);
    init_obj.register_terminator(uninitialize_chinese_script);
    init_obj.set_minimum_library_initialization_level(
            MODULE_INITIALIZATION_LEVEL_SCENE);

    return init_obj.init();
}

} // extern "C"
