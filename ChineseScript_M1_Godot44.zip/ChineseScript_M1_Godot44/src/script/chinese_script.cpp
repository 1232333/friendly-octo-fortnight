#include "chinese_script.h"

#include "../language/chinese_language.h"
#include "../runtime/script_instance.h"

#include <godot_cpp/variant/utility_functions.hpp>

namespace godot {

void ChineseScript::_bind_methods() {
}

void ChineseScript::_set_source_code(const String &p_code) {
    source_code = p_code;
    M1Parser parser;
    valid = parser.parse(source_code, program);
    _update_exports();
}

String ChineseScript::_get_source_code() const {
    return source_code;
}

void ChineseScript::execute_ready(Object *p_owner) {
    if (!valid) {
        UtilityFunctions::push_error("华文脚本：脚本未通过 M1 语法检查");
        return;
    }

    for (int i = 0; i < program.ready_prints.size(); ++i) {
        UtilityFunctions::print(program.ready_prints[i]);
    }
}

bool ChineseScript::_can_instantiate() const {
    return valid;
}

bool ChineseScript::_is_valid() const {
    return valid;
}

bool ChineseScript::_is_tool() const {
    return false;
}

bool ChineseScript::_has_source_code() const {
    return true;
}

ScriptLanguage *ChineseScript::_get_language() const {
    return ChineseLanguage::get_singleton();
}

StringName ChineseScript::_get_instance_base_type() const {
    return StringName(program.base_type);
}

Ref<Script> ChineseScript::_get_base_script() const {
    return Ref<Script>();
}

Array<Dictionary> ChineseScript::_get_script_property_list() const {
    return Array<Dictionary>();
}

Array<Dictionary> ChineseScript::_get_script_method_list() const {
    return Array<Dictionary>();
}

Array<Dictionary> ChineseScript::_get_script_signal_list() const {
    return Array<Dictionary>();
}

Dictionary ChineseScript::_get_constants() const {
    return Dictionary();
}

bool ChineseScript::_has_method(const StringName &p_method) const {
    return false;
}

bool ChineseScript::_has_script_signal(const StringName &p_signal) const {
    return false;
}

bool ChineseScript::_instance_has(Object *p_object) const {
    return has_chinese_script_instance(p_object);
}

void *ChineseScript::_instance_create(Object *p_for_object) const {
    if (!valid || !p_for_object) {
        return nullptr;
    }

    Ref<ChineseScript> self(const_cast<ChineseScript *>(this));
    return create_chinese_script_instance(p_for_object, self);
}

Error ChineseScript::_reload(bool p_keep_state) {
    M1Parser parser;
    valid = parser.parse(source_code, program);
    return valid ? OK : ERR_PARSE_ERROR;
}

void ChineseScript::_update_exports() {
    // M1 has no exported properties. M3 will populate property metadata.
}

} // namespace godot
