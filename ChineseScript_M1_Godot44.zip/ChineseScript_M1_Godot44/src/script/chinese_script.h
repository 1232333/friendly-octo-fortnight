#pragma once

#include <godot_cpp/classes/script_extension.hpp>

#include "../frontend/m1_parser.h"

namespace godot {

class ChineseScript : public ScriptExtension {
    GDCLASS(ChineseScript, ScriptExtension);

private:
    String source_code;
    M1Program program;
    bool valid = false;

protected:
    static void _bind_methods();

public:
    void execute_ready(Object *p_owner);

    bool _can_instantiate() const override;
    bool _is_valid() const override;
    bool _is_tool() const override;
    bool _has_source_code() const override;
    String _get_source_code() const override;
    void _set_source_code(const String &p_code) override;
    ScriptLanguage *_get_language() const override;
    StringName _get_instance_base_type() const override;
    Ref<Script> _get_base_script() const override;

    Array<Dictionary> _get_script_property_list() const override;
    Array<Dictionary> _get_script_method_list() const override;
    Array<Dictionary> _get_script_signal_list() const override;
    Dictionary _get_constants() const override;

    bool _has_method(const StringName &p_method) const override;
    bool _has_script_signal(const StringName &p_signal) const override;
    bool _instance_has(Object *p_object) const override;
    void *_instance_create(Object *p_for_object) const override;
    Error _reload(bool p_keep_state) override;
    void _update_exports() override;
};

} // namespace godot
