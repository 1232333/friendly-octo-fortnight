#pragma once

#include <godot_cpp/variant/string.hpp>
#include <godot_cpp/templates/vector.hpp>

namespace godot {

struct M1Program {
    String base_type = "Node2D";
    bool has_ready_section = false;
    Vector<String> ready_prints;
    String error_message;
    int error_line = 0;
};

class M1Parser {
public:
    bool parse(const String &p_source, M1Program &r_program) const;

private:
    static String normalize_base_type(String p_name);
    static bool parse_print_statement(const String &p_line, String &r_message);
};

} // namespace godot
