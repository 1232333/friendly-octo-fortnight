#include "m1_parser.h"

namespace godot {

String M1Parser::normalize_base_type(String p_name) {
    p_name = p_name.strip_edges();

    while (p_name.ends_with("：") || p_name.ends_with(":") ||
            p_name.ends_with("，") || p_name.ends_with(",")) {
        p_name = p_name.substr(0, p_name.length() - 1).strip_edges();
    }

    if (p_name == "节点二D" || p_name == "二维节点") {
        return "Node2D";
    }
    if (p_name == "节点") {
        return "Node";
    }
    if (p_name == "资源") {
        return "Resource";
    }
    return p_name;
}

bool M1Parser::parse_print_statement(const String &p_line, String &r_message) {
    int open = p_line.find("打印(");
    int open_width = 2;

    if (open < 0) {
        open = p_line.find("打印（");
        open_width = 2;
    }
    if (open < 0) {
        return false;
    }

    int arg_start = open + String("打印").length() + 1;
    int close = p_line.rfind(")");
    if (close < 0) {
        close = p_line.rfind("）");
    }
    if (close <= arg_start) {
        return false;
    }

    String arg = p_line.substr(arg_start, close - arg_start).strip_edges();
    if (arg.length() < 2) {
        return false;
    }

    const char32_t quote = arg[0];
    if ((quote != '"' && quote != '\'') || arg[arg.length() - 1] != quote) {
        return false;
    }

    r_message = arg.substr(1, arg.length() - 2);
    r_message = r_message.replace("\\n", "\n");
    r_message = r_message.replace("\\t", "\t");
    r_message = r_message.replace("\\\"", "\"");
    r_message = r_message.replace("\\'", "'");
    r_message = r_message.replace("\\\\", "\\");
    return true;
}

bool M1Parser::parse(const String &p_source, M1Program &r_program) const {
    r_program = M1Program();

    const PackedStringArray lines = p_source.replace("\r\n", "\n").split("\n");
    bool found_class = false;
    bool in_ready = false;

    for (int i = 0; i < lines.size(); ++i) {
        String line = lines[i].strip_edges();
        if (line.is_empty() || line.begins_with("#")) {
            continue;
        }

        if (line.begins_with("类 ")) {
            found_class = true;
            const int inherit_pos = line.find("继承");
            if (inherit_pos >= 0) {
                String base_name = line.substr(inherit_pos + String("继承").length()).strip_edges();
                r_program.base_type = normalize_base_type(base_name);
            }
            continue;
        }

        if (line.begins_with("当准备完成")) {
            in_ready = true;
            r_program.has_ready_section = true;
            continue;
        }

        if (in_ready && line.begins_with("打印")) {
            String message;
            if (!parse_print_statement(line, message)) {
                r_program.error_message = "M1 只支持 打印(\"字符串\") 形式";
                r_program.error_line = i + 1;
                return false;
            }
            r_program.ready_prints.push_back(message);
        }
    }

    if (!found_class) {
        r_program.error_message = "缺少类声明。示例：类 测试节点，继承 节点二D：";
        r_program.error_line = 1;
        return false;
    }

    if (r_program.base_type.is_empty()) {
        r_program.base_type = "Node2D";
    }

    return true;
}

} // namespace godot
