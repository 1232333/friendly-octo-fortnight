#include "chinese_language.h"

#include "../frontend/m1_parser.h"
#include "../script/chinese_script.h"

#include <godot_cpp/core/memory.hpp>

namespace godot {

static ChineseLanguage *s_language_singleton = nullptr;

void ChineseLanguage::_bind_methods() {
}

ChineseLanguage *ChineseLanguage::get_singleton() {
    return s_language_singleton;
}

void ChineseLanguage::set_singleton(ChineseLanguage *p_language) {
    s_language_singleton = p_language;
}

String ChineseLanguage::_get_name() const {
    return "华文脚本";
}

String ChineseLanguage::_get_type() const {
    return "ChineseScript";
}

String ChineseLanguage::_get_extension() const {
    return "zh";
}

PackedStringArray ChineseLanguage::_get_recognized_extensions() const {
    PackedStringArray extensions;
    extensions.push_back("zh");
    return extensions;
}

PackedStringArray ChineseLanguage::_get_reserved_words() const {
    PackedStringArray words;
    words.push_back("类");
    words.push_back("继承");
    words.push_back("变量");
    words.push_back("常量");
    words.push_back("定义");
    words.push_back("返回");
    words.push_back("若");
    words.push_back("否则");
    words.push_back("重复");
    words.push_back("对于");
    words.push_back("当准备完成");
    words.push_back("打印");
    return words;
}

PackedStringArray ChineseLanguage::_get_comment_delimiters() const {
    PackedStringArray delimiters;
    delimiters.push_back("#");
    return delimiters;
}

PackedStringArray ChineseLanguage::_get_string_delimiters() const {
    PackedStringArray delimiters;
    delimiters.push_back("\" \"");
    delimiters.push_back("' '");
    return delimiters;
}

bool ChineseLanguage::_is_control_flow_keyword(const String &p_keyword) const {
    return p_keyword == "若" ||
            p_keyword == "否则" ||
            p_keyword == "重复" ||
            p_keyword == "对于";
}

void ChineseLanguage::_init() {
    s_language_singleton = this;
}

void ChineseLanguage::_finish() {
    if (s_language_singleton == this) {
        s_language_singleton = nullptr;
    }
}

void ChineseLanguage::_frame() {
}

void ChineseLanguage::_thread_enter() {
}

void ChineseLanguage::_thread_exit() {
}

Object *ChineseLanguage::_create_script() const {
    return memnew(ChineseScript);
}

Dictionary ChineseLanguage::_validate(
        const String &p_code,
        const String &p_path,
        bool p_validate_functions,
        bool p_validate_errors,
        bool p_validate_warnings,
        bool p_validate_safe_lines) const {
    M1Program program;
    M1Parser parser;
    const bool ok = parser.parse(p_code, program);

    Dictionary result;
    result["valid"] = ok;

    Array<Dictionary> errors;
    if (!ok) {
        Dictionary error;
        error["line"] = program.error_line;
        error["column"] = 1;
        error["message"] = program.error_message;
        error["code"] = "CHINESE_M1_PARSE_ERROR";
        errors.push_back(error);
    }

    result["errors"] = errors;
    result["warnings"] = Array<Dictionary>();
    result["functions"] = Array<Dictionary>();
    result["safe_lines"] = PackedInt32Array();
    return result;
}

Ref<Script> ChineseLanguage::_make_template(
        const String &p_template,
        const String &p_class_name,
        const String &p_base_class_name) const {
    Ref<ChineseScript> script;
    script.instantiate();

    String base_name = p_base_class_name;
    if (base_name == "Node2D") {
        base_name = "节点二D";
    } else if (base_name == "Node") {
        base_name = "节点";
    } else if (base_name == "Resource") {
        base_name = "资源";
    }

    String source = "类 " + p_class_name + "，继承 " + base_name + "：\n";
    source += "    当准备完成：\n";
    source += "        打印(\"华文脚本运行成功\")\n";
    script->set_source_code(source);
    return Ref<Script>(script);
}

Dictionary ChineseLanguage::_get_global_class_name(const String &p_path) const {
    Dictionary result;
    result["name"] = "";
    result["base_type"] = "Node2D";
    result["icon_path"] = "";
    return result;
}

Array<Dictionary> ChineseLanguage::_get_public_functions() const {
    return Array<Dictionary>();
}

Dictionary ChineseLanguage::_get_public_constants() const {
    return Dictionary();
}

Dictionary ChineseLanguage::_lookup_code(
        const String &p_code,
        const String &p_symbol,
        const String &p_path,
        Object *p_owner) const {
    return Dictionary();
}

Dictionary ChineseLanguage::_complete_code(
        const String &p_code,
        const String &p_path,
        Object *p_owner) const {
    return Dictionary();
}

} // namespace godot
