#pragma once

#include <godot_cpp/classes/script_language_extension.hpp>

namespace godot {

class ChineseLanguage : public ScriptLanguageExtension {
    GDCLASS(ChineseLanguage, ScriptLanguageExtension);

protected:
    static void _bind_methods();

public:
    static ChineseLanguage *get_singleton();
    static void set_singleton(ChineseLanguage *p_language);

    String _get_name() const override;
    String _get_type() const override;
    String _get_extension() const override;
    PackedStringArray _get_recognized_extensions() const override;
    PackedStringArray _get_reserved_words() const override;
    PackedStringArray _get_comment_delimiters() const override;
    PackedStringArray _get_string_delimiters() const override;
    bool _is_control_flow_keyword(const String &p_keyword) const override;

    void _init() override;
    void _finish() override;
    void _frame() override;
    void _thread_enter() override;
    void _thread_exit() override;

    Object *_create_script() const override;
    Dictionary _validate(
            const String &p_code,
            const String &p_path,
            bool p_validate_functions,
            bool p_validate_errors,
            bool p_validate_warnings,
            bool p_validate_safe_lines) const override;

    Ref<Script> _make_template(
            const String &p_template,
            const String &p_class_name,
            const String &p_base_class_name) const override;

    Dictionary _get_global_class_name(const String &p_path) const override;
    Array<Dictionary> _get_public_functions() const override;
    Dictionary _get_public_constants() const override;
    Dictionary _lookup_code(
            const String &p_code,
            const String &p_symbol,
            const String &p_path,
            Object *p_owner) const override;
    Dictionary _complete_code(
            const String &p_code,
            const String &p_path,
            Object *p_owner) const override;
};

} // namespace godot
