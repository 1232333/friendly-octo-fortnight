#include "script_instance.h"

#include "../language/chinese_language.h"
#include "../script/chinese_script.h"

#include <godot_cpp/classes/node.hpp>
#include <godot_cpp/variant/utility_functions.hpp>

#include <mutex>
#include <unordered_map>

namespace godot {

static GDExtensionInterfaceScriptInstanceCreate3 s_script_instance_create3 = nullptr;
static GDExtensionScriptInstanceInfo3 s_instance_info = {};
static bool s_info_initialized = false;
static std::mutex s_instances_mutex;
static std::unordered_map<uint64_t, uint32_t> s_instance_owner_counts;

static GDExtensionObjectPtr instance_get_owner(GDExtensionScriptInstanceDataPtr p_data) {
    auto *data = static_cast<ChineseInstanceData *>(p_data);
    return data ? reinterpret_cast<GDExtensionObjectPtr>(data->owner) : nullptr;
}

static GDExtensionObjectPtr instance_get_script(GDExtensionScriptInstanceDataPtr p_data) {
    auto *data = static_cast<ChineseInstanceData *>(p_data);
    if (!data || data->script.is_null()) {
        return nullptr;
    }
    return reinterpret_cast<GDExtensionObjectPtr>(data->script.ptr());
}

static GDExtensionScriptLanguagePtr instance_get_language(GDExtensionScriptInstanceDataPtr) {
    return reinterpret_cast<GDExtensionScriptLanguagePtr>(ChineseLanguage::get_singleton());
}

static void instance_notification(
        GDExtensionScriptInstanceDataPtr p_data,
        int32_t p_what,
        GDExtensionBool p_reversed) {
    auto *data = static_cast<ChineseInstanceData *>(p_data);
    if (!data || data->ready_called || p_reversed) {
        return;
    }

    if (p_what == Node::NOTIFICATION_READY) {
        data->ready_called = true;
        if (data->script.is_valid()) {
            data->script->execute_ready(data->owner);
        }
    }
}

static void instance_free(GDExtensionScriptInstanceDataPtr p_data) {
    auto *data = static_cast<ChineseInstanceData *>(p_data);
    if (data && data->owner_id != 0) {
        std::lock_guard<std::mutex> lock(s_instances_mutex);
        auto it = s_instance_owner_counts.find(data->owner_id);
        if (it != s_instance_owner_counts.end()) {
            if (it->second <= 1) {
                s_instance_owner_counts.erase(it);
            } else {
                --it->second;
            }
        }
    }
    delete data;
}

static void initialize_instance_info() {
    if (s_info_initialized) {
        return;
    }

    s_instance_info = {};
    s_instance_info.get_owner_func = instance_get_owner;
    s_instance_info.notification_func = instance_notification;
    s_instance_info.get_script_func = instance_get_script;
    s_instance_info.get_language_func = instance_get_language;
    s_instance_info.free_func = instance_free;

    // M1 intentionally leaves property/method callbacks null.
    // They are added in M2/M3 after the VM and property metadata exist.
    s_info_initialized = true;
}

void set_script_instance_create3(GDExtensionInterfaceGetProcAddress p_get_proc_address) {
    if (!p_get_proc_address) {
        return;
    }

    s_script_instance_create3 =
            reinterpret_cast<GDExtensionInterfaceScriptInstanceCreate3>(
                    p_get_proc_address("script_instance_create3"));
}

void *create_chinese_script_instance(Object *p_owner, const Ref<ChineseScript> &p_script) {
    if (!p_owner || p_script.is_null() || !s_script_instance_create3) {
        return nullptr;
    }

    initialize_instance_info();

    auto *data = new ChineseInstanceData;
    data->owner = p_owner;
    data->owner_id = static_cast<uint64_t>(p_owner->get_instance_id());
    data->script = p_script;
    {
        std::lock_guard<std::mutex> lock(s_instances_mutex);
        ++s_instance_owner_counts[data->owner_id];
    }

    GDExtensionScriptInstancePtr instance =
            s_script_instance_create3(&s_instance_info,
                    reinterpret_cast<GDExtensionScriptInstanceDataPtr>(data));

    if (!instance) {
        {
            std::lock_guard<std::mutex> lock(s_instances_mutex);
            auto it = s_instance_owner_counts.find(data->owner_id);
            if (it != s_instance_owner_counts.end()) {
                if (it->second <= 1) s_instance_owner_counts.erase(it);
                else --it->second;
            }
        }
        delete data;
        return nullptr;
    }

    return reinterpret_cast<void *>(instance);
}

bool has_chinese_script_instance(Object *p_owner) {
    if (!p_owner) {
        return false;
    }
    std::lock_guard<std::mutex> lock(s_instances_mutex);
    auto it = s_instance_owner_counts.find(static_cast<uint64_t>(p_owner->get_instance_id()));
    return it != s_instance_owner_counts.end() && it->second > 0;
}

} // namespace godot
