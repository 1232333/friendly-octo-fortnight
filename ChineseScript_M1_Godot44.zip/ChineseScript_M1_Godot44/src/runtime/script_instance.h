#pragma once

#include <cstdint>

#include <godot_cpp/classes/object.hpp>
#include <godot_cpp/classes/script.hpp>
#include <gdextension_interface.h>

namespace godot {

class ChineseScript;

struct ChineseInstanceData {
    Object *owner = nullptr; // Engine owns the Object; instance is destroyed with its script instance.
    uint64_t owner_id = 0;
    Ref<ChineseScript> script;
    bool ready_called = false;
};

void set_script_instance_create3(GDExtensionInterfaceGetProcAddress p_get_proc_address);
void *create_chinese_script_instance(Object *p_owner, const Ref<ChineseScript> &p_script);
bool has_chinese_script_instance(Object *p_owner);

} // namespace godot
